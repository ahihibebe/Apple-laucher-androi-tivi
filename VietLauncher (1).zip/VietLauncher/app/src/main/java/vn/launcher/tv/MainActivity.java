package vn.launcher.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    // Ưu tiên đưa các ứng dụng này lên dock (so khớp theo tên hiển thị)
    private static final String[] DOCK_PREF = {"youtube", "fpt play", "tv360", "vtv"};
    private static final String[] THU = {"Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư",
            "Thứ năm", "Thứ sáu", "Thứ bảy"};

    // Màu quầng sáng của các hình nền có sẵn (0 = nền đen)
    private static final String[] PRESET_NAMES = {"Đỏ (mặc định)", "Xanh dương", "Tím", "Xanh lá", "Đen"};
    private static final int[] PRESET_COLORS = {0xAAB71C1C, 0xAA1565C0, 0xAA6A1B9A, 0xAA2E7D32, 0};

    private static final int REQ_PICK_IMAGE = 101;

    // Độ đục của ô ứng dụng khi chưa chọn (0.6 = 60%); ô đang chọn luôn rõ 100%
    private static final float TILE_ALPHA = 0.6f;

    interface Opener {
        InputStream open() throws IOException;
    }

    private LinearLayout dock;
    private GridLayout grid;
    private TextView appName, greeting, dateView, lunarView;

    private SharedPreferences prefs;
    private SoundPool sounds;
    private int soundMove, soundSelect;
    private boolean soundOn = true;
    private boolean quiet = false;

    static class AppItem {
        String label, pkg, cls;
        Drawable image;
        boolean banner;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        soundOn = prefs.getBoolean("sound", true);

        dock = findViewById(R.id.dock);
        grid = findViewById(R.id.grid);
        appName = findViewById(R.id.app_name);
        greeting = findViewById(R.id.greeting);
        dateView = findViewById(R.id.date);
        lunarView = findViewById(R.id.lunar);

        initSounds();
        applyBackground();

        int[] pillIds = {R.id.pill_inputs, R.id.pill_wifi, R.id.pill_settings};
        for (int id : pillIds) {
            findViewById(id).setOnFocusChangeListener((v, has) -> {
                if (has) playMove();
            });
        }

        findViewById(R.id.pill_inputs).setOnClickListener(v -> {
            playSelect();
            startSafe(new Intent("com.android.tv.action.VIEW_INPUTS"),
                    new Intent(Settings.ACTION_SETTINGS));
        });
        findViewById(R.id.pill_wifi).setOnClickListener(v -> {
            playSelect();
            startSafe(new Intent(Settings.ACTION_WIFI_SETTINGS),
                    new Intent(Settings.ACTION_SETTINGS));
        });
        findViewById(R.id.pill_settings).setOnClickListener(v -> {
            playSelect();
            showMenu();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateHeader();
        loadApps();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sounds != null) {
            sounds.release();
            sounds = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Là màn hình chính nên không thoát khi bấm Back
    }

    // ---------------------------------------------------------------- Âm thanh

    private void initSounds() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        sounds = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build();
        soundMove = sounds.load(this, R.raw.move, 1);
        soundSelect = sounds.load(this, R.raw.select, 1);
    }

    private void playMove() {
        if (soundOn && !quiet && sounds != null) sounds.play(soundMove, 0.6f, 0.6f, 1, 0, 1f);
    }

    private void playSelect() {
        if (soundOn && sounds != null) sounds.play(soundSelect, 0.7f, 0.7f, 1, 0, 1f);
    }

    // ---------------------------------------------------------------- Menu tùy chỉnh

    private void showMenu() {
        String[] items = {"Hình nền…", "Âm thanh di chuyển: " + (soundOn ? "Bật" : "Tắt"),
                "Cài đặt hệ thống của TV"};
        new AlertDialog.Builder(this)
                .setTitle("Cài đặt")
                .setItems(items, (dlg, which) -> {
                    if (which == 0) {
                        showWallpaperMenu();
                    } else if (which == 1) {
                        soundOn = !soundOn;
                        prefs.edit().putBoolean("sound", soundOn).apply();
                        toast("Âm thanh di chuyển: " + (soundOn ? "Bật" : "Tắt"));
                        playSelect();
                    } else {
                        startSafe(new Intent(Settings.ACTION_SETTINGS));
                    }
                })
                .show();
    }

    private void showWallpaperMenu() {
        final int n = PRESET_NAMES.length;
        String[] items = new String[n + 2];
        System.arraycopy(PRESET_NAMES, 0, items, 0, n);
        items[n] = "Chọn ảnh từ thiết bị…";
        items[n + 1] = "Chọn ảnh từ thư mục ứng dụng…";
        new AlertDialog.Builder(this)
                .setTitle("Hình nền")
                .setItems(items, (dlg, which) -> {
                    if (which < n) {
                        prefs.edit().putString("bg", "preset:" + which).apply();
                        applyBackground();
                    } else if (which == n) {
                        pickImage();
                    } else {
                        showLocalImages();
                    }
                })
                .show();
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try {
            startActivityForResult(i, REQ_PICK_IMAGE);
        } catch (ActivityNotFoundException e) {
            // Nhiều TV không có trình chọn tệp → dùng thư mục riêng của ứng dụng
            toast("TV này không có trình chọn ảnh, dùng thư mục ứng dụng");
            showLocalImages();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK_IMAGE && res == RESULT_OK && data != null && data.getData() != null) {
            final Uri uri = data.getData();
            applyCustomAsync(() -> getContentResolver().openInputStream(uri));
        }
    }

    private void showLocalImages() {
        final File dir = getExternalFilesDir("wallpapers");
        File[] found = dir == null ? null : dir.listFiles((d, name) -> {
            String l = name.toLowerCase(Locale.ROOT);
            return l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") || l.endsWith(".webp");
        });
        final String path = dir == null ? "" : dir.getAbsolutePath();
        if (found == null || found.length == 0) {
            new AlertDialog.Builder(this)
                    .setTitle("Chưa có ảnh nào")
                    .setMessage("Hãy chép ảnh (jpg/png/webp) vào thư mục:\n" + path
                            + "\n\nVí dụ từ máy tính:\nadb push anh.jpg " + path + "/")
                    .setPositiveButton("Đóng", null)
                    .show();
            return;
        }
        final File[] files = found;
        String[] names = new String[files.length];
        for (int k = 0; k < files.length; k++) names[k] = files[k].getName();
        new AlertDialog.Builder(this)
                .setTitle("Chọn ảnh nền")
                .setItems(names, (dlg, which) -> {
                    final File f = files[which];
                    applyCustomAsync(() -> new FileInputStream(f));
                })
                .show();
    }

    // ---------------------------------------------------------------- Hình nền

    private void applyCustomAsync(final Opener opener) {
        final DisplayMetrics dm = getResources().getDisplayMetrics();
        new Thread(() -> {
            try {
                Bitmap bm = decodeCover(opener, dm.widthPixels, dm.heightPixels);
                if (bm == null) throw new IOException("decode");
                try (FileOutputStream os = new FileOutputStream(new File(getFilesDir(), "wallpaper.jpg"))) {
                    bm.compress(Bitmap.CompressFormat.JPEG, 90, os);
                }
                prefs.edit().putString("bg", "custom").apply();
                runOnUiThread(() -> {
                    applyBackground();
                    toast("Đã đổi hình nền");
                });
            } catch (Exception | OutOfMemoryError e) {
                runOnUiThread(() -> toast("Không đọc được ảnh này"));
            }
        }).start();
    }

    private Bitmap decodeCover(Opener opener, int w, int h) throws IOException {
        BitmapFactory.Options op = new BitmapFactory.Options();
        op.inJustDecodeBounds = true;
        try (InputStream is = opener.open()) {
            BitmapFactory.decodeStream(is, null, op);
        }
        int s = 1;
        while (op.outWidth / (s * 2) >= w && op.outHeight / (s * 2) >= h) s *= 2;
        op.inJustDecodeBounds = false;
        op.inSampleSize = s;
        Bitmap src;
        try (InputStream is = opener.open()) {
            src = BitmapFactory.decodeStream(is, null, op);
        }
        if (src == null) return null;

        float scale = Math.max((float) w / src.getWidth(), (float) h / src.getHeight());
        int cw = Math.min(src.getWidth(), Math.round(w / scale));
        int ch = Math.min(src.getHeight(), Math.round(h / scale));
        int x = Math.max(0, (src.getWidth() - cw) / 2);
        int y = Math.max(0, (src.getHeight() - ch) / 2);
        Bitmap crop = Bitmap.createBitmap(src, x, y, cw, ch);
        return Bitmap.createScaledBitmap(crop, w, h, true);
    }

    private void applyBackground() {
        String bg = prefs.getString("bg", "preset:0");
        Drawable d = null;
        if ("custom".equals(bg)) {
            File f = new File(getFilesDir(), "wallpaper.jpg");
            if (f.exists()) {
                Bitmap bm = BitmapFactory.decodeFile(f.getPath());
                if (bm != null) {
                    d = new LayerDrawable(new Drawable[]{
                            new BitmapDrawable(getResources(), bm),
                            new ColorDrawable(0x66000000)}); // phủ tối nhẹ cho dễ đọc chữ
                }
            }
        }
        if (d == null) {
            int idx = 0;
            try {
                if (bg.startsWith("preset:")) idx = Integer.parseInt(bg.substring(7));
            } catch (NumberFormatException ignored) {
            }
            if (idx < 0 || idx >= PRESET_COLORS.length) idx = 0;
            d = presetDrawable(PRESET_COLORS[idx]);
        }
        getWindow().setBackgroundDrawable(d);
    }

    private Drawable presetDrawable(int glow) {
        ColorDrawable base = new ColorDrawable(0xFF0D0D10);
        if (glow == 0) return base;
        GradientDrawable g = new GradientDrawable();
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g.setGradientRadius(getResources().getDisplayMetrics().widthPixels * 0.7f);
        g.setGradientCenter(0.35f, 0.30f);
        g.setColors(new int[]{glow, 0x00000000});
        return new LayerDrawable(new Drawable[]{base, g});
    }

    // ---------------------------------------------------------------- Màn hình chính

    private void updateHeader() {
        Calendar c = Calendar.getInstance();
        int h = c.get(Calendar.HOUR_OF_DAY);
        int res = h < 12 ? R.string.good_morning : (h < 18 ? R.string.good_afternoon : R.string.good_evening);
        Locale vi = new Locale("vi");
        greeting.setText(getString(res).toUpperCase(vi));
        String d = THU[c.get(Calendar.DAY_OF_WEEK) - 1] + ", " + c.get(Calendar.DAY_OF_MONTH)
                + " tháng " + (c.get(Calendar.MONTH) + 1);
        dateView.setText(d.toUpperCase(vi));
        lunarView.setText(LunarCalendar.format(c.get(Calendar.DAY_OF_MONTH),
                c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR)));
    }

    private List<AppItem> queryApps() {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> list = new ArrayList<>();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        list.addAll(pm.queryIntentActivities(i, 0));
        Intent j = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        list.addAll(pm.queryIntentActivities(j, 0));

        List<AppItem> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            AppItem a = new AppItem();
            a.pkg = pkg;
            a.cls = ri.activityInfo.name;
            a.label = String.valueOf(ri.loadLabel(pm));
            Drawable bn = ri.activityInfo.loadBanner(pm);
            a.banner = bn != null;
            a.image = bn != null ? bn : ri.loadIcon(pm);
            out.add(a);
        }
        Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return out;
    }

    private void loadApps() {
        List<AppItem> all = queryApps();
        List<AppItem> dockApps = new ArrayList<>();
        for (String key : DOCK_PREF) {
            for (AppItem a : all) {
                if (a.label.toLowerCase(Locale.ROOT).contains(key) && !dockApps.contains(a)) {
                    dockApps.add(a);
                    break;
                }
            }
        }
        for (AppItem a : all) {
            if (dockApps.size() >= 4) break;
            if (!dockApps.contains(a)) dockApps.add(a);
        }
        if (dockApps.size() > 4) dockApps = new ArrayList<>(dockApps.subList(0, 4));

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int inner = dm.widthPixels - 2 * dp(48) - 2 * dp(12);
        int margin = dp(8);
        int tileW = inner / 4 - 2 * margin;
        int tileH = tileW * 9 / 16;

        dock.removeAllViews();
        grid.removeAllViews();

        for (AppItem a : dockApps) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tileW, tileH);
            lp.setMargins(margin, margin, margin, margin);
            dock.addView(makeTile(a), lp);
        }
        for (AppItem a : all) {
            if (dockApps.contains(a)) continue;
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = tileW;
            lp.height = tileH;
            lp.setMargins(margin, margin, margin, margin);
            grid.addView(makeTile(a), lp);
        }
        if (dock.getChildCount() > 0) {
            quiet = true; // không phát tiếng khi tự động chọn ô đầu tiên
            dock.getChildAt(0).requestFocus();
            quiet = false;
        }
    }

    private View makeTile(final AppItem a) {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundResource(R.drawable.tile_bg);
        f.setClipToOutline(true);
        f.setFocusable(true);
        f.setClickable(true);
        f.setAlpha(TILE_ALPHA);

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(a.image);
        if (a.banner) {
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(dp(20), dp(12), dp(20), dp(12));
        }
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));

        f.setOnFocusChangeListener((v, has) -> {
            float s = has ? 1.08f : 1f;
            v.animate().scaleX(s).scaleY(s).alpha(has ? 1f : TILE_ALPHA).setDuration(120).start();
            v.setTranslationZ(has ? dp(8) : 0);
            ((FrameLayout) v).setForeground(has ? getDrawable(R.drawable.tile_focus) : null);
            if (has) {
                appName.setText(a.label);
                playMove();
            }
        });
        f.setOnClickListener(v -> {
            playSelect();
            Intent it = new Intent(Intent.ACTION_MAIN)
                    .setComponent(new ComponentName(a.pkg, a.cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(it);
            } catch (Exception ignored) {
            }
        });
        return f;
    }

    private void startSafe(Intent... intents) {
        for (Intent i : intents) {
            try {
                startActivity(i);
                return;
            } catch (ActivityNotFoundException | SecurityException ignored) {
            }
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
