package vn.launcher.tv;

import android.content.Context;
import android.view.View;
import android.widget.ScrollView;

/** ScrollView có chiều cao tối đa, dùng cho các khung cài đặt kiểu macOS. */
public class MaxHeightScrollView extends ScrollView {
    private int maxHeight = Integer.MAX_VALUE;

    public MaxHeightScrollView(Context c) {
        super(c);
    }

    public void setMaxHeight(int px) {
        maxHeight = px;
    }

    @Override
    protected void onMeasure(int w, int h) {
        int size = View.MeasureSpec.getSize(h);
        int limit = size > 0 ? Math.min(size, maxHeight) : maxHeight;
        super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(limit, View.MeasureSpec.AT_MOST));
    }
}
