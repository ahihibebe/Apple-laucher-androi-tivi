package vn.launcher.tv;

import android.service.notification.NotificationListenerService;

/** Dịch vụ rỗng: khi người dùng cấp quyền, launcher đọc được tên bài hát đang phát. */
public class MediaListener extends NotificationListenerService {
}
