package vn.launcher.tv;

import java.util.Calendar;

/** Tìm ngày lễ Việt Nam sắp tới (dương lịch và âm lịch). */
public final class Holidays {

    public static class Result {
        public int days;
        public String name;
    }

    // {ngày, tháng, tên Việt, tên Anh}
    private static final Object[][] SOLAR = {
            {1, 1, "Tết Dương lịch", "New Year's Day"},
            {8, 3, "Quốc tế Phụ nữ", "International Women's Day"},
            {30, 4, "Giải phóng miền Nam", "Reunification Day"},
            {1, 5, "Quốc tế Lao động", "Labour Day"},
            {1, 6, "Quốc tế Thiếu nhi", "Children's Day"},
            {2, 9, "Quốc khánh", "National Day"},
            {20, 10, "Ngày Phụ nữ Việt Nam", "Vietnamese Women's Day"},
            {20, 11, "Ngày Nhà giáo Việt Nam", "Teachers' Day"},
            {24, 12, "Giáng sinh", "Christmas"},
    };

    private static final Object[][] LUNAR = {
            {1, 1, "Tết Nguyên Đán", "Lunar New Year (Tết)"},
            {15, 1, "Rằm tháng Giêng", "Lantern Festival"},
            {10, 3, "Giỗ Tổ Hùng Vương", "Hùng Kings' Festival"},
            {15, 4, "Lễ Phật Đản", "Buddha's Birthday"},
            {5, 5, "Tết Đoan Ngọ", "Dragon Boat Festival"},
            {15, 7, "Lễ Vu Lan", "Vu Lan Festival"},
            {15, 8, "Tết Trung thu", "Mid-Autumn Festival"},
            {23, 12, "Ông Công Ông Táo", "Kitchen Gods Day"},
    };

    private Holidays() {
    }

    public static Result next(Calendar from, boolean en) {
        for (int d = 0; d <= 400; d++) {
            Calendar c = (Calendar) from.clone();
            c.add(Calendar.DAY_OF_MONTH, d);
            int dd = c.get(Calendar.DAY_OF_MONTH);
            int mm = c.get(Calendar.MONTH) + 1;
            int yy = c.get(Calendar.YEAR);
            for (Object[] h : SOLAR) {
                if ((Integer) h[0] == dd && (Integer) h[1] == mm) return make(d, h, en);
            }
            int[] l = LunarCalendar.solarToLunar(dd, mm, yy);
            if (l[3] == 0) {
                for (Object[] h : LUNAR) {
                    if ((Integer) h[0] == l[0] && (Integer) h[1] == l[1]) return make(d, h, en);
                }
            }
        }
        return null;
    }

    private static Result make(int days, Object[] h, boolean en) {
        Result r = new Result();
        r.days = days;
        r.name = (String) (en ? h[3] : h[2]);
        return r;
    }
}
