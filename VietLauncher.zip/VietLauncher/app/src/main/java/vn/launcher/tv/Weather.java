package vn.launcher.tv;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Locale;

/** Lấy vị trí (GPS/mạng nếu có quyền, nếu không thì theo IP) và dự báo từ Open-Meteo. */
final class Weather {

    static class Data {
        double temp, min, max;
        int code, rain;
        String city;
    }

    private Weather() {
    }

    static Data fetch(Context ctx, boolean en) throws Exception {
        double lat = Double.NaN, lon = Double.NaN;
        String city = null;

        Location loc = lastLocation(ctx);
        if (loc != null) {
            lat = loc.getLatitude();
            lon = loc.getLongitude();
            city = reverse(ctx, lat, lon, en);
        }
        JSONObject ip = null;
        if (Double.isNaN(lat) || city == null) {
            try {
                ip = ipLocation();
            } catch (Exception e) {
                if (Double.isNaN(lat)) throw e;
            }
            if (ip != null) {
                if (Double.isNaN(lat)) {
                    lat = ip.getDouble("latitude");
                    lon = ip.getDouble("longitude");
                }
                if (city == null) city = ip.optString("city", "");
            }
        }

        String url = String.format(Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                        + "&current=temperature_2m,weather_code"
                        + "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max"
                        + "&timezone=auto&forecast_days=1", lat, lon);
        JSONObject j = new JSONObject(get(url));
        JSONObject cur = j.getJSONObject("current");
        JSONObject daily = j.getJSONObject("daily");

        Data d = new Data();
        d.temp = cur.getDouble("temperature_2m");
        d.code = cur.getInt("weather_code");
        d.min = daily.getJSONArray("temperature_2m_min").getDouble(0);
        d.max = daily.getJSONArray("temperature_2m_max").getDouble(0);
        JSONArray rain = daily.optJSONArray("precipitation_probability_max");
        d.rain = (rain != null && !rain.isNull(0)) ? rain.getInt(0) : 0;
        d.city = city == null ? "" : city;
        return d;
    }

    private static Location lastLocation(Context ctx) {
        try {
            if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return null;
            }
            LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return null;
            Location best = null;
            for (String p : lm.getProviders(true)) {
                try {
                    Location l = lm.getLastKnownLocation(p);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (SecurityException ignored) {
                }
            }
            return best;
        } catch (Exception e) {
            return null;
        }
    }

    @SuppressWarnings("deprecation")
    private static String reverse(Context ctx, double lat, double lon, boolean en) {
        try {
            if (!Geocoder.isPresent()) return null;
            Geocoder g = new Geocoder(ctx, en ? Locale.ENGLISH : new Locale("vi"));
            List<Address> list = g.getFromLocation(lat, lon, 1);
            if (list != null && !list.isEmpty()) {
                Address a = list.get(0);
                String s = a.getSubAdminArea();
                if (s == null) s = a.getLocality();
                if (s == null) s = a.getAdminArea();
                return s;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static JSONObject ipLocation() throws Exception {
        try {
            JSONObject o = new JSONObject(get("https://ipwho.is/"));
            if (o.has("latitude") && o.optBoolean("success", true)) return o;
        } catch (Exception ignored) {
        }
        JSONObject o = new JSONObject(get("https://ipapi.co/json/"));
        if (!o.has("latitude")) throw new IOException("no ip location");
        return o;
    }

    private static String get(String u) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "VietLauncher/1.0");
            try (InputStream is = c.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                return bo.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }

    /** @return {emoji, mô tả} theo mã thời tiết WMO */
    static String[] describe(int c, boolean en) {
        if (c == 0) return new String[]{"☀️", en ? "Sunny" : "Nắng"};
        if (c == 1 || c == 2) return new String[]{"⛅", en ? "Partly cloudy" : "Ít mây"};
        if (c == 3) return new String[]{"☁️", en ? "Cloudy" : "Nhiều mây"};
        if (c == 45 || c == 48) return new String[]{"🌫️", en ? "Fog" : "Sương mù"};
        if (c >= 51 && c <= 57) return new String[]{"🌦️", en ? "Drizzle" : "Mưa phùn"};
        if (c >= 61 && c <= 67) return new String[]{"🌧️", en ? "Rain" : "Mưa"};
        if (c >= 71 && c <= 77) return new String[]{"❄️", en ? "Snow" : "Tuyết"};
        if (c >= 80 && c <= 82) return new String[]{"🌧️", en ? "Showers" : "Mưa rào"};
        if (c == 85 || c == 86) return new String[]{"❄️", en ? "Snow showers" : "Mưa tuyết"};
        if (c >= 95) return new String[]{"⛈️", en ? "Thunderstorm" : "Giông bão"};
        return new String[]{"🌡️", "—"};
    }
}
