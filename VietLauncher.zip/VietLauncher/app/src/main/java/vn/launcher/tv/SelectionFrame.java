package vn.launcher.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Khung viền sáng (LED) phủ lên nội dung; di chuyển/đổi kích thước bằng cách vẽ lại nên rất nhẹ. */
public class SelectionFrame extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float rx, ry, rw, rh;
    private float radius = 14f;
    private float stroke = 3f;
    private int color = 0xFFFFFFFF;

    public SelectionFrame(Context c) {
        super(c);
        paint.setStyle(Paint.Style.STROKE);
        glow.setStyle(Paint.Style.STROKE);
        setWillNotDraw(false);
    }

    public void setStrokeWidth(float px) {
        stroke = px;
        invalidate();
    }

    public void setRadius(float px) {
        radius = px;
        invalidate();
    }

    public void setColor(int c) {
        color = c;
        invalidate();
    }

    public void setRect(float x, float y, float w, float h) {
        rx = x;
        ry = y;
        rw = w;
        rh = h;
        invalidate();
    }

    public float[] getRect() {
        return new float[]{rx, ry, rw, rh};
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (rw <= 0 || rh <= 0) return;
        glow.setStrokeWidth(stroke * 3f);
        glow.setColor((color & 0x00FFFFFF) | 0x40000000);
        canvas.drawRoundRect(rx, ry, rx + rw, ry + rh, radius, radius, glow);
        paint.setStrokeWidth(stroke);
        paint.setColor(color);
        float half = stroke / 2f;
        canvas.drawRoundRect(rx + half, ry + half, rx + rw - half, ry + rh - half, radius, radius, paint);
    }
}
