package vn.launcher.tv;

import java.text.Normalizer;
import java.util.Locale;

/** Xử lý câu lệnh giọng nói: bỏ dấu, bỏ động từ ("mở", "open"...), đổi chữ số, chấm điểm khớp tên ứng dụng. */
final class VoiceCommand {

    private static final String[] VERBS = {
            "mo ung dung", "mo kenh", "bat kenh", "chuyen sang kenh", "chuyen sang", "chuyen den", "chuyen kenh",
            "xem kenh", "khoi dong", "mo", "bat", "chay", "xem", "kenh",
            "open app", "open", "launch", "start", "go to", "switch to", "watch channel", "watch", "play",
            "channel"};

    private static final String[] WORDS = {"khong", "mot", "hai", "ba", "bon", "nam", "sau", "bay", "tam", "chin",
            "muoi", "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"};
    private static final int[] VALUES = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    private VoiceCommand() {
    }

    static String norm(String s) {
        String t = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replace('đ', 'd');
        return t.replaceAll("[^a-z0-9]+", " ").trim();
    }

    /** Bỏ động từ ở đầu câu: "mo fpt" → "fpt". */
    static String stripVerb(String n) {
        String t = n.trim();
        boolean changed = true;
        while (changed) {
            changed = false;
            for (String v : VERBS) {
                if (t.equals(v)) return "";
                if (t.startsWith(v + " ")) {
                    t = t.substring(v.length() + 1).trim();
                    changed = true;
                    break;
                }
            }
        }
        return t;
    }

    /** "vtv mot" → "vtv 1" (khi nhận dạng trả chữ thay vì số). */
    static String digitWords(String n) {
        String[] w = n.split(" ");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < w.length; i++) {
            String x = w[i];
            if (i > 0) {
                for (int k = 0; k < WORDS.length; k++) {
                    if (x.equals(WORDS[k])) {
                        x = String.valueOf(VALUES[k]);
                        break;
                    }
                }
            }
            if (sb.length() > 0) sb.append(' ');
            sb.append(x);
        }
        return sb.toString();
    }

    /** "vtv 1" → "vtv1" */
    static String key(String n) {
        return n.replace(" ", "");
    }

    /** Điểm khớp giữa tên ứng dụng (đã chuẩn hóa) và cụm người dùng nói. */
    static int score(String label, String q) {
        if (q.isEmpty() || label.isEmpty()) return 0;
        if (label.equals(q)) return 100;
        if (q.length() >= 2 && label.startsWith(q + " ")) return 85;
        if (q.length() >= 2 && label.startsWith(q)) return 80;
        if (q.length() >= 3 && label.contains(q)) return 60;
        if (label.length() >= 3 && q.contains(label)) return 55;
        return 0;
    }
}
