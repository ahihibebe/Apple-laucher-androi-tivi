package vn.launcher.tv;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/** Xử lý câu lệnh giọng nói: bỏ dấu, bỏ động từ ("mở", "open"...), đổi chữ số, chấm điểm khớp tên ứng dụng. */
final class VoiceCommand {

    private static final String[] VERBS = {
            "mo ung dung", "mo kenh", "bat kenh", "chuyen sang kenh", "chuyen sang", "chuyen den", "chuyen kenh",
            "xem kenh", "khoi dong", "mo", "bat", "chay", "xem", "kenh",
            "open app", "open", "launch", "start", "go to", "switch to", "watch channel", "watch", "play",
            "channel"};

    private static final String[] WORDS = {"khong", "mot", "hai", "ba", "bon", "nam", "sau", "bay", "tam", "chin",
            "muoi", "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"};
    private static final int[] VALUES = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    private VoiceCommand() {
    }

    static String norm(String s) {
        String t = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replace('đ', 'd');
        return t.replaceAll("[^a-z0-9]+", " ").trim();
    }

    /** Bỏ động từ ở đầu câu: "mo fpt" → "fpt". */
    static String stripVerb(String n) {
        String t = n.trim();
        boolean changed = true;
        while (changed) {
            changed = false;
            for (String v : VERBS) {
                if (t.equals(v)) return "";
                if (t.startsWith(v + " ")) {
                    t = t.substring(v.length() + 1).trim();
                    changed = true;
                    break;
                }
            }
        }
        return t;
    }

    /** "vtv mot" → "vtv 1" (khi nhận dạng trả chữ thay vì số). */
    static String digitWords(String n) {
        String[] w = n.split(" ");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < w.length; i++) {
            String x = w[i];
            if (i > 0) {
                for (int k = 0; k < WORDS.length; k++) {
                    if (x.equals(WORDS[k])) {
                        x = String.valueOf(VALUES[k]);
                        break;
                    }
                }
            }
            if (sb.length() > 0) sb.append(' ');
            sb.append(x);
        }
        return sb.toString();
    }

    /** "vtv 1" → "vtv1" */
    static String key(String n) {
        return n.replace(" ", "");
    }

    /** Điểm khớp giữa tên ứng dụng (đã chuẩn hóa) và cụm người dùng nói. */
    static int score(String label, String q) {
        if (q.isEmpty() || label.isEmpty()) return 0;
        if (label.equals(q)) return 100;
        if (q.length() >= 2 && label.startsWith(q + " ")) return 85;
        if (q.length() >= 2 && label.startsWith(q)) return 80;
        if (q.length() >= 3 && label.contains(q)) return 60;
        if (label.length() >= 3 && q.contains(label)) return 55;
        return 0;
    }

    // ------------------------------------------------------------ cụm từ, bí danh

    /** Câu nói có chứa một trong các cụm (đã chuẩn hóa, tách theo từ). */
    static boolean has(String full, String... phrases) {
        String f = " " + full + " ";
        for (String p : phrases) if (f.contains(" " + p + " ")) return true;
        return false;
    }

    private static final String[][] APP_ALIASES = {
            {"tizentube", "tizen", "tizentube"},
            {"getout", "getout"},
            {"googleplay", "googleplay", "chplay", "cuahangplay", "playstore", "cuahanggoogleplay", "googleplaystore"},
            {"vietmitv", "vietmitv", "vietmi"},
            {"vtvgo", "vtvgo", "vtvgotv"}};

    /** Tên ứng dụng viết liền/tách đều về một dạng chuẩn: "tizen tube" → "tizentube", "ch play" → "googleplay". */
    static String canonApp(String key) {
        for (String[] a : APP_ALIASES) {
            for (int i = 1; i < a.length; i++) if (a[i].equals(key)) return a[0];
        }
        return key;
    }

    /** Điểm khớp khi bỏ hết khoảng trắng ở cả hai phía ("get out" = "getout"). */
    static int scoreKeys(String lk, String qk) {
        if (lk.isEmpty() || qk.isEmpty()) return 0;
        if (lk.equals(qk)) return 100;
        if (qk.length() >= 3 && lk.startsWith(qk)) return 85;
        if (lk.length() >= 3 && qk.startsWith(lk)) return 80;
        if (qk.length() >= 4 && lk.contains(qk)) return 65;
        if (lk.length() >= 4 && qk.contains(lk)) return 60;
        return 0;
    }

    private static final Pattern VINH_LONG = Pattern.compile("^(?:truyen hinh |tv |dai |kenh )?vinh long (\\d)$");

    /** "vĩnh long 1", "truyền hình vĩnh long 2" → "thvl1", "thvl2". */
    static String canonChannel(String n) {
        String t = n.trim();
        java.util.regex.Matcher m = VINH_LONG.matcher(t);
        if (m.matches()) return "thvl" + m.group(1);
        return t;
    }
}
