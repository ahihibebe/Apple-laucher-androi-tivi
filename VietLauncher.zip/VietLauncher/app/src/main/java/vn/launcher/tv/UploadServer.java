package vn.launcher.tv;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Máy chủ HTTP rất nhỏ chỉ chạy khi cửa sổ mã QR đang mở. Điện thoại quét mã, mở trang, chọn ảnh và gửi lên.
 * Đường dẫn có mã ngẫu nhiên dùng một lần cho mỗi lần mở, ảnh tối đa 30 MB.
 */
final class UploadServer {

    interface Listener {
        void onImage(byte[] data);
    }

    private static final int MAX_BYTES = 30 * 1024 * 1024;

    private final String token;
    private final String page;
    private final Listener listener;
    private ServerSocket server;
    private volatile boolean running;

    UploadServer(String token, String page, Listener listener) {
        this.token = token;
        this.page = page;
        this.listener = listener;
    }

    int start() throws IOException {
        server = new ServerSocket(0, 4);
        running = true;
        final ServerSocket ss = server;
        Thread t = new Thread(() -> {
            while (running) {
                try {
                    Socket s = ss.accept();
                    handle(s);
                } catch (IOException e) {
                    if (!running) break;
                }
            }
        });
        t.setDaemon(true);
        t.start();
        return server.getLocalPort();
    }

    void stop() {
        running = false;
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
        }
    }

    private void handle(Socket sock) {
        try {
            sock.setSoTimeout(15000);
            InputStream in = sock.getInputStream();
            OutputStream out = sock.getOutputStream();
            String reqLine = readLine(in);
            if (reqLine == null) return;
            String[] parts = reqLine.split(" ");
            String method = parts.length > 0 ? parts[0] : "";
            String path = parts.length > 1 ? parts[1] : "";
            int len = 0;
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                int c = line.indexOf(':');
                if (c > 0 && line.substring(0, c).trim().equalsIgnoreCase("content-length")) {
                    try {
                        len = Integer.parseInt(line.substring(c + 1).trim());
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
            if ("GET".equals(method) && path.equals("/" + token)) {
                respond(out, 200, "OK", "text/html; charset=utf-8", page.getBytes(StandardCharsets.UTF_8));
            } else if ("POST".equals(method) && path.equals("/" + token + "/up")) {
                if (len <= 0 || len > MAX_BYTES) {
                    respond(out, 413, "Payload Too Large", "text/plain", "too large".getBytes(StandardCharsets.UTF_8));
                    return;
                }
                byte[] data = new byte[len];
                int off = 0;
                while (off < len) {
                    int r = in.read(data, off, len - off);
                    if (r < 0) break;
                    off += r;
                }
                if (off != len) {
                    respond(out, 400, "Bad Request", "text/plain", "incomplete".getBytes(StandardCharsets.UTF_8));
                    return;
                }
                respond(out, 200, "OK", "text/plain", "OK".getBytes(StandardCharsets.UTF_8));
                listener.onImage(data);
            } else {
                respond(out, 404, "Not Found", "text/plain", "not found".getBytes(StandardCharsets.UTF_8));
            }
        } catch (IOException ignored) {
        } finally {
            try {
                sock.close();
            } catch (IOException ignored) {
            }
        }
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        int b;
        while ((b = in.read()) != -1) {
            if (b == '\n') break;
            if (b != '\r') bo.write(b);
            if (bo.size() > 8192) throw new IOException("line too long");
        }
        if (b == -1 && bo.size() == 0) return null;
        return bo.toString("UTF-8");
    }

    private static void respond(OutputStream out, int code, String text, String type, byte[] body)
            throws IOException {
        String head = "HTTP/1.1 " + code + " " + text + "\r\n"
                + "Content-Type: " + type + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.UTF_8));
        out.write(body);
        out.flush();
    }
}
