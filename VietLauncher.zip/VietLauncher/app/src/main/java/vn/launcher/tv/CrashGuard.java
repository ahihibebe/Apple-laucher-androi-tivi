package vn.launcher.tv;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Ghi lại lỗi của launcher vào file để lần mở sau hiển thị, thay vì chỉ đen màn hình. */
final class CrashGuard {

    private CrashGuard() {
    }

    private static File file(Context c) {
        return new File(c.getFilesDir(), "crash.txt");
    }

    static void install(final Context app) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            record(app, e);
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    static void record(Context c, Throwable e) {
        try (PrintWriter w = new PrintWriter(new FileWriter(file(c), false))) {
            w.println(System.currentTimeMillis());
            e.printStackTrace(w);
        } catch (Exception ignored) {
        }
    }

    /** Nội dung lỗi gần nhất (không gồm dòng thời gian) hoặc null. */
    static String read(Context c) {
        File f = file(c);
        if (!f.exists()) return null;
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            r.readLine();
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.length() == 0 ? null : sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    static boolean recent(Context c, long withinMs) {
        File f = file(c);
        if (!f.exists()) return false;
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            long t = Long.parseLong(r.readLine().trim());
            return System.currentTimeMillis() - t < withinMs;
        } catch (Exception e) {
            return false;
        }
    }

    static void clear(Context c) {
        try {
            //noinspection ResultOfMethodCallIgnored
            file(c).delete();
        } catch (Exception ignored) {
        }
    }

    static String firstLines(String s, int n) {
        StringBuilder sb = new StringBuilder();
        String[] lines = s.split("\n");
        for (int i = 0; i < lines.length && i < n; i++) sb.append(lines[i]).append('\n');
        return sb.toString();
    }

    static String trace(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }
}
