package vn.launcher.tv;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.Collator;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Đơn vị hành chính Việt Nam sau sáp nhập (34 tỉnh/thành, không còn cấp huyện) để chọn vị trí thời tiết.
 * 34 tỉnh/thành có sẵn trong app (kèm tọa độ thành phố đại diện); phường/xã tải theo từng tỉnh từ
 * provinces.open-api.vn rồi lưu lại để dùng khi không có mạng. Tọa độ phường/xã lấy từ OpenStreetMap Nominatim.
 */
final class AdminData {

    static class Province {
        final String name;
        final int code;
        final double lat;
        final double lon;

        Province(String name, int code, double lat, double lon) {
            this.name = name;
            this.code = code;
            this.lat = lat;
            this.lon = lon;
        }

        String shortName() {
            return name.replaceFirst("^(Thành phố|Tỉnh) ", "");
        }
    }

    static class Ward {
        String name = "";
        int code;
    }

    // Tọa độ: thành phố đại diện của tỉnh (dùng khi chưa chọn phường/xã).
    static final Province[] PROVINCES = {
            new Province("Thành phố Hà Nội", 1, 21.03, 105.85),
            new Province("Tỉnh Cao Bằng", 4, 22.67, 106.26),
            new Province("Tỉnh Tuyên Quang", 8, 21.82, 105.21),
            new Province("Tỉnh Điện Biên", 11, 21.39, 103.02),
            new Province("Tỉnh Lai Châu", 12, 22.40, 103.46),
            new Province("Tỉnh Sơn La", 14, 21.33, 103.91),
            new Province("Tỉnh Lào Cai", 15, 22.48, 103.97),
            new Province("Tỉnh Thái Nguyên", 19, 21.59, 105.84),
            new Province("Tỉnh Lạng Sơn", 20, 21.85, 106.76),
            new Province("Tỉnh Quảng Ninh", 22, 20.95, 107.08),
            new Province("Tỉnh Bắc Ninh", 24, 21.19, 106.07),
            new Province("Tỉnh Phú Thọ", 25, 21.32, 105.40),
            new Province("Thành phố Hải Phòng", 31, 20.86, 106.68),
            new Province("Tỉnh Hưng Yên", 33, 20.65, 106.05),
            new Province("Tỉnh Ninh Bình", 37, 20.25, 105.97),
            new Province("Tỉnh Thanh Hóa", 38, 19.81, 105.78),
            new Province("Tỉnh Nghệ An", 40, 18.68, 105.69),
            new Province("Tỉnh Hà Tĩnh", 42, 18.34, 105.91),
            new Province("Tỉnh Quảng Trị", 44, 17.47, 106.62),
            new Province("Thành phố Huế", 46, 16.46, 107.59),
            new Province("Thành phố Đà Nẵng", 48, 16.05, 108.21),
            new Province("Tỉnh Quảng Ngãi", 51, 15.12, 108.80),
            new Province("Tỉnh Gia Lai", 52, 13.78, 109.22),
            new Province("Tỉnh Khánh Hòa", 56, 12.24, 109.19),
            new Province("Tỉnh Đắk Lắk", 66, 12.67, 108.04),
            new Province("Tỉnh Lâm Đồng", 68, 11.94, 108.44),
            new Province("Tỉnh Đồng Nai", 75, 10.96, 106.84),
            new Province("Thành phố Hồ Chí Minh", 79, 10.78, 106.70),
            new Province("Tỉnh Tây Ninh", 80, 11.31, 106.10),
            new Province("Tỉnh Đồng Tháp", 82, 10.46, 105.63),
            new Province("Tỉnh Vĩnh Long", 86, 10.25, 105.97),
            new Province("Tỉnh An Giang", 91, 10.37, 105.43),
            new Province("Thành phố Cần Thơ", 92, 10.03, 105.78),
            new Province("Tỉnh Cà Mau", 96, 9.18, 105.15)};

    private AdminData() {
    }

    static Province byName(String name) {
        if (name == null || name.isEmpty()) return null;
        for (Province p : PROVINCES) if (p.name.equals(name)) return p;
        return null;
    }

    /** Bỏ dấu, chữ thường, bỏ tiền tố "Tỉnh/Thành phố" để so tên. */
    static String norm(String s) {
        String t = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).replace('đ', 'd');
        return t.replaceAll("^(thanh pho|tinh)\\s+", "").trim();
    }

    // ------------------------------------------------------------ phường / xã

    static List<Ward> loadWards(Context ctx, Province p) throws Exception {
        File cache = new File(ctx.getFilesDir(), "wards_" + p.code + ".json");
        JSONArray arr = null;
        if (cache.exists()) {
            try {
                arr = new JSONArray(readFile(cache));
            } catch (Exception ignored) {
            }
        }
        if (arr == null || arr.length() == 0) {
            arr = fetchWards(p.code, p.name);
            if (arr == null || arr.length() == 0) {      // mã không khớp → tra mã theo tên
                int c2 = findCodeByName(p.name);
                if (c2 > 0 && c2 != p.code) arr = fetchWards(c2, p.name);
            }
            if (arr == null || arr.length() == 0) throw new IOException("no wards");
            try (FileOutputStream os = new FileOutputStream(cache)) {
                os.write(arr.toString().getBytes("UTF-8"));
            } catch (Exception ignored) {
            }
        }
        List<Ward> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Ward w = new Ward();
            w.name = o.optString("name", "");
            w.code = o.optInt("code");
            if (!w.name.isEmpty()) out.add(w);
        }
        final Collator col = Collator.getInstance(new Locale("vi"));
        Collections.sort(out, (a, b) -> col.compare(a.name, b.name));
        return out;
    }

    private static JSONArray fetchWards(int code, String expectName) throws Exception {
        JSONObject o = new JSONObject(get("https://provinces.open-api.vn/api/v2/p/" + code + "?depth=2"));
        if (!norm(o.optString("name")).equals(norm(expectName))) return null;
        JSONArray wards = o.optJSONArray("wards");
        if (wards == null) return null;
        JSONArray slim = new JSONArray();
        for (int i = 0; i < wards.length(); i++) {
            JSONObject w = wards.getJSONObject(i);
            JSONObject n = new JSONObject();
            n.put("name", w.optString("name", ""));
            n.put("code", w.optInt("code"));
            slim.put(n);
        }
        return slim;
    }

    private static int findCodeByName(String name) {
        try {
            JSONArray a = new JSONArray(get("https://provinces.open-api.vn/api/v2/"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (norm(o.optString("name")).equals(norm(name))) return o.optInt("code");
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

    // ------------------------------------------------------------ tọa độ

    /** @return {vĩ độ, kinh độ} hoặc null nếu không tìm thấy. */
    static double[] geocode(String query) {
        try {
            String url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=vn"
                    + "&accept-language=vi&q=" + URLEncoder.encode(query, "UTF-8");
            JSONArray a = new JSONArray(get(url));
            if (a.length() > 0) {
                JSONObject o = a.getJSONObject(0);
                return new double[]{Double.parseDouble(o.getString("lat")), Double.parseDouble(o.getString("lon"))};
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    // ------------------------------------------------------------ tiện ích

    private static String readFile(File f) throws IOException {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private static String get(String u) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            c.setRequestProperty("User-Agent", "VietLauncher/2.0 (Android TV launcher)");
            c.setRequestProperty("Accept", "application/json");
            try (InputStream is = c.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                return bo.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }
}
