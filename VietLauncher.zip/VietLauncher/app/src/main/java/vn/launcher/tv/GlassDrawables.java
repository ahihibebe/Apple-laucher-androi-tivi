package vn.launcher.tv;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * "Kính lỏng" (Liquid Glass) vẽ bằng nhiều lớp: nền kính có màu, ánh sáng phản chiếu ở nửa trên,
 * ánh khúc xạ ở đáy và viền sáng chuyển màu. Quả cầu bóng dùng cho biểu tượng tròn.
 */
final class GlassDrawables {

    private GlassDrawables() {
    }

    static Drawable panel(float radiusPx, int topTint, int bottomTint, float strokePx) {
        return new Panel(radiusPx, topTint, bottomTint, strokePx);
    }

    static Drawable orb(int color) {
        return new Orb(color);
    }

    static int lighten(int c, float f) {
        int a = c >>> 24;
        int r = (c >> 16) & 0xFF;
        int g = (c >> 8) & 0xFF;
        int b = c & 0xFF;
        r += (int) ((255 - r) * f);
        g += (int) ((255 - g) * f);
        b += (int) ((255 - b) * f);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    static int darken(int c, float f) {
        int a = c >>> 24;
        int r = (int) (((c >> 16) & 0xFF) * (1 - f));
        int g = (int) (((c >> 8) & 0xFF) * (1 - f));
        int b = (int) ((c & 0xFF) * (1 - f));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static class Panel extends Drawable {
        private final float radius;
        private final float stroke;
        private final int top;
        private final int bottom;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private float r;
        private int alpha = 255;

        Panel(float radius, int top, int bottom, float stroke) {
            this.radius = radius;
            this.top = top;
            this.bottom = bottom;
            this.stroke = Math.max(1f, stroke);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(this.stroke);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            float half = stroke / 2f;
            rect.set(b.left + half, b.top + half, b.right - half, b.bottom - half);
            r = Math.max(0f, Math.min(radius, Math.min(rect.width(), rect.height()) / 2f));
            fill.setShader(new LinearGradient(0, b.top, 0, b.bottom, top, bottom, Shader.TileMode.CLAMP));
            sheen.setShader(new LinearGradient(0, b.top, 0, b.top + b.height() * 0.6f,
                    0x73FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            glow.setShader(new LinearGradient(0, b.bottom, 0, b.bottom - b.height() * 0.4f,
                    0x4DFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            rim.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                    0xD9FFFFFF, 0x4DFFFFFF, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            if (rect.isEmpty()) return;
            fill.setAlpha(alpha);
            sheen.setAlpha(alpha);
            glow.setAlpha(alpha);
            rim.setAlpha(alpha);
            c.drawRoundRect(rect, r, r, fill);
            c.drawRoundRect(rect, r, r, sheen);
            c.drawRoundRect(rect, r, r, glow);
            c.drawRoundRect(rect, r, r, rim);
        }

        @Override
        public void getOutline(Outline outline) {
            Rect b = getBounds();
            outline.setRoundRect(b, Math.min(radius, Math.min(b.width(), b.height()) / 2f));
        }

        @Override
        public void setAlpha(int a) {
            alpha = a;
            invalidateSelf();
        }

        @Override
        public void setColorFilter(ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    private static class Orb extends Drawable {
        private final int color;
        private final Paint base = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF shineRect = new RectF();
        private float cx;
        private float cy;
        private float r;
        private int alpha = 255;

        Orb(int color) {
            this.color = color;
            rim.setStyle(Paint.Style.STROKE);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            cx = b.exactCenterX();
            cy = b.exactCenterY();
            r = Math.max(0f, Math.min(b.width(), b.height()) / 2f - 0.5f);
            base.setShader(new RadialGradient(cx - r * 0.25f, cy - r * 0.45f, Math.max(1f, r * 1.5f),
                    new int[]{lighten(color, 0.45f), color, darken(color, 0.3f)},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            shineRect.set(cx - r * 0.62f, cy - r * 0.92f, cx + r * 0.62f, cy - r * 0.08f);
            shine.setShader(new LinearGradient(0, shineRect.top, 0, shineRect.bottom,
                    0xCCFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            float sw = Math.max(1f, r * 0.07f);
            rim.setStrokeWidth(sw);
            rim.setShader(new LinearGradient(cx - r, cy - r, cx + r, cy + r,
                    0xB3FFFFFF, 0x33FFFFFF, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            if (r <= 0f) return;
            base.setAlpha(alpha);
            shine.setAlpha(alpha);
            rim.setAlpha(alpha);
            c.drawCircle(cx, cy, r, base);
            c.drawOval(shineRect, shine);
            c.drawCircle(cx, cy, Math.max(0f, r - rim.getStrokeWidth() / 2f), rim);
        }

        @Override
        public void getOutline(Outline outline) {
            outline.setOval(getBounds());
        }

        @Override
        public void setAlpha(int a) {
            alpha = a;
            invalidateSelf();
        }

        @Override
        public void setColorFilter(ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}
