package vn.launcher.tv;

import android.content.Context;

import java.io.File;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Chạy lệnh shell qua ADB nội bộ: launcher tự kết nối tới adbd của chính TV (localhost:5555).
 * Cần bật "Gỡ lỗi qua mạng" trên TV; lần đầu TV sẽ hỏi cho phép gỡ lỗi (chọn "Luôn cho phép").
 */
final class AdbLocal {

    private AdbLocal() {
    }

    static synchronized String shell(Context ctx, String command) throws Exception {
        Class<?> dadbClass = Class.forName("dadb.Dadb");
        Object dadb = connect(ctx, dadbClass);
        try {
            Object resp = dadbClass.getMethod("shell", String.class).invoke(dadb, command);
            Object out = resp.getClass().getMethod("getOutput").invoke(resp);
            return out == null ? "" : String.valueOf(out);
        } finally {
            try {
                ((AutoCloseable) dadb).close();
            } catch (Exception ignored) {
            }
        }
    }

    private static Object connect(Context ctx, Class<?> dadbClass) throws Exception {
        File home = ctx.getFilesDir();
        new File(home, ".android").mkdirs();
        System.setProperty("user.home", home.getAbsolutePath());
        try {
            // Cách 1: khóa tự tạo trong thư mục riêng của ứng dụng
            return callStatic(dadbClass, "create", new Class<?>[]{String.class, int.class},
                    new Object[]{"localhost", 5555});
        } catch (NoSuchMethodException e) {
            // Cách 2: tự tạo / đọc khóa rồi truyền vào
            Class<?> kp = Class.forName("dadb.AdbKeyPair");
            File priv = new File(home, "adbkey");
            File pub = new File(home, "adbkey.pub");
            if (!priv.exists() || !pub.exists()) {
                callStatic(kp, "generate", new Class<?>[]{File.class, File.class}, new Object[]{priv, pub});
            }
            Object keyPair = callStatic(kp, "read", new Class<?>[]{File.class, File.class},
                    new Object[]{priv, pub});
            return callStatic(dadbClass, "create", new Class<?>[]{String.class, int.class, kp},
                    new Object[]{"localhost", 5555, keyPair});
        }
    }

    /** Gọi hàm static của lớp Kotlin: hàm @JvmStatic hoặc hàm trong Companion. */
    private static Object callStatic(Class<?> c, String name, Class<?>[] types, Object[] args)
            throws Exception {
        try {
            Method m = c.getMethod(name, types);
            if (Modifier.isStatic(m.getModifiers())) return m.invoke(null, args);
        } catch (NoSuchMethodException ignored) {
        }
        Object companion = c.getField("Companion").get(null);
        return companion.getClass().getMethod(name, types).invoke(companion, args);
    }
}
