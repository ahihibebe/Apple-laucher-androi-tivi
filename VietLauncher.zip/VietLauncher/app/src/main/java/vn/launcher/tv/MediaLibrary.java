package vn.launcher.tv;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Đọc danh sách nhạc/ảnh từ MediaStore (bộ nhớ máy + USB); nếu trống thì quét thư mục trực tiếp. */
final class MediaLibrary {

    static class Track {
        String title = "";
        String artist = "";
        Uri uri;
        long duration;
    }

    static class Album {
        String id;
        String name;
        int count;
    }

    private static final String[] AUDIO_EXT = {".mp3", ".m4a", ".aac", ".flac", ".wav", ".ogg", ".opus", ".wma"};
    private static final String[] IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"};

    private MediaLibrary() {
    }

    // ------------------------------------------------------------ nhạc

    static List<Track> loadTracks(Context ctx) {
        return loadTracks(ctx, false);
    }

    /** deep = true: ngoài MediaStore còn quét thư mục để thấy cả file USB chưa được hệ thống lập chỉ mục. */
    @SuppressWarnings("deprecation")
    static List<Track> loadTracks(Context ctx, boolean deep) {
        List<Track> out = new ArrayList<>();
        Set<String> known = new HashSet<>();
        try (Cursor c = ctx.getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION,
                        MediaStore.Audio.Media.DATA},
                MediaStore.Audio.Media.IS_MUSIC + " != 0", null,
                MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (c != null) {
                while (c.moveToNext() && out.size() < 3000) {
                    Track t = new Track();
                    t.uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0));
                    String title = c.getString(1);
                    t.title = title == null ? "" : title;
                    String artist = c.getString(2);
                    t.artist = (artist == null || "<unknown>".equals(artist)) ? "" : artist;
                    t.duration = c.getLong(3);
                    String data = c.getString(4);
                    if (data != null) known.add(data);
                    out.add(t);
                }
            }
        } catch (Throwable ignored) {
        }
        if (out.isEmpty() || deep) {
            for (File f : scan(AUDIO_EXT, 3000)) {
                if (out.size() >= 3000) break;
                if (known.contains(f.getAbsolutePath())) continue;
                Track t = new Track();
                t.uri = Uri.fromFile(f);
                String n = f.getName();
                int dot = n.lastIndexOf('.');
                t.title = dot > 0 ? n.substring(0, dot) : n;
                out.add(t);
            }
            Collections.sort(out, (x, y) -> x.title.compareToIgnoreCase(y.title));
        }
        return out;
    }

    /** Ảnh bìa nhúng trong file nhạc, hoặc null. */
    static Bitmap loadCover(Context ctx, Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, uri);
            byte[] art = r.getEmbeddedPicture();
            if (art == null) return null;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(art, 0, art.length, o);
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 512) s *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = s;
            return BitmapFactory.decodeByteArray(art, 0, art.length, o);
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                r.release();
            } catch (Throwable ignored) {
            }
        }
    }

    static String formatTime(long ms) {
        long s = Math.max(0, ms) / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    // ------------------------------------------------------------ ảnh

    static List<Album> loadAlbums(Context ctx) {
        Map<String, Album> map = new LinkedHashMap<>();
        try (Cursor c = ctx.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media.BUCKET_ID, MediaStore.Images.Media.BUCKET_DISPLAY_NAME},
                null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    if (id == null) continue;
                    Album a = map.get(id);
                    if (a == null) {
                        a = new Album();
                        a.id = id;
                        String name = c.getString(1);
                        a.name = name == null ? "?" : name;
                        map.put(id, a);
                    }
                    a.count++;
                }
            }
        } catch (Throwable ignored) {
        }
        List<Album> out = new ArrayList<>(map.values());
        Collections.sort(out, (x, y) -> x.name.compareToIgnoreCase(y.name));
        return out;
    }

    /** Danh sách ảnh; ids rỗng = tất cả ảnh. */
    static List<Uri> loadImages(Context ctx, Set<String> ids) {
        List<Uri> out = new ArrayList<>();
        String sel = null;
        String[] args = null;
        if (ids != null && !ids.isEmpty()) {
            args = ids.toArray(new String[0]);
            StringBuilder sb = new StringBuilder(MediaStore.Images.Media.BUCKET_ID + " IN (");
            for (int i = 0; i < args.length; i++) sb.append(i == 0 ? "?" : ",?");
            sb.append(")");
            sel = sb.toString();
        }
        try (Cursor c = ctx.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID}, sel, args,
                MediaStore.Images.Media.DATE_ADDED + " DESC")) {
            if (c != null) {
                while (c.moveToNext() && out.size() < 1500) {
                    out.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0)));
                }
            }
        } catch (Throwable ignored) {
        }
        if (out.isEmpty() && (ids == null || ids.isEmpty())) {
            for (File f : scan(IMAGE_EXT, 1500)) out.add(Uri.fromFile(f));
        }
        return out;
    }

    /** Đọc ảnh đã thu nhỏ (cạnh dài tối đa maxDim) và xoay theo EXIF. */
    static Bitmap loadScaled(Context ctx, Uri uri, int maxDim) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream is = open(ctx, uri)) {
                BitmapFactory.decodeStream(is, null, o);
            }
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= maxDim) s *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = s;
            Bitmap b;
            try (InputStream is = open(ctx, uri)) {
                b = BitmapFactory.decodeStream(is, null, o);
            }
            if (b == null) return null;
            int rot = 0;
            try (InputStream is = open(ctx, uri)) {
                int ori = new ExifInterface(is).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (ori == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
            } catch (Throwable ignored) {
            }
            if (rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            }
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    private static InputStream open(Context ctx, Uri uri) throws Exception {
        if ("file".equals(uri.getScheme())) return new FileInputStream(uri.getPath());
        InputStream is = ctx.getContentResolver().openInputStream(uri);
        if (is == null) throw new FileNotFoundException();
        return is;
    }

    // ------------------------------------------------------------ quét thư mục (dự phòng)

    @SuppressWarnings("deprecation")
    private static List<File> roots() {
        List<File> r = new ArrayList<>();
        try {
            r.add(Environment.getExternalStorageDirectory());
        } catch (Throwable ignored) {
        }
        File[] vols = new File("/storage").listFiles();
        if (vols != null) {
            for (File v : vols) {
                String n = v.getName();
                if ("emulated".equals(n) || "self".equals(n)) continue;
                r.add(v);
            }
        }
        return r;
    }

    private static List<File> scan(String[] exts, int max) {
        List<File> out = new ArrayList<>();
        for (File root : roots()) walk(root, exts, 0, max, out);
        return out;
    }

    private static void walk(File dir, String[] exts, int depth, int max, List<File> out) {
        if (dir == null || depth > 4 || out.size() >= max) return;
        File[] list = dir.listFiles();
        if (list == null) return;
        for (File f : list) {
            if (out.size() >= max) return;
            String n = f.getName();
            if (n.startsWith(".") || "Android".equalsIgnoreCase(n)) continue;
            if (f.isDirectory()) {
                walk(f, exts, depth + 1, max, out);
            } else {
                String l = n.toLowerCase(Locale.ROOT);
                for (String e : exts) {
                    if (l.endsWith(e)) {
                        out.add(f);
                        break;
                    }
                }
            }
        }
    }
}
