package vn.launcher.tv;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.animation.ArgbEvaluator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.SearchManager;
import android.app.role.RoleManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Enumeration;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends Activity {

    private static final String[] DOCK_PREF = {"youtube", "fpt play", "tv360", "vtv"};
    private static final String DEFAULT_FPT_LINK = "https://fptplay.vn/trang/channel";
    // Hai kênh mặc định trong khung TV: {tên, liên kết}. Sửa được trong Cài đặt.
    private static final String[][] DEFAULT_CH = {
            {"THVL1", "https://fptplay.vn/xem-truyen-hinh/thvl1"},
            {"VTV1", "https://fptplay.vn/xem-truyen-hinh/vtv1-hd"}};
    // Viền LED: đỏ → vàng → xanh lá → trắng → (về đỏ)
    private static final int[] LED_COLORS = {0xFFFF3B30, 0xFFFFD60A, 0xFF30D158, 0xFFFFFFFF, 0xFFFF3B30};

    private static final String[] THU_VI = {"Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư",
            "Thứ năm", "Thứ sáu", "Thứ bảy"};
    private static final String[] DAY_EN = {"Sunday", "Monday", "Tuesday", "Wednesday",
            "Thursday", "Friday", "Saturday"};
    private static final String[] MON_EN = {"January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"};

    private static final String[] PRESET_VI = {"Đỏ (mặc định)", "Xanh dương", "Tím", "Xanh lá", "Đen"};
    private static final String[] PRESET_EN = {"Red (default)", "Blue", "Purple", "Green", "Black"};
    private static final int[] PRESET_COLORS = {0xAAB71C1C, 0xAA1565C0, 0xAA6A1B9A, 0xAA2E7D32, 0};

    private static final String[] DISPLAY_KEYS = {"weatherOn", "wifiOn", "voiceOn", "musicOn", "tvOn",
            "musicFrameOn", "photoFrameOn", "barsOn", "holidayOn", "lunarAlertOn", "nameOn"};

    private static final int REQ_PICK_IMAGE = 101;
    private static final int REQ_ROLE = 102;
    private static final int REQ_LOC = 103;
    private static final int REQ_MEDIA = 104;
    // Màu ô biểu tượng trong khung cài đặt kiểu macOS
    private static final int[] PALETTE = {0xFF8E8E93, 0xFF0A84FF, 0xFF30B0C7, 0xFFAF52DE, 0xFF34C759,
            0xFFFF453A, 0xFFFF9F0A, 0xFF64D2FF, 0xFFFF375F, 0xFF5E5CE6};
    private static final float APP_FOCUS_SCALE = 1.25f;   // ô đang chọn phóng to lên
    private static final float APP_SIZE_SCALE = 0.8f;     // ô ứng dụng nhỏ hơn 20%
    private static final int COLUMNS = 4;
    private static final float TILE_ALPHA = 0.6f;
    private static final long STATUS_INTERVAL = 2000;
    private static final TimeInterpolator SMOOTH = new PathInterpolator(0.25f, 0.1f, 0.25f, 1f);

    interface Opener {
        InputStream open() throws IOException;
    }

    interface AdbCallback {
        void done(String out, String err);
    }

    static class AppItem {
        String label, pkg, cls;
        Drawable image;
        boolean banner, self;
    }

    static class MusicInfo {
        String text;
        PendingIntent open;
        Runnable ours;
    }

    private String lang = "vi";
    private boolean uiFailed = false;
    private boolean safeMode = false;

    private ScrollView scroll;
    private LinearLayout dock, tvSection, tvFrame, mediaSection, mediaFrame, weatherBox, sysBars;
    private GridLayout grid;
    private TextView appName, greeting, dateView, lunarView, pillStatus, pillWifi;
    private TextView holidayView, lunarAlert, weatherTemp, weatherDesc, weatherCity;
    private TextView txtStorage, txtRam;
    private ProgressBar barStorage, barRam;

    private SharedPreferences prefs;
    private SoundPool sounds;
    private int soundMove, soundSelect;
    private boolean soundOn = true;
    private boolean quiet = false;

    private Dialog currentDialog;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statusTick = new Runnable() {
        @Override
        public void run() {
            safe(MainActivity.this::updateStatus);
            safe(MainActivity.this::updateSysBars);
            safe(MainActivity.this::updateNetwork);
            safe(() -> maybeFetchWeather(false));
            safe(() -> {
                if (Calendar.getInstance().get(Calendar.DAY_OF_YEAR) != lastDay) updateHeader();
            });
            handler.postDelayed(this, STATUS_INTERVAL);
        }
    };

    private List<AppItem> apps = new ArrayList<>();
    private String lastSignature = "";
    private String statusKey = "";
    private Runnable statusAction;
    private String movingPkg = null;
    private int tileW, tileH, slotW;
    private int lastDay = -1;
    private String netKey = "";
    private Bitmap wallBitmap;
    private boolean weatherBusy = false;
    private long lastWeatherAttempt = 0;

    // ================================================================ ngôn ngữ

    private boolean en() {
        return "en".equals(lang);
    }

    private String tr(String vi, String eng) {
        return en() ? eng : vi;
    }

    @Override
    protected void attachBaseContext(Context base) {
        lang = base.getSharedPreferences("cfg", MODE_PRIVATE).getString("lang", "vi");
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(new Locale(lang));
        super.attachBaseContext(base.createConfigurationContext(cfg));
    }

    // ================================================================ vòng đời

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        CrashGuard.install(getApplicationContext());
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        safeMode = CrashGuard.recent(this, 60000);   // vừa lỗi trong 1 phút → chế độ an toàn
        try {
            initUi();
        } catch (Throwable t) {
            CrashGuard.record(this, t);
            uiFailed = true;
            showFallback(t);
        }
    }

    private void initUi() {
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        soundOn = prefs.getBoolean("sound", true);

        scroll = findViewById(R.id.scroll);
        dock = findViewById(R.id.dock);
        grid = findViewById(R.id.grid);
        tvSection = findViewById(R.id.tv_section);
        tvFrame = findViewById(R.id.tv_frame);
        mediaSection = findViewById(R.id.media_section);
        mediaFrame = findViewById(R.id.media_frame);
        tabDots = findViewById(R.id.tab_dots);
        tabTitle = findViewById(R.id.tab_title);
        buildTabDots();
        contentRoot = findViewById(R.id.content_root);
        setupSelectionFrame();
        sysBars = findViewById(R.id.sys_bars);
        weatherBox = findViewById(R.id.weather_box);
        appName = findViewById(R.id.app_name);
        greeting = findViewById(R.id.greeting);
        dateView = findViewById(R.id.date);
        lunarView = findViewById(R.id.lunar);
        pillStatus = findViewById(R.id.pill_status);
        pillWifi = findViewById(R.id.pill_wifi);
        holidayView = findViewById(R.id.holiday);
        lunarAlert = findViewById(R.id.lunar_alert);
        weatherTemp = findViewById(R.id.weather_temp);
        weatherDesc = findViewById(R.id.weather_desc);
        weatherCity = findViewById(R.id.weather_city);
        txtStorage = findViewById(R.id.txt_storage);
        txtRam = findViewById(R.id.txt_ram);
        barStorage = findViewById(R.id.bar_storage);
        barRam = findViewById(R.id.bar_ram);

        if (!safeMode) {
            try {
                initSounds();
            } catch (Throwable ignored) {
            }
        }
        try {
            applyBackground();
        } catch (Throwable t) {
            getWindow().setBackgroundDrawable(new ColorDrawable(0xFF0D0D10));
        }

        int[] pillIds = {R.id.pill_status, R.id.pill_wifi, R.id.pill_settings};
        for (int id : pillIds) {
            findViewById(id).setOnFocusChangeListener((v, has) -> {
                if (has) playMove();
            });
        }
        pillStatus.setOnClickListener(v -> {
            playSelect();
            if (statusAction != null) statusAction.run();
            else startVoiceSearch();
        });
        findViewById(R.id.pill_wifi).setOnClickListener(v -> {
            playSelect();
            startSafe(new Intent(Settings.ACTION_WIFI_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
        });
        findViewById(R.id.pill_settings).setOnClickListener(v -> {
            playSelect();
            showMenu();
        });
        applyVisibility();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (uiFailed) return;
        safe(this::updateHeader);
        safe(() -> refreshApps(false, null));
        safe(this::refreshTabDock);
        if (!safeMode) {
            safe(this::startCardSlides);
            safe(this::updateSysBars);
            safe(this::updateNetwork);
            safe(this::showWeather);
            safe(() -> {
                if (prefs.getBoolean("weatherOn", true) || prefs.getBoolean("wifiOn", true)) {
                    requestLocationIfNeeded(false);   // cần cho thời tiết và đọc tên Wi-Fi
                }
                maybeFetchWeather(false);
            });
            handler.removeCallbacks(statusTick);
            handler.post(statusTick);
        } else {
            toast(tr("Chế độ an toàn: launcher vừa gặp lỗi", "Safe mode: the launcher just hit an error"));
        }
        safe(this::showLastCrash);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(statusTick);
        handler.removeCallbacks(cardSlideTick);
        frameHideNow();
        stopUploadServer();
        dismissDialog();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (uiFailed) return;
        dismissDialog();             // bấm Home: đóng mọi menu đang mở
        if (movingPkg != null) endMove();
        goHome();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dismissDialog();
        releasePlayer();
        handler.removeCallbacksAndMessages(null);
        if (sounds != null) {
            sounds.release();
            sounds = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Là màn hình chính nên không thoát khi bấm Back
    }

    private void safe(Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            CrashGuard.record(this, t);
        }
    }

    /** Màn hình tối giản khi giao diện chính không dựng được: hiện lỗi và cho đi tới cài đặt, tránh đen màn hình. */
    private void showFallback(Throwable t) {
        try {
            getWindow().setBackgroundDrawable(new ColorDrawable(0xFF0D0D10));
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(48), dp(36), dp(48), dp(24));

            TextView title = new TextView(this);
            title.setText(tr("Launcher gặp lỗi khi khởi động", "The launcher failed to start"));
            title.setTextColor(0xFFFFFFFF);
            title.setTextSize(22);
            box.addView(title, new LinearLayout.LayoutParams(-2, -2));

            TextView msg = new TextView(this);
            msg.setText(CrashGuard.firstLines(CrashGuard.trace(t), 12));
            msg.setTextColor(0xCCFFFFFF);
            msg.setTextSize(11);
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-2, -2);
            mp.setMargins(0, dp(12), 0, dp(16));
            box.addView(msg, mp);

            Button settings = new Button(this);
            settings.setText(tr("Mở cài đặt hệ thống", "Open system settings"));
            settings.setOnClickListener(v -> startSafe(new Intent(Settings.ACTION_SETTINGS)));
            box.addView(settings, new LinearLayout.LayoutParams(-2, -2));

            Button home = new Button(this);
            home.setText(tr("Chọn launcher khác", "Choose another launcher"));
            home.setOnClickListener(v -> startSafe(new Intent(Settings.ACTION_HOME_SETTINGS),
                    new Intent(Settings.ACTION_SETTINGS)));
            box.addView(home, new LinearLayout.LayoutParams(-2, -2));

            Button retry = new Button(this);
            retry.setText(tr("Thử lại", "Retry"));
            retry.setOnClickListener(v -> recreate());
            box.addView(retry, new LinearLayout.LayoutParams(-2, -2));

            setContentView(box);
            settings.requestFocus();
        } catch (Throwable ignored) {
        }
    }

    /** Lần mở sau khi từng gặp lỗi: hiện nội dung lỗi để báo lại. */
    private void showLastCrash() {
        final String full = CrashGuard.read(this);
        if (full == null) return;
        CrashGuard.clear(this);
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Launcher từng gặp lỗi", "The launcher hit an error earlier"))
                .setMessage(CrashGuard.firstLines(full, 10))
                .setPositiveButton(tr("Sao chép", "Copy"), (dlg, w) -> {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("crash", full));
                        toast(tr("Đã sao chép", "Copied"));
                    } catch (Exception ignored) {
                    }
                })
                .setNegativeButton(tr("Đóng", "Close"), null));
    }

    private boolean hasNotificationAccess() {
        try {
            String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
            return s != null && s.contains(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    private void goHome() {
        scroll.smoothScrollTo(0, 0);
        View first = dock.getChildAt(0);
        if (first != null && !first.hasFocus()) {
            quiet = true;
            first.requestFocus();
            quiet = false;
        }
    }

    // ================================================================ hộp thoại (luôn chỉ có 1 hộp thoại)

    private void present(AlertDialog.Builder builder) {
        dismissDialog();
        final AlertDialog d = builder.create();
        d.setOnDismissListener(x -> {
            if (currentDialog == d) currentDialog = null;
        });
        currentDialog = d;
        d.show();
    }

    private void dismissDialog() {
        if (currentDialog != null) {
            try {
                currentDialog.dismiss();
            } catch (Exception ignored) {
            }
            currentDialog = null;
        }
    }

    // ================================================================ phím (chế độ di chuyển)

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (uiFailed) return super.dispatchKeyEvent(e);
        if (movingPkg == null) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0
                    && launchByKey(e.getKeyCode())) {
                return true;
            }
            return super.dispatchKeyEvent(e);
        }
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            switch (e.getKeyCode()) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    moveBy(-1);
                    break;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    moveBy(1);
                    break;
                case KeyEvent.KEYCODE_DPAD_UP:
                    moveBy(-COLUMNS);
                    break;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    moveBy(COLUMNS);
                    break;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_BACK:
                case KeyEvent.KEYCODE_ESCAPE:
                    endMove();
                    break;
                default:
                    return super.dispatchKeyEvent(e);
            }
        }
        return true;
    }

    private void startMove(AppItem a) {
        if (dockTab != 0) {          // đang ở tab "gần đây"/"thường dùng": về tab Ứng dụng để di chuyển
            dockTab = 0;
            updateTabUi();
            buildViews(a.pkg);
        }
        movingPkg = a.pkg;
        appName.setText(tr("Đang di chuyển: ", "Moving: ") + a.label);
        toast(tr("Dùng phím mũi tên để di chuyển, bấm OK để xong",
                "Use the arrow keys to move, press OK when done"));
    }

    private void endMove() {
        if (movingPkg == null) return;
        String p = movingPkg;
        movingPkg = null;
        saveOrder();
        for (AppItem a : apps) if (a.pkg.equals(p)) appName.setText(a.label);
        toast(tr("Đã lưu vị trí", "Position saved"));
    }

    private void moveBy(int delta) {
        int idx = -1;
        for (int i = 0; i < apps.size(); i++) if (apps.get(i).pkg.equals(movingPkg)) idx = i;
        if (idx < 0) return;
        int n = idx + delta;
        if (n < 0 || n >= apps.size()) return;
        AppItem a = apps.remove(idx);
        apps.add(n, a);
        buildViews(movingPkg);
        appName.setText(tr("Đang di chuyển: ", "Moving: ") + a.label);
        playMove();
    }

    private void saveOrder() {
        StringBuilder sb = new StringBuilder();
        for (AppItem a : apps) {
            if (sb.length() > 0) sb.append(',');
            sb.append(a.pkg);
        }
        prefs.edit().putString("order", sb.toString()).apply();
        lastSignature = signature(queryResolve());
    }

    // ================================================================ âm thanh

    private void initSounds() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        sounds = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build();
        soundMove = sounds.load(this, R.raw.move, 1);
        soundSelect = sounds.load(this, R.raw.select, 1);
    }

    private void playMove() {
        if (soundOn && !quiet && sounds != null) sounds.play(soundMove, 0.6f, 0.6f, 1, 0, 1f);
    }

    private void playSelect() {
        if (soundOn && sounds != null) sounds.play(soundSelect, 0.7f, 0.7f, 1, 0, 1f);
    }

    // ================================================================ nút trạng thái (giọng nói / USB / nhạc)

    private void updateStatus() {
        String key, text;
        int icon;
        Runnable action;

        final MusicInfo music = prefs.getBoolean("musicOn", true) ? currentMusic() : null;
        if (music != null) {
            key = "music:" + music.text;
            text = music.text;
            icon = R.drawable.ic_music;
            action = () -> {
                if (music.ours != null) {
                    music.ours.run();
                    return;
                }
                try {
                    if (music.open != null) {
                        music.open.send();
                        return;
                    }
                } catch (PendingIntent.CanceledException ignored) {
                }
                startSafe(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC));
            };
        } else if (usbConnected()) {
            key = "usb";
            text = tr("USB đã kết nối", "USB connected");
            icon = R.drawable.ic_usb;
            action = () -> startSafe(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
                    new Intent(Settings.ACTION_SETTINGS));
        } else {
            key = "voice";
            text = getString(R.string.voice_search);
            icon = R.drawable.ic_mic;
            action = this::startVoiceSearch;
        }
        statusAction = action;
        boolean show = !"voice".equals(key) || prefs.getBoolean("voiceOn", true);
        pillStatus.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!key.equals(statusKey)) {
            statusKey = key;
            pillStatus.setText(text);
            pillStatus.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0);
        }
    }

    private MusicInfo currentMusic() {
        if (isPlaying() && trackIdx >= 0 && trackIdx < tracks.size()) {
            MusicInfo m = new MusicInfo();
            MediaLibrary.Track t = tracks.get(trackIdx);
            m.text = t.title + (t.artist.isEmpty() ? "" : " - " + t.artist);
            m.ours = this::openMusicPanel;
            return m;
        }
        try {
            MediaSessionManager msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> list = msm.getActiveSessions(new ComponentName(this, MediaListener.class));
            for (MediaController c : list) {
                PlaybackState ps = c.getPlaybackState();
                if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) {
                    MusicInfo m = new MusicInfo();
                    MediaMetadata md = c.getMetadata();
                    String title = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_TITLE);
                    String artist = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                    if (title == null || title.isEmpty()) {
                        m.text = tr("Đang phát nhạc", "Playing music");
                    } else {
                        m.text = title + (artist == null || artist.isEmpty() ? "" : " - " + artist);
                    }
                    m.open = c.getSessionActivity();
                    return m;
                }
            }
        } catch (Exception ignored) {
        }
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null && am.isMusicActive()) {
                MusicInfo m = new MusicInfo();
                m.text = tr("Đang phát nhạc", "Playing music");
                return m;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private boolean usbConnected() {
        try {
            UsbManager um = (UsbManager) getSystemService(Context.USB_SERVICE);
            if (um != null) {
                for (UsbDevice d : um.getDeviceList().values()) {
                    for (int i = 0; i < d.getInterfaceCount(); i++) {
                        if (d.getInterface(i).getInterfaceClass() == UsbConstants.USB_CLASS_MASS_STORAGE) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        try {
            StorageManager sm = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
            if (sm != null) {
                for (StorageVolume v : sm.getStorageVolumes()) {
                    if (v.isRemovable() && Environment.MEDIA_MOUNTED.equals(v.getState())) return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void startVoiceSearch() {
        Intent katniss = new Intent(Intent.ACTION_ASSIST).setPackage("com.google.android.katniss");
        boolean ok = startSafe(katniss,
                new Intent(Intent.ACTION_VOICE_COMMAND),
                new Intent("android.intent.action.VOICE_ASSIST"),
                new Intent(Intent.ACTION_ASSIST),
                new Intent(RecognizerIntent.ACTION_WEB_SEARCH));
        if (!ok) toast(tr("Không tìm thấy Google Assistant trên TV này",
                "Google Assistant was not found on this TV"));
    }

    // ================================================================ mạng (tên Wi-Fi / LAN)

    private void updateNetwork() {
        if (!prefs.getBoolean("wifiOn", true)) {
            pillWifi.setVisibility(View.GONE);
            return;
        }
        pillWifi.setVisibility(View.VISIBLE);
        String text;
        int icon = R.drawable.ic_wifi;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                text = "LAN";
                icon = R.drawable.ic_ethernet;
            } else if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                text = wifiName();
            } else {
                text = tr("Chưa kết nối", "Offline");
            }
        } catch (Exception e) {
            text = getString(R.string.wifi);
        }
        String key = text + "|" + icon;
        if (!key.equals(netKey)) {
            netKey = key;
            pillWifi.setText(text);
            pillWifi.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0);
        }
    }

    @SuppressWarnings("deprecation")
    private String wifiName() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo wi = wm == null ? null : wm.getConnectionInfo();
            String ssid = wi == null ? null : wi.getSSID();
            if (ssid != null && !ssid.contains("unknown ssid") && !ssid.equals("0x") && !ssid.isEmpty()) {
                if (ssid.length() > 1 && ssid.startsWith("\"") && ssid.endsWith("\"")) {
                    ssid = ssid.substring(1, ssid.length() - 1);
                }
                return ssid;
            }
        } catch (Exception ignored) {
        }
        return getString(R.string.wifi);   // chưa cấp quyền vị trí → không đọc được tên
    }

    // ================================================================ dung lượng + RAM

    private void updateSysBars() {
        if (!prefs.getBoolean("barsOn", true)) return;
        try {
            StatFs st = new StatFs(Environment.getDataDirectory().getPath());
            long total = st.getTotalBytes();
            long free = st.getAvailableBytes();
            setBar(barStorage, txtStorage, total - free, total);

            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            setBar(barRam, txtRam, mi.totalMem - mi.availMem, mi.totalMem);
        } catch (Exception ignored) {
        }
    }

    private void setBar(ProgressBar bar, TextView txt, long used, long total) {
        if (total <= 0) return;
        int p = (int) (used * 100 / total);
        bar.setProgress(p);
        bar.setProgressTintList(ColorStateList.valueOf(p >= 90 ? 0xFFFF5252 : 0xE6FFFFFF));
        txt.setText(String.format(Locale.US, "%.1f/%.1f GB",
                used / 1073741824.0, total / 1073741824.0));
    }

    // ================================================================ thời tiết

    private void requestLocationIfNeeded(boolean force) {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) return;
            if (!force && prefs.getBoolean("locAsked", false)) return;
            prefs.edit().putBoolean("locAsked", true).apply();
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_LOC) {
            maybeFetchWeather(true);
        } else if (req == REQ_MEDIA) {
            Runnable r = pendingMedia;
            pendingMedia = null;
            if (hasMediaPerm()) {
                if (r != null) r.run();
                safe(this::startCardSlides);
            } else {
                toast(tr("Chưa được cấp quyền đọc nhạc/ảnh. Có thể cấp bằng: adb shell pm grant " + getPackageName()
                                + " " + mediaPerms()[0],
                        "Media permission was not granted. You can grant it with: adb shell pm grant "
                                + getPackageName() + " " + mediaPerms()[0]));
            }
        }
    }

    private void maybeFetchWeather(boolean force) {
        if (!prefs.getBoolean("weatherOn", true) || weatherBusy) return;
        long now = System.currentTimeMillis();
        if (!force) {
            if (now - lastWeatherAttempt < 5 * 60 * 1000L) return;
            if (now - prefs.getLong("w_time", 0) < 30 * 60 * 1000L) return;
        }
        lastWeatherAttempt = now;
        weatherBusy = true;
        final boolean eng = en();
        new Thread(() -> {
            try {
                Weather.Data d = Weather.fetch(getApplicationContext(), eng);
                prefs.edit()
                        .putFloat("w_temp", (float) d.temp)
                        .putFloat("w_min", (float) d.min)
                        .putFloat("w_max", (float) d.max)
                        .putInt("w_code", d.code)
                        .putInt("w_rain", d.rain)
                        .putString("w_city", d.city)
                        .putLong("w_time", System.currentTimeMillis())
                        .apply();
                runOnUiThread(this::showWeather);
            } catch (Exception ignored) {
                // giữ dữ liệu cũ, thử lại sau
            } finally {
                weatherBusy = false;
            }
        }).start();
    }

    private void showWeather() {
        if (!prefs.getBoolean("weatherOn", true)) {
            weatherBox.setVisibility(View.GONE);
            return;
        }
        weatherBox.setVisibility(View.VISIBLE);
        if (prefs.getLong("w_time", 0) == 0) {
            weatherTemp.setText("…");
            weatherDesc.setText(tr("Đang tải thời tiết", "Loading weather"));
            weatherCity.setText("");
            return;
        }
        String[] d = Weather.describe(prefs.getInt("w_code", 0), en());
        weatherTemp.setText(d[0] + " " + Math.round(prefs.getFloat("w_temp", 0)) + "°C");
        weatherDesc.setText(d[1] + " · " + Math.round(prefs.getFloat("w_min", 0)) + "°/"
                + Math.round(prefs.getFloat("w_max", 0)) + "° · 💧" + prefs.getInt("w_rain", 0) + "%");
        weatherCity.setText(prefs.getString("w_city", ""));
    }

    // ================================================================ menu Cài đặt

    private void showMenu() {
        LinearLayout win = macWindow(tr("Cài đặt", "Settings"));
        LinearLayout list = macListBox(win);
        final Dialog[] holder = new Dialog[1];
        list.addView(profileHeader(), new LinearLayout.LayoutParams(-1, -2));
        list.addView(quickTiles(holder), new LinearLayout.LayoutParams(-1, -2));
        list.addView(volumeRow());

        list.addView(sectionHeader(tr("Chung", "General")));
        addNav(list, holder, R.drawable.ic_image, PALETTE[2], tr("Hình nền", "Wallpaper"), this::showWallpaperMenu);
        addNav(list, holder, R.drawable.ic_language, PALETTE[1], tr("Ngôn ngữ", "Language"), this::showLanguageMenu);
        addRow(list, toggleRowEx(R.drawable.ic_volume, PALETTE[8], tr("Âm thanh di chuyển", "Navigation sound"), "sound"));
        addNav(list, holder, R.drawable.ic_info, PALETTE[9], getString(R.string.info_title), this::showInfo);

        list.addView(sectionHeader(tr("Khung & phím", "Frames & keys")));
        addNav(list, holder, R.drawable.ic_live_tv, PALETTE[5], tr("Kênh trong khung TV", "Channels in the TV frame"),
                this::showTvFrameMenu);
        addNav(list, holder, R.drawable.ic_remote, PALETTE[6], tr("Gán phím mở ứng dụng", "Key shortcuts for apps"),
                this::showKeyMapMenu);
        addNav(list, holder, R.drawable.ic_link, PALETTE[4], tr("FPT Play: liên kết Truyền hình", "FPT Play: TV section link"),
                this::showFptLink);

        list.addView(sectionHeader(tr("Khác", "More")));
        addNav(list, holder, R.drawable.ic_tune, PALETTE[3], tr("Hiển thị", "Display"), this::showDisplayMenu);
        addNav(list, holder, R.drawable.ic_music_dlg, PALETTE[8], tr("Nhạc & ảnh", "Music & photos"),
                this::showMediaSettings);
        addNav(list, holder, R.drawable.ic_home, PALETTE[1], tr("Đặt launcher mặc định", "Set as default launcher"),
                this::showDefaultLauncherMenu);
        addNav(list, holder, R.drawable.ic_tv, PALETTE[0], tr("Cài đặt hệ thống", "System settings"),
                () -> startSafe(new Intent(Settings.ACTION_SETTINGS)));
        addNav(list, holder, R.drawable.ic_apps, PALETTE[7], tr("Ứng dụng đã ẩn", "Hidden apps"), this::showHiddenApps);

        holder[0] = showMacDialog(win, 540, null);
        focusFirst(list, 1);
    }

    private void showIconMenu(String title, String[] labels, final int[] icons,
                              DialogInterface.OnClickListener listener) {
        showMacMenu(title, labels, icons, false, listener);
    }

    private void showDisplayMenu() {
        LinearLayout win = macWindow(tr("Hiển thị", "Display"));
        MaxHeightScrollView sv = new MaxHeightScrollView(this);
        sv.setMaxHeight((int) (getResources().getDisplayMetrics().heightPixels * 0.80f));
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(0), dp(12), dp(14));
        sv.addView(list, new ViewGroup.LayoutParams(-1, -2));
        win.addView(sv, new LinearLayout.LayoutParams(-1, -2));

        list.addView(sectionHeader(tr("Khung trên màn hình chính", "Home screen frames")));
        addRow(list, toggleRow(tr("Khung kênh TV", "TV channel frame"), "tvOn"));
        addRow(list, toggleRow(tr("Khung phát nhạc (bộ nhớ, USB)", "Music player (storage, USB)"), "musicFrameOn"));
        addRow(list, toggleRow(tr("Khung trình chiếu ảnh", "Photo slideshow"), "photoFrameOn"));

        list.addView(sectionHeader(tr("Thông tin hiển thị", "Information shown")));
        addRow(list, toggleRow(tr("Thời tiết", "Weather"), "weatherOn"));
        addRow(list, toggleRow(tr("Mạng (tên Wi-Fi / LAN)", "Network (Wi-Fi name / LAN)"), "wifiOn"));
        addRow(list, toggleRow(tr("Tìm kiếm giọng nói", "Voice search"), "voiceOn"));
        addRow(list, toggleRow(tr("Bài hát/video đang phát (YouTube, SmartTube…)",
                "Now playing (YouTube, SmartTube…)"), "musicOn"));
        addRow(list, toggleRow(tr("Dung lượng & RAM", "Storage & RAM"), "barsOn"));
        addRow(list, toggleRow(tr("Đếm ngược ngày lễ", "Holiday countdown"), "holidayOn"));
        addRow(list, toggleRow(tr("Nhắc mùng 1, 14, 15, cuối tháng âm", "Lunar alerts (1st, 14th, 15th, last day)"),
                "lunarAlertOn"));
        addRow(list, toggleRow(tr("Hiện tên trong lời chào", "Show name in greeting"), "nameOn"));

        list.addView(sectionHeader(tr("Hình nền", "Wallpaper")));
        addRow(list, macRow(R.drawable.ic_image, PALETTE[2], tr("Độ trong suốt hình nền…", "Wallpaper opacity…"), v -> {
            playSelect();
            showOpacityDialog();
        }));

        showMacDialog(win, 560, null);
        View first = list.getChildAt(1);
        if (first != null) first.requestFocus();
    }

    private void addRow(LinearLayout list, View row) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(2), 0, dp(2));
        list.addView(row, lp);
    }

    private View toggleRow(String label, final String key) {
        return toggleRowEx(0, 0, label, key);
    }

    private View toggleRowEx(int iconRes, int color, String label, final String key) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(12), dp(8));
        row.setFocusable(true);
        row.setClickable(true);
        row.setBackground(macRowBg());

        boolean hasIcon = iconRes != 0;
        if (hasIcon) {
            FrameLayout tile = new FrameLayout(this);
            tile.setBackground(rounded(color, 7));
            ImageView iv = new ImageView(this);
            iv.setImageResource(iconRes);
            iv.setPadding(dp(5), dp(5), dp(5), dp(5));
            tile.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            row.addView(tile, new LinearLayout.LayoutParams(dp(30), dp(30)));
        }

        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(15);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.setMargins(hasIcon ? dp(14) : dp(2), 0, dp(10), 0);
        row.addView(t, tl);

        final TextView st = new TextView(this);
        st.setTextSize(12);
        st.setTypeface(Typeface.DEFAULT_BOLD);
        st.setPadding(dp(14), dp(4), dp(14), dp(4));
        applyToggleState(st, prefs.getBoolean(key, true));
        row.addView(st, new LinearLayout.LayoutParams(-2, -2));

        row.setOnFocusChangeListener((v, has) -> {
            if (has) playMove();
        });
        row.setOnClickListener(v -> {
            boolean now = !prefs.getBoolean(key, true);
            prefs.edit().putBoolean(key, now).apply();
            applyToggleState(st, now);
            if ("sound".equals(key)) soundOn = now;
            playSelect();
            onDisplayChanged(key, now);
        });
        return row;
    }

    private void applyToggleState(TextView st, boolean on) {
        st.setText(on ? tr("Bật", "On") : tr("Tắt", "Off"));
        st.setTextColor(0xFFFFFFFF);
        st.setBackground(rounded(on ? 0xFF34C759 : 0x66787880, 12));
    }

    private View sectionHeader(String text) {
        TextView t = new TextView(this);
        t.setText(text.toUpperCase(new Locale(lang)));
        t.setTextColor(0x99FFFFFF);
        t.setTextSize(11);
        t.setLetterSpacing(0.08f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(12), dp(14), dp(12), dp(4));
        return t;
    }

    private void onDisplayChanged(String key, boolean on) {
        applyVisibility();
        if ("weatherOn".equals(key)) {
            if (on) {
                requestLocationIfNeeded(true);
                maybeFetchWeather(true);
            }
            showWeather();
        } else if ("wifiOn".equals(key)) {
            netKey = "";
            updateNetwork();
            if (on) requestLocationIfNeeded(false);
        } else if ("voiceOn".equals(key)) {
            statusKey = "";
            updateStatus();
        } else if ("musicOn".equals(key)) {
            statusKey = "";
            if (on && !hasNotificationAccess()) {
                toast(tr("Bật quyền cho \"" + getString(R.string.app_name) + "\" để hiện tên bài hát/video",
                        "Allow \"" + getString(R.string.app_name) + "\" to show the song/video title"));
                startSafe(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
            updateStatus();
        } else if ("tvOn".equals(key)) {
            buildTvFrame();
        } else if ("musicFrameOn".equals(key) || "photoFrameOn".equals(key)) {
            buildMediaFrame();
        } else if ("barsOn".equals(key)) {
            updateSysBars();
        } else {
            updateHeader();
        }
    }

    private void showOpacityDialog() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        final TextView label = new TextView(this);
        label.setTextSize(15);
        label.setTextColor(0xFFFFFFFF);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setKeyProgressIncrement(5);
        int cur = prefs.getInt("bgAlpha", 100);
        sb.setProgress(cur);
        label.setText(tr("Độ rõ của hình nền: ", "Wallpaper visibility: ") + cur + "%");
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int p, boolean fromUser) {
                label.setText(tr("Độ rõ của hình nền: ", "Wallpaper visibility: ") + p + "%");
                prefs.edit().putInt("bgAlpha", p).apply();
                applyBackground();
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        body.addView(label, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, dp(14), 0, dp(6));
        body.addView(sb, sp);
        macDialog(tr("Độ trong suốt hình nền", "Wallpaper opacity"), body, 520, tr("Xong", "Done"),
                null, null, null, null, false);
        sb.requestFocus();
    }

    private void applyVisibility() {
        tvSection.setVisibility(prefs.getBoolean("tvOn", true) ? View.VISIBLE : View.GONE);
        sysBars.setVisibility(prefs.getBoolean("barsOn", true) ? View.VISIBLE : View.GONE);
        if (!prefs.getBoolean("weatherOn", true)) weatherBox.setVisibility(View.GONE);
    }

    private void showLanguageMenu() {
        final String[] names = {"Tiếng Việt", "English"};
        LinearLayout win = macWindow(tr("Ngôn ngữ", "Language"));
        LinearLayout list = macListBox(win);
        final Dialog[] holder = new Dialog[1];
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            boolean cur = (idx == 1) == en();
            addRow(list, macRowEx(R.drawable.ic_language, PALETTE[1 + i], names[i], cur ? "✓" : "", v -> {
                playSelect();
                holder[0].dismiss();
                String nl = idx == 1 ? "en" : "vi";
                if (!nl.equals(lang)) {
                    prefs.edit().putString("lang", nl).apply();
                    recreate();
                }
            }));
        }
        holder[0] = showMacDialog(win, 440, null);
        focusFirst(list, 0);
    }

    private void askName() {
        macEditDialog(tr("Tên của bạn", "Your name"),
                tr("Tên hiện trong lời chào và khung cài đặt.", "Shown in the greeting and the settings window."),
                new String[]{tr("Tên", "Name")}, new String[]{prefs.getString("name", "")},
                v -> {
                    prefs.edit().putString("name", v[0]).putBoolean("nameOn", true).apply();
                    updateHeader();
                }, null);
    }

    private void showHiddenApps() {
        final List<String> hidden = new ArrayList<>(new TreeSet<>(hiddenSet()));
        if (hidden.isEmpty()) {
            toast(tr("Chưa có ứng dụng nào bị ẩn", "No hidden apps"));
            return;
        }
        PackageManager pm = getPackageManager();
        String[] labels = new String[hidden.size()];
        int[] icons = new int[hidden.size()];
        for (int i = 0; i < hidden.size(); i++) {
            icons[i] = R.drawable.ic_apps;
            try {
                labels[i] = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(hidden.get(i), 0)));
            } catch (Exception e) {
                labels[i] = hidden.get(i);
            }
        }
        showMacMenu(tr("Chọn ứng dụng để hiện lại", "Choose an app to show again"), labels, icons, false,
                (dlg, which) -> {
                    Set<String> h = hiddenSet();
                    h.remove(hidden.get(which));
                    prefs.edit().putStringSet("hidden", h).apply();
                    refreshApps(true, hidden.get(which));
                    toast(tr("Đã hiện lại ứng dụng", "App is visible again"));
                });
    }

    private TextView infoText(String text, int sizeSp, int color, boolean bold, int topDp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, dp(topDp), 0, 0);
        t.setLayoutParams(lp);
        return t;
    }

    /** Thông tin kiểu "Giới thiệu về máy Mac": logo, tên, phiên bản, mô tả, liên kết Facebook. */
    private void showInfo() {
        final String url = getString(R.string.info_url);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        logo.setBackground(rounded(0x33000000, 22));
        body.addView(logo, new LinearLayout.LayoutParams(dp(96), dp(96)));
        body.addView(infoText(getString(R.string.app_name), 22, 0xFFFFFFFF, true, 12));
        body.addView(infoText(tr("Phiên bản ", "Version ") + appVersion(), 13, 0xB3FFFFFF, false, 2));
        body.addView(infoText(getString(R.string.info_description), 13, 0xCCFFFFFF, false, 12));

        View fb = macRowEx(R.drawable.ic_link, 0xFF1877F2, "Facebook", "›", v -> {
            playSelect();
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e) {
                toast(tr("TV chưa có trình duyệt. Hãy truy cập: ", "No browser on this TV. Visit: ") + url);
            }
        });
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(-1, -2);
        fl.setMargins(0, dp(16), 0, 0);
        body.addView(fb, fl);
        body.addView(infoText(url, 11, 0x99FFFFFF, false, 4));

        macDialog(getString(R.string.info_title), body, 480, tr("Đóng", "Close"), null, null, null, null, false);
    }

    // ================================================================ khung kênh TV

    private void showTvFrameMenu() {
        String[] items = {tr("Kênh 1: ", "Channel 1: ") + chName(0), tr("Kênh 2: ", "Channel 2: ") + chName(1)};
        int[] icons = {R.drawable.ic_live_tv, R.drawable.ic_live_tv};
        showMacMenu(tr("Kênh trong khung TV", "Channels in the TV frame"), items, icons, false,
                (dlg, which) -> editChannel(which));
    }

    private AppItem findApp(String pkg) {
        for (AppItem a : apps) if (a.pkg.equals(pkg)) return a;
        return null;
    }

    private String chName(int i) {
        return prefs.getString("ch" + i + "Name", DEFAULT_CH[i][0]);
    }

    private String chLink(int i) {
        return prefs.getString("ch" + i + "Link", DEFAULT_CH[i][1]);
    }

    private void buildTvFrame() {
        tvFrame.removeAllViews();
        boolean on = prefs.getBoolean("tvOn", true);
        tvSection.setVisibility(on ? View.VISIBLE : View.GONE);
        if (!on) return;
        for (int i = 0; i < 2; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(84), 1f);
            lp.setMargins(dp(8), dp(4), dp(8), dp(4));
            tvFrame.addView(makeChannelCard(i), lp);
        }
    }

    private AppItem findByLabel(String key) {
        for (AppItem a : apps) {
            if (!a.self && a.label.toLowerCase(Locale.ROOT).contains(key)) return a;
        }
        return null;
    }

    private void adbRun(final String cmd, final AdbCallback cb) {
        new Thread(() -> {
            String out = null;
            String err = null;
            try {
                out = AdbLocal.shell(getApplicationContext(), cmd);
            } catch (Throwable t) {
                Throwable c = t.getCause() != null ? t.getCause() : t;
                err = c.getClass().getSimpleName() + (c.getMessage() == null ? "" : ": " + c.getMessage());
            }
            final String fo = out;
            final String fe = err;
            runOnUiThread(() -> cb.done(fo, fe));
        }).start();
    }

    // ---------------------------------------------------------------- FPT Play → mục Truyền hình

    private boolean isFpt(AppItem a) {
        return a.label.toLowerCase(Locale.ROOT).contains("fpt play");
    }

    private String fptLink() {
        return prefs.getString("fptLink", DEFAULT_FPT_LINK).trim();
    }

    /** Mở FPT Play bằng liên kết Truyền hình; nếu ứng dụng không nhận liên kết thì mở ứng dụng bình thường. */
    private void launchFptTv(AppItem a, View from) {
        String link = fptLink();
        if (!link.isEmpty() && openLinkIn(link, a.pkg)) return;
        launchPlain(a, from);
    }

    private boolean openLinkIn(String link, String pkg) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
        i.setPackage(pkg);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return startSafe(i);
    }

    private void showFptLink() {
        macEditDialog(tr("FPT Play – liên kết mở Truyền hình", "FPT Play – TV section link"),
                tr("Dùng khi mở FPT Play (ô ứng dụng và phím gán). Để trống = mở FPT Play như bình thường.",
                        "Used when opening FPT Play (app tile and key shortcut). Empty = open FPT Play normally."),
                new String[]{tr("Liên kết", "Link")}, new String[]{fptLink()},
                v -> {
                    prefs.edit().putString("fptLink", v[0]).apply();
                    toast(tr("Đã lưu", "Saved"));
                },
                () -> {
                    prefs.edit().remove("fptLink").apply();
                    toast(tr("Đã khôi phục liên kết mặc định", "Default link restored"));
                });
    }

    /** Bấm ô kênh: mở liên kết kênh trong FPT Play. */
    private void openChannelLink(int slot, View from) {
        String link = chLink(slot).trim();
        AppItem fpt = findByLabel("fpt play");
        if (fpt != null) recordLaunch(fpt.pkg);
        if (link.isEmpty()) {
            if (fpt != null) launchPlain(fpt, from);
            else toast(tr("Chưa có liên kết cho kênh này", "No link set for this channel"));
            return;
        }
        if (fpt != null) {
            if (openLinkIn(link, fpt.pkg)) return;
            toast(tr("FPT Play không nhận liên kết này, đang mở ứng dụng",
                    "FPT Play did not accept this link, opening the app"));
            launchPlain(fpt, from);
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (!startSafe(i)) toast(tr("Không mở được liên kết", "Cannot open the link"));
    }

    private void editChannel(final int slot) {
        macEditDialog(tr("Sửa kênh ", "Edit channel ") + (slot + 1), null,
                new String[]{tr("Tên kênh", "Channel name"), tr("Liên kết mở kênh", "Channel link")},
                new String[]{chName(slot), chLink(slot)},
                v -> {
                    prefs.edit().putString("ch" + slot + "Name", v[0]).putString("ch" + slot + "Link", v[1]).apply();
                    buildTvFrame();
                },
                () -> {
                    prefs.edit().remove("ch" + slot + "Name").remove("ch" + slot + "Link").apply();
                    buildTvFrame();
                });
    }

    private void showAdbGuide() {
        showAdbHelp(tr("Bật ADB qua mạng", "Enable network ADB"),
                tr("Tính năng \"Tự động bằng ADB nội bộ\" cho launcher tự kết nối tới ADB của chính TV (cổng 5555).\n\n"
                                + "1. Trên TV: Cài đặt → Tùy chọn nhà phát triển → bật Gỡ lỗi USB và Gỡ lỗi qua mạng (nếu có).\n"
                                + "2. Nếu TV không có cổng 5555 (Android 11 trở lên), kết nối máy tính với TV rồi chạy lệnh dưới đây một lần (mất hiệu lực khi TV khởi động lại).\n"
                                + "3. Khi TV hỏi cho phép gỡ lỗi, chọn Luôn cho phép.\n\n"
                                + "Lưu ý: bật ADB cho phép ứng dụng đã được cấp quyền chạy lệnh trên TV. Hãy tắt ADB qua mạng khi không dùng.",
                        "\"Automatic with local ADB\" lets the launcher connect to the TV's own ADB (port 5555).\n\n"
                                + "1. On the TV: Settings → Developer options → enable USB debugging and network debugging (if available).\n"
                                + "2. If port 5555 is not available (Android 11+), connect a computer and run the command below once (it resets on reboot).\n"
                                + "3. Choose Always allow when the TV asks.\n\n"
                                + "Note: enabling ADB lets an authorized app run commands on the TV. Turn network ADB off when not needed."),
                "adb tcpip 5555");
    }

    // ---------------------------------------------------------------- viền LED đỏ → vàng → xanh lá → trắng

    private FrameLayout contentRoot;
    private SelectionFrame selFrame;
    private View frameOwner;
    private ValueAnimator selAnim;
    private ValueAnimator ledAnim;
    private boolean frameVisible = false;
    private final Runnable frameHide = new Runnable() {
        @Override
        public void run() {
            frameHideNow();
        }
    };

    private void setupSelectionFrame() {
        selFrame = new SelectionFrame(this);
        selFrame.setStrokeWidth(Math.max(2, dp(3)));
        selFrame.setRadius(dp(16));
        selFrame.setColor(LED_COLORS[0]);
        selFrame.setAlpha(0f);
        contentRoot.addView(selFrame, new FrameLayout.LayoutParams(-1, -1));
    }

    private void autoCancelGlow(final FrameLayout f) {
        f.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                if (frameOwner == f) frameHideNow();
            }
        });
    }

    /** Ô được chọn → khung LED trượt tới ô đó; mất chọn → ẩn khung nếu không có ô nào khác nhận chọn. */
    private void setGlow(FrameLayout f, boolean on, float scale) {
        if (on) {
            frameTo(f, scale);
        } else if (frameOwner == f) {
            handler.postDelayed(frameHide, 120);
        }
    }

    private float[] centerInContent(View v) {
        float x = v.getWidth() / 2f;
        float y = v.getHeight() / 2f;
        View cur = v;
        while (cur != contentRoot) {
            x += cur.getLeft();
            y += cur.getTop();
            if (!(cur.getParent() instanceof View)) return null;
            cur = (View) cur.getParent();
        }
        return new float[]{x, y};
    }

    private void frameTo(final View tile, final float scale) {
        if (selFrame == null || contentRoot == null) return;
        handler.removeCallbacks(frameHide);
        if (tile.getWidth() == 0) {                       // chưa đo xong → thử lại sau khi dựng
            tile.post(() -> {
                if (tile.hasFocus()) frameTo(tile, scale);
            });
            return;
        }
        float[] c = centerInContent(tile);
        if (c == null) return;
        float pad = dp(3);
        final float tw = tile.getWidth() * scale + 2 * pad;
        final float th = tile.getHeight() * scale + 2 * pad;
        final float tx = c[0] - tw / 2f;
        final float ty = c[1] - th / 2f;
        frameOwner = tile;
        if (selAnim != null) selAnim.cancel();
        selFrame.animate().cancel();
        if (!frameVisible) {                              // lần đầu: hiện ngay tại ô
            frameVisible = true;
            selFrame.setRect(tx, ty, tw, th);
            selFrame.animate().alpha(1f).setDuration(150).start();
            startLed();
            return;
        }
        selFrame.animate().alpha(1f).setDuration(120).start();
        final float[] from = selFrame.getRect();
        selAnim = ValueAnimator.ofFloat(0f, 1f);          // trượt mượt từ ô cũ sang ô mới
        selAnim.setDuration(240);
        selAnim.setInterpolator(SMOOTH);
        selAnim.addUpdateListener(an -> {
            float t = (Float) an.getAnimatedValue();
            selFrame.setRect(from[0] + (tx - from[0]) * t, from[1] + (ty - from[1]) * t,
                    from[2] + (tw - from[2]) * t, from[3] + (th - from[3]) * t);
        });
        selAnim.start();
        startLed();
    }

    private void frameHideNow() {
        handler.removeCallbacks(frameHide);
        if (selFrame == null) return;
        if (selAnim != null) selAnim.cancel();
        selFrame.animate().cancel();
        selFrame.animate().alpha(0f).setDuration(120).start();
        frameVisible = false;
        frameOwner = null;
        stopLed();
    }

    /** Màu viền đổi liên tục: đỏ → vàng → xanh lá → trắng. */
    private void startLed() {
        if (ledAnim != null && ledAnim.isRunning()) return;
        final ArgbEvaluator ev = new ArgbEvaluator();
        ledAnim = ValueAnimator.ofFloat(0f, 4f);
        ledAnim.setDuration(2400);
        ledAnim.setInterpolator(new LinearInterpolator());
        ledAnim.setRepeatCount(ValueAnimator.INFINITE);
        ledAnim.setRepeatMode(ValueAnimator.RESTART);
        ledAnim.addUpdateListener(an -> {
            float v = (Float) an.getAnimatedValue();
            int seg = Math.min(3, (int) v);
            int c = (Integer) ev.evaluate(v - seg, LED_COLORS[seg], LED_COLORS[seg + 1]);
            if (selFrame != null) selFrame.setColor(c);
        });
        ledAnim.start();
    }

    private void stopLed() {
        if (ledAnim != null) {
            ledAnim.cancel();
            ledAnim = null;
        }
    }

    // ---------------------------------------------------------------- 4 ô nhanh + thanh âm lượng trong Cài đặt

    private String btStatus() {
        try {
            BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter ad = bm == null ? null : bm.getAdapter();
            if (ad == null) return tr("Không có", "Not available");
            return ad.isEnabled() ? tr("Đang bật", "On") : tr("Đã tắt", "Off");
        } catch (Throwable t) {
            return "—";
        }
    }

    private String netStatusText() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "LAN";
            if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return wifiName();
            return tr("Chưa kết nối", "Offline");
        } catch (Exception e) {
            return "—";
        }
    }

    private View quickTile(int iconRes, int color, String name, String status, final Dialog[] holder,
                           final Runnable action) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(dp(6), dp(12), dp(6), dp(10));
        t.setFocusable(true);
        t.setClickable(true);
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, rounded(0xFF0A84FF, 14));
        sl.addState(new int[]{android.R.attr.state_pressed}, rounded(0xFF0A84FF, 14));
        sl.addState(new int[]{}, rounded(0x1FFFFFFF, 14));
        t.setBackground(sl);

        FrameLayout circle = new FrameLayout(this);
        GradientDrawable cg = new GradientDrawable();
        cg.setShape(GradientDrawable.OVAL);
        cg.setColor(color);
        circle.setBackground(cg);
        ImageView iv = new ImageView(this);
        iv.setImageResource(iconRes);
        iv.setPadding(dp(9), dp(9), dp(9), dp(9));
        circle.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        t.addView(circle, new LinearLayout.LayoutParams(dp(40), dp(40)));

        TextView title = new TextView(this);
        title.setText(name);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(13);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
        tl.setMargins(0, dp(8), 0, 0);
        t.addView(title, tl);

        TextView sub = new TextView(this);
        sub.setText(status);
        sub.setTextColor(0xB3FFFFFF);
        sub.setTextSize(10);
        sub.setSingleLine(true);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sub.setGravity(Gravity.CENTER);
        t.addView(sub, new LinearLayout.LayoutParams(-1, -2));

        t.setOnFocusChangeListener((v, has) -> {
            if (has) playMove();
        });
        t.setOnClickListener(v -> {
            playSelect();
            holder[0].dismiss();
            action.run();
        });
        return t;
    }

    private View quickTiles(Dialog[] holder) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        View[] tiles = {
                quickTile(R.drawable.ic_input, 0xFF0A84FF, tr("Nguồn vào", "Input"),
                        tr("Chọn nguồn vào", "Choose input"), holder, this::openInputs),
                quickTile(R.drawable.ic_bluetooth, 0xFF0082FC, "Bluetooth", btStatus(), holder, this::openBluetooth),
                quickTile(R.drawable.ic_wifi, 0xFF34C759, tr("Mạng", "Network"), netStatusText(), holder,
                        this::openNetwork),
                quickTile(R.drawable.ic_power, 0xFFFF453A, tr("Tắt TV", "Turn off"),
                        tr("Chuyển chế độ chờ", "Go to standby"), holder, this::confirmPowerOff)};
        for (View t : tiles) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(4), dp(6), dp(4), dp(6));
            row.addView(t, lp);
        }
        return row;
    }

    private View volumeRow() {
        final AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(14), dp(10));
        row.setBackground(rounded(0x1FFFFFFF, 14));

        ImageView ic = new ImageView(this);
        ic.setImageResource(R.drawable.ic_volume);
        row.addView(ic, new LinearLayout.LayoutParams(dp(22), dp(22)));

        final int max = am == null ? 15 : Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        int cur = am == null ? 0 : am.getStreamVolume(AudioManager.STREAM_MUSIC);
        final TextView pct = new TextView(this);
        pct.setTextColor(0xCCFFFFFF);
        pct.setTextSize(12);
        pct.setText(cur * 100 / max + "%");

        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(cur);
        sb.setKeyProgressIncrement(1);
        sb.setProgressDrawable(getDrawable(R.drawable.slider_progress));
        sb.setThumb(getDrawable(R.drawable.slider_thumb));
        sb.setSplitTrack(false);
        sb.setPadding(dp(12), 0, dp(12), 0);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int p, boolean fromUser) {
                pct.setText(p * 100 / max + "%");
                if (fromUser && am != null) {
                    try {
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0);
                    } catch (Exception ignored) {
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        sb.setOnFocusChangeListener((v, has) -> {
            row.setBackground(rounded(has ? 0x660A84FF : 0x1FFFFFFF, 14));
            if (has) playMove();
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, dp(28), 1f);
        sl.setMargins(dp(6), 0, dp(6), 0);
        row.addView(sb, sl);
        row.addView(pct, new LinearLayout.LayoutParams(dp(40), -2));

        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.setMargins(dp(4), dp(4), dp(4), dp(8));
        row.setLayoutParams(rl);
        return row;
    }

    private void openInputs() {
        if (startSafe(new Intent("com.android.tv.action.VIEW_INPUTS"))) return;
        adbRun("input keyevent 178", (out, err) -> {      // KEYCODE_TV_INPUT
            if (err != null) {
                toast(tr("Không mở được danh sách nguồn vào. Bật ADB nội bộ hoặc dùng nút INPUT trên remote",
                        "Cannot open the input list. Enable local ADB or use the INPUT button on the remote"));
            }
        });
    }

    private void openBluetooth() {
        startSafe(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
    }

    private void openNetwork() {
        startSafe(new Intent(Settings.ACTION_WIFI_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
    }

    private void confirmPowerOff() {
        macMessage(tr("Tắt TV?", "Turn off the TV?"),
                tr("TV sẽ chuyển sang chế độ chờ. Cần bật ADB nội bộ.",
                        "The TV will go to standby. Local ADB must be enabled."),
                tr("Tắt TV", "Turn off"), this::powerOff, tr("Hủy", "Cancel"));
    }

    private void powerOff() {
        adbRun("input keyevent 223", (out, err) -> {      // KEYCODE_SLEEP
            if (err != null) {
                toast(tr("Cần bật ADB nội bộ để tắt TV: ", "Local ADB is needed to turn off the TV: ") + err);
            }
        });
    }

    // ---------------------------------------------------------------- chọn hình nền từ điện thoại bằng mã QR

    private UploadServer uploadServer;

    private void stopUploadServer() {
        if (uploadServer != null) {
            uploadServer.stop();
            uploadServer = null;
        }
    }

    private String lanIp() {
        String fallback = null;
        try {
            Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
            while (nis.hasMoreElements()) {
                NetworkInterface ni = nis.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                String n = ni.getName();
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress a = addrs.nextElement();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        if (n.startsWith("wlan") || n.startsWith("eth")) return a.getHostAddress();
                        if (fallback == null) fallback = a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return fallback;
    }

    private String uploadPage(String token) {
        try (InputStream is = getResources().openRawResource(R.raw.upload_page)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8")
                    .replace("@TITLE@", tr("Gửi ảnh nền cho TV", "Send a wallpaper to the TV"))
                    .replace("@HINT@", tr("Chọn một ảnh trong điện thoại rồi bấm Gửi.", "Pick a photo from your phone, then tap Send."))
                    .replace("@BTN@", tr("Gửi", "Send"))
                    .replace("@PICK@", tr("Chưa chọn ảnh", "Pick a photo first"))
                    .replace("@DONE@", tr("Đã gửi! Xem trên TV.", "Sent! Check the TV."))
                    .replace("@ERR@", tr("Gửi thất bại, hãy thử lại.", "Failed, please try again."))
                    .replace("@TOKEN@", token);
        } catch (Exception e) {
            return "<html><body>Error</body></html>";
        }
    }

    private Bitmap makeQr(String text, int sizePx) {
        try {
            Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.MARGIN, 1);
            BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, sizePx, sizePx, hints);
            int w = m.getWidth();
            int h = m.getHeight();
            int[] px = new int[w * h];
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) px[y * w + x] = m.get(x, y) ? 0xFF000000 : 0xFFFFFFFF;
            }
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            b.setPixels(px, 0, w, 0, 0, w, h);
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    private void showQrUpload() {
        String ip = lanIp();
        if (ip == null) {
            toast(tr("TV chưa kết nối mạng", "The TV is not connected to a network"));
            return;
        }
        stopUploadServer();
        byte[] rnd = new byte[9];
        new SecureRandom().nextBytes(rnd);
        StringBuilder tk = new StringBuilder();
        for (byte b : rnd) tk.append(String.format(Locale.US, "%02x", b));
        final String token = tk.toString();
        final Dialog[] ref = new Dialog[1];
        String url = null;
        try {
            uploadServer = new UploadServer(token, uploadPage(token), data -> {
                applyCustomAsync(() -> new ByteArrayInputStream(data));
                runOnUiThread(() -> {
                    if (ref[0] != null) ref[0].dismiss();
                });
            });
            int port = uploadServer.start();
            url = "http://" + ip + ":" + port + "/" + token;
        } catch (Exception e) {
            stopUploadServer();
            toast(tr("Không mở được cổng nhận ảnh", "Could not open the upload port"));
            return;
        }

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView qr = new ImageView(this);
        qr.setBackground(rounded(0xFFFFFFFF, 14));
        qr.setPadding(dp(10), dp(10), dp(10), dp(10));
        Bitmap bm = makeQr(url, dp(240));
        if (bm != null) qr.setImageBitmap(bm);
        body.addView(qr, new LinearLayout.LayoutParams(dp(260), dp(260)));
        body.addView(infoText(tr("Quét mã bằng điện thoại (cùng mạng Wi-Fi với TV), chọn ảnh rồi bấm Gửi.",
                "Scan with your phone (same Wi-Fi as the TV), pick a photo and tap Send."), 13, 0xE6FFFFFF, false, 14));
        body.addView(infoText(url, 11, 0x99FFFFFF, false, 6));
        ref[0] = macDialogEx(tr("Chọn ảnh từ điện thoại", "Choose a photo from your phone"), body, 460,
                tr("Đóng", "Close"), null, null, null, null, false, this::stopUploadServer);
    }

    private void autoSetDefaultLauncher() {
        toast(tr("Đang kết nối ADB nội bộ…", "Connecting to local ADB…"));
        adbRun("cmd package set-home-activity " + getPackageName() + "/.MainActivity", (out, err) -> {
            if (err != null) {
                toast(tr("Lỗi ADB nội bộ: ", "Local ADB error: ") + err);
            } else {
                String o = out == null ? "" : out.trim();
                toast(o.isEmpty() ? tr("Đã đặt làm launcher mặc định", "Set as default launcher") : o);
            }
        });
    }

    private View makeChannelCard(final int slot) {
        final FrameLayout f = new FrameLayout(this);
        f.setBackgroundResource(R.drawable.tile_bg);
        f.setClipToOutline(true);
        f.setFocusable(true);
        f.setClickable(true);

        final String name = chName(slot);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText(name);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-2, -2));

        TextView sub = new TextView(this);
        sub.setText("FPT Play");
        sub.setTextColor(0x99FFFFFF);
        sub.setTextSize(11);
        box.addView(sub, new LinearLayout.LayoutParams(-2, -2));
        f.addView(box, new FrameLayout.LayoutParams(-1, -1));

        autoCancelGlow(f);
        f.setOnFocusChangeListener((v, has) -> {
            float sc = has ? 1.04f : 1f;
            f.animate().scaleX(sc).scaleY(sc).setDuration(180).setInterpolator(SMOOTH).start();
            f.setTranslationZ(has ? dp(8) : 0);
            setGlow(f, has, 1.04f);
            if (has) {
                playMove();
                if (movingPkg == null) appName.setText(name);
            }
        });
        f.setOnClickListener(v -> {
            playSelect();
            openChannelLink(slot, v);
        });
        f.setOnLongClickListener(v -> {
            playSelect();
            editChannel(slot);
            return true;
        });
        return f;
    }

    // ================================================================ khung kiểu macOS

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private void roundCorners(View v, final int radiusPx) {
        v.setClipToOutline(true);
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
            }
        });
    }

    private void presentDialog(final Dialog d, final Runnable onDismiss) {
        dismissDialog();
        d.setOnDismissListener(x -> {
            if (currentDialog == d) currentDialog = null;
            if (onDismiss != null) onDismiss.run();
        });
        currentDialog = d;
        d.show();
    }

    /** Cửa sổ kiểu macOS: nền mờ bo góc, có ba chấm đỏ-vàng-xanh và tiêu đề ở giữa. */
    private LinearLayout macWindow(String title) {
        LinearLayout win = new LinearLayout(this);
        win.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE62B2B2E);
        bg.setCornerRadius(dp(22));
        bg.setStroke(Math.max(1, dp(1)), 0x33FFFFFF);
        win.setBackground(bg);
        win.setClipToOutline(true);

        FrameLayout bar = new FrameLayout(this);
        LinearLayout lights = new LinearLayout(this);
        lights.setOrientation(LinearLayout.HORIZONTAL);
        lights.setGravity(Gravity.CENTER_VERTICAL);
        int[] cols = {0xFFFF5F57, 0xFFFEBC2E, 0xFF28C840};
        for (int c : cols) {
            View dot = new View(this);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(c);
            dot.setBackground(d);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(12), dp(12));
            dl.setMargins(0, 0, dp(8), 0);
            lights.addView(dot, dl);
        }
        FrameLayout.LayoutParams ll = new FrameLayout.LayoutParams(-2, -1, Gravity.START | Gravity.CENTER_VERTICAL);
        ll.setMargins(dp(16), 0, 0, 0);
        bar.addView(lights, ll);

        TextView tt = new TextView(this);
        tt.setText(title);
        tt.setTextColor(0xE6FFFFFF);
        tt.setTextSize(13);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setGravity(Gravity.CENTER);
        bar.addView(tt, new FrameLayout.LayoutParams(-2, -1, Gravity.CENTER));
        win.addView(bar, new LinearLayout.LayoutParams(-1, dp(40)));
        return win;
    }

    private Dialog showMacDialog(View win, int widthDp, Runnable onDismiss) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(win);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0x00000000));
            int sw = getResources().getDisplayMetrics().widthPixels;
            w.setLayout(Math.min(dp(widthDp), (int) (sw * 0.92f)), ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.CENTER);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setDimAmount(0.5f);
            if (Build.VERSION.SDK_INT >= 31) {      // làm mờ nền phía sau (nếu TV hỗ trợ)
                try {
                    WindowManager.LayoutParams lp = w.getAttributes();
                    lp.setBlurBehindRadius(30);
                    w.setAttributes(lp);
                    w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
                } catch (Throwable ignored) {
                }
            }
        }
        presentDialog(d, onDismiss);
        return d;
    }

    private Drawable macRowBg() {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, rounded(0xFF0A84FF, 9));
        sl.addState(new int[]{android.R.attr.state_pressed}, rounded(0xFF0A84FF, 9));
        sl.addState(new int[]{}, new ColorDrawable(0x00000000));
        return sl;
    }

    private View macRow(int iconRes, int color, String label, View.OnClickListener click) {
        return macRowEx(iconRes, color, label, "›", click);
    }

    private View macRowEx(int iconRes, int color, String label, String trailing, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(12), dp(8));
        row.setFocusable(true);
        row.setClickable(true);
        row.setBackground(macRowBg());

        FrameLayout tile = new FrameLayout(this);
        tile.setBackground(rounded(color, 7));
        ImageView iv = new ImageView(this);
        iv.setImageResource(iconRes);
        iv.setPadding(dp(5), dp(5), dp(5), dp(5));
        tile.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        row.addView(tile, new LinearLayout.LayoutParams(dp(30), dp(30)));

        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(15);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.setMargins(dp(14), 0, dp(8), 0);
        row.addView(t, tl);

        TextView chev = new TextView(this);
        chev.setText(trailing);
        chev.setTextColor(0x80FFFFFF);
        chev.setTextSize(20);
        row.addView(chev, new LinearLayout.LayoutParams(-2, -2));

        row.setOnFocusChangeListener((v, has) -> {
            if (has) playMove();
        });
        row.setOnClickListener(click);
        return row;
    }

    private LinearLayout macListBox(LinearLayout win) {
        MaxHeightScrollView sv = new MaxHeightScrollView(this);
        sv.setMaxHeight((int) (getResources().getDisplayMetrics().heightPixels * 0.80f));
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(4), dp(12), dp(14));
        sv.addView(list, new ViewGroup.LayoutParams(-1, -2));
        win.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        return list;
    }

    private void focusFirst(LinearLayout list, int from) {
        for (int i = from; i < list.getChildCount(); i++) {
            View c = list.getChildAt(i);
            if (c.isFocusable()) {
                c.requestFocus();
                return;
            }
        }
    }

    private void addNav(LinearLayout list, final Dialog[] holder, int icon, int color, String label,
                        final Runnable action) {
        addRow(list, macRow(icon, color, label, v -> {
            playSelect();
            holder[0].dismiss();
            action.run();
        }));
    }

    private LinearLayout.LayoutParams btnLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(10), 0, 0, 0);
        return lp;
    }

    private View macButton(String text, int color, final Runnable action, final Dialog[] holder) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(18), dp(8), dp(18), dp(8));
        b.setFocusable(true);
        b.setClickable(true);
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable focused = rounded(color, 9);
        focused.setStroke(Math.max(2, dp(2)), 0xFFFFFFFF);
        sl.addState(new int[]{android.R.attr.state_focused}, focused);
        sl.addState(new int[]{}, rounded(color, 9));
        b.setBackground(sl);
        b.setOnFocusChangeListener((v, has) -> {
            if (has) playMove();
        });
        b.setOnClickListener(v -> {
            playSelect();
            if (holder[0] != null) holder[0].dismiss();
            if (action != null) action.run();
        });
        return b;
    }

    /** Hộp thoại kiểu macOS: nội dung ở giữa, nút bên phải (Mặc định / Hủy / nút chính màu xanh). */
    private Dialog macDialog(String title, View body, int widthDp, String positive, Runnable onPositive,
                             String neutral, Runnable onNeutral, String negative, boolean scroll) {
        return macDialogEx(title, body, widthDp, positive, onPositive, neutral, onNeutral, negative, scroll, null);
    }

    private Dialog macDialogEx(String title, View body, int widthDp, String positive, Runnable onPositive,
                               String neutral, Runnable onNeutral, String negative, boolean scroll,
                               Runnable onDismiss) {
        LinearLayout win = macWindow(title);
        final Dialog[] holder = new Dialog[1];
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(8), dp(22), dp(18));
        if (body != null) {
            if (scroll) {
                MaxHeightScrollView sv = new MaxHeightScrollView(this);
                sv.setMaxHeight((int) (getResources().getDisplayMetrics().heightPixels * 0.5f));
                sv.setFocusable(true);
                sv.addView(body, new ViewGroup.LayoutParams(-1, -2));
                content.addView(sv, new LinearLayout.LayoutParams(-1, -2));
            } else {
                content.addView(body, new LinearLayout.LayoutParams(-1, -2));
            }
        }
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.END);
        View pos = null;
        if (neutral != null) btns.addView(macButton(neutral, 0x33FFFFFF, onNeutral, holder), btnLp());
        if (negative != null) btns.addView(macButton(negative, 0x33FFFFFF, null, holder), btnLp());
        if (positive != null) {
            pos = macButton(positive, 0xFF0A84FF, onPositive, holder);
            btns.addView(pos, btnLp());
        }
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.setMargins(0, dp(14), 0, 0);
        content.addView(btns, bp);
        win.addView(content, new LinearLayout.LayoutParams(-1, -2));
        holder[0] = showMacDialog(win, widthDp, onDismiss);
        if (pos != null) pos.requestFocus();
        return holder[0];
    }

    private Dialog macMessage(String title, String message, String positive, Runnable onPositive,
                              String negative) {
        TextView m = new TextView(this);
        m.setText(message);
        m.setTextColor(0xE6FFFFFF);
        m.setTextSize(14);
        return macDialog(title, m, 520, positive, onPositive, null, null, negative, false);
    }

    interface EditResult {
        void done(String[] values);
    }

    private Drawable editBg() {
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable focused = rounded(0x26FFFFFF, 10);
        focused.setStroke(Math.max(2, dp(2)), 0xFF0A84FF);
        sl.addState(new int[]{android.R.attr.state_focused}, focused);
        sl.addState(new int[]{}, rounded(0x26FFFFFF, 10));
        return sl;
    }

    private void macEditDialog(String title, String message, String[] hints, String[] initial,
                               final EditResult cb, Runnable onDefault) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        if (message != null) {
            TextView m = new TextView(this);
            m.setText(message);
            m.setTextColor(0xB3FFFFFF);
            m.setTextSize(13);
            LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
            ml.setMargins(0, 0, 0, dp(8));
            body.addView(m, ml);
        }
        final EditText[] ets = new EditText[hints.length];
        for (int i = 0; i < hints.length; i++) {
            EditText et = new EditText(this);
            et.setSingleLine(true);
            et.setHint(hints[i]);
            et.setText(initial[i]);
            et.setTextColor(0xFFFFFFFF);
            et.setHintTextColor(0x66FFFFFF);
            et.setTextSize(15);
            et.setBackground(editBg());
            et.setPadding(dp(14), dp(10), dp(14), dp(10));
            et.setSelection(et.getText().length());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(6), 0, dp(6));
            body.addView(et, lp);
            ets[i] = et;
        }
        macDialog(title, body, 560, tr("Lưu", "Save"), () -> {
            String[] v = new String[ets.length];
            for (int i = 0; i < ets.length; i++) v[i] = ets[i].getText().toString().trim();
            cb.done(v);
        }, onDefault != null ? tr("Mặc định", "Default") : null, onDefault, tr("Hủy", "Cancel"), false);
        ets[0].requestFocus();
    }

    private String appVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** Hình nền hiện tại cắt vuông, dùng làm logo tròn trong khung cài đặt. */
    private Bitmap wallpaperSquare(int size) {
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        String bg = prefs.getString("bg", "preset:0");
        if ("custom".equals(bg) && wallBitmap != null) {
            int w = wallBitmap.getWidth();
            int h = wallBitmap.getHeight();
            int side = Math.min(w, h);
            Rect src = new Rect((w - side) / 2, (h - side) / 2, (w + side) / 2, (h + side) / 2);
            c.drawBitmap(wallBitmap, src, new Rect(0, 0, size, size), null);
        } else {
            c.drawColor(0xFF0D0D10);
            int idx = 0;
            try {
                if (bg.startsWith("preset:")) idx = Integer.parseInt(bg.substring(7));
            } catch (NumberFormatException ignored) {
            }
            if (idx < 0 || idx >= PRESET_COLORS.length) idx = 0;
            if (PRESET_COLORS[idx] != 0) {
                GradientDrawable g = new GradientDrawable();
                g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
                g.setGradientRadius(size * 0.8f);
                g.setGradientCenter(0.35f, 0.30f);
                g.setColors(new int[]{PRESET_COLORS[idx], 0x00000000});
                g.setBounds(0, 0, size, size);
                g.draw(c);
            }
        }
        return out;
    }

    private View profileHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(14), dp(12), dp(14), dp(12));
        h.setFocusable(true);
        h.setClickable(true);
        h.setBackground(macRowBg());

        ImageView av = new ImageView(this);
        av.setScaleType(ImageView.ScaleType.CENTER_CROP);
        av.setImageBitmap(wallpaperSquare(dp(64)));
        av.setClipToOutline(true);
        av.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setOval(0, 0, view.getWidth(), view.getHeight());
            }
        });
        h.addView(av, new LinearLayout.LayoutParams(dp(64), dp(64)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        String n = prefs.getString("name", "").trim();
        TextView name = new TextView(this);
        name.setText(n.isEmpty() ? tr("Đặt tên của bạn", "Set your name") : n);
        name.setTextColor(0xFFFFFFFF);
        name.setTextSize(20);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setSingleLine(true);
        col.addView(name, new LinearLayout.LayoutParams(-2, -2));
        TextView sub = new TextView(this);
        sub.setText(getString(R.string.app_name) + " · " + appVersion());
        sub.setTextColor(0xB3FFFFFF);
        sub.setTextSize(12);
        col.addView(sub, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
        cl.setMargins(dp(16), 0, 0, 0);
        h.addView(col, cl);

        h.setOnFocusChangeListener((v, has) -> {
            if (has) playMove();
        });
        h.setOnClickListener(v -> {
            playSelect();
            askName();
        });
        return h;
    }

    private void showMacMenu(String title, String[] labels, int[] icons, boolean profile,
                             final DialogInterface.OnClickListener listener) {
        showMacMenu(title, labels, icons, null, profile, listener);
    }

    private void showMacMenu(String title, String[] labels, int[] icons, String[] headers, boolean profile,
                             final DialogInterface.OnClickListener listener) {
        LinearLayout win = macWindow(title);
        MaxHeightScrollView sv = new MaxHeightScrollView(this);
        sv.setMaxHeight((int) (getResources().getDisplayMetrics().heightPixels * 0.80f));
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(4), dp(12), dp(14));
        sv.addView(list, new ViewGroup.LayoutParams(-1, -2));
        win.addView(sv, new LinearLayout.LayoutParams(-1, -2));

        final Dialog[] holder = new Dialog[1];
        if (profile) list.addView(profileHeader(), new LinearLayout.LayoutParams(-1, -2));
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            if (headers != null && headers[i] != null) list.addView(sectionHeader(headers[i]));
            View row = macRow(icons[i], PALETTE[i % PALETTE.length], labels[i], v -> {
                playSelect();
                holder[0].dismiss();
                listener.onClick(holder[0], idx);
            });
            addRow(list, row);
        }
        holder[0] = showMacDialog(win, 520, null);
        for (int i = profile ? 1 : 0; i < list.getChildCount(); i++) {
            View c = list.getChildAt(i);
            if (c.isFocusable()) {
                c.requestFocus();
                break;
            }
        }
    }

    // ================================================================ quyền đọc nhạc / ảnh

    private Runnable pendingMedia;

    private String[] mediaPerms() {
        if (Build.VERSION.SDK_INT >= 33) {
            return new String[]{Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_IMAGES};
        }
        return new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    private boolean hasMediaPerm() {
        try {
            for (String p : mediaPerms()) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void withMediaPermission(Runnable r) {
        if (hasMediaPerm()) {
            r.run();
            return;
        }
        pendingMedia = r;
        try {
            requestPermissions(mediaPerms(), REQ_MEDIA);
        } catch (Exception e) {
            toast(tr("TV không hỗ trợ hộp thoại cấp quyền", "This TV cannot show the permission dialog"));
        }
    }

    // ================================================================ trình phát nhạc

    private MediaPlayer player;
    private boolean playerReady = false;
    private List<MediaLibrary.Track> tracks = new ArrayList<>();
    private boolean tracksLoaded = false;
    private int trackIdx = -1;
    private Bitmap coverBitmap;

    // thẻ trên màn hình chính
    private ImageView mcCover;
    private ImageView mcState;
    private TextView mcTitle;
    private TextView mcSub;

    // cửa sổ trình phát
    private boolean panelOpen = false;
    private ImageView pCover;
    private ImageView pPlay;
    private TextView pTitle;
    private TextView pArtist;
    private TextView pElapsed;
    private TextView pTotal;
    private ProgressBar pProgress;
    private ListView pList;
    private BaseAdapter pAdapter;

    private final Runnable panelTick = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            if (panelOpen) handler.postDelayed(this, 500);
        }
    };

    private boolean isPlaying() {
        try {
            return player != null && playerReady && player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
        playerReady = false;
    }

    private void loadTracks(final Runnable done) {
        loadTracks(done, false);
    }

    private void loadTracks(final Runnable done, final boolean deep) {
        new Thread(() -> {
            final List<MediaLibrary.Track> list = MediaLibrary.loadTracks(getApplicationContext(), deep);
            runOnUiThread(() -> {
                tracks = list;
                tracksLoaded = true;
                if (done != null) done.run();
            });
        }).start();
    }

    private void playTrack(int idx) {
        if (idx < 0 || idx >= tracks.size()) return;
        try {
            releasePlayer();
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            mp.setDataSource(this, tracks.get(idx).uri);
            mp.setOnPreparedListener(p -> {
                playerReady = true;
                p.start();
                refreshPlayerUi();
            });
            mp.setOnCompletionListener(p -> nextTrack());
            mp.setOnErrorListener((p, what, extra) -> {
                playerReady = false;
                toast(tr("Không phát được bài này", "Cannot play this track"));
                refreshPlayerUi();
                return true;
            });
            player = mp;
            trackIdx = idx;
            coverBitmap = null;
            mp.prepareAsync();
            loadCoverAsync(idx);
            refreshPlayerUi();
            if (panelOpen && pList != null) pList.smoothScrollToPosition(idx);
        } catch (Exception e) {
            toast(tr("Không phát được bài này", "Cannot play this track"));
        }
    }

    private void togglePlay() {
        if (player == null) {
            if (trackIdx >= 0) playTrack(trackIdx);
            else if (!tracks.isEmpty()) playTrack(0);
            return;
        }
        if (!playerReady) return;
        try {
            if (player.isPlaying()) player.pause();
            else player.start();
        } catch (Exception ignored) {
        }
        refreshPlayerUi();
    }

    private void stopPlayback() {
        releasePlayer();
        refreshPlayerUi();
        updateProgress();
    }

    private void nextTrack() {
        if (tracks.isEmpty()) return;
        playTrack((trackIdx + 1) % tracks.size());
    }

    private void prevTrack() {
        if (tracks.isEmpty()) return;
        try {
            if (player != null && playerReady && player.getCurrentPosition() > 3000) {
                player.seekTo(0);
                return;
            }
        } catch (Exception ignored) {
        }
        playTrack(trackIdx <= 0 ? tracks.size() - 1 : trackIdx - 1);
    }

    /** Làm mới danh sách nhạc (quét cả USB mới cắm), giữ nguyên bài đang phát nếu còn. */
    private void refreshMusic() {
        if (!hasMediaPerm()) {
            withMediaPermission(this::refreshMusic);
            return;
        }
        final Uri cur = (trackIdx >= 0 && trackIdx < tracks.size()) ? tracks.get(trackIdx).uri : null;
        toast(tr("Đang làm mới danh sách nhạc…", "Refreshing the music list…"));
        loadTracks(() -> {
            int idx = -1;
            if (cur != null) {
                for (int i = 0; i < tracks.size(); i++) {
                    if (cur.equals(tracks.get(i).uri)) {
                        idx = i;
                        break;
                    }
                }
            }
            trackIdx = idx;
            refreshPlayerUi();
            toast(tr("Có " + tracks.size() + " bài hát", tracks.size() + " tracks"));
        }, true);
    }

    private void loadCoverAsync(final int idx) {
        if (idx < 0 || idx >= tracks.size()) return;
        final Uri uri = tracks.get(idx).uri;
        new Thread(() -> {
            final Bitmap b = MediaLibrary.loadCover(getApplicationContext(), uri);
            runOnUiThread(() -> {
                if (trackIdx == idx) {
                    coverBitmap = b;
                    refreshPlayerUi();
                }
            });
        }).start();
    }

    private void setCover(ImageView iv, Bitmap b, int padDp) {
        if (b != null) {
            iv.setPadding(0, 0, 0, 0);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(b);
        } else {
            int p = dp(padDp);
            iv.setPadding(p, p, p, p);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setImageResource(R.drawable.ic_music_dlg);
        }
    }

    private void refreshPlayerUi() {
        MediaLibrary.Track t = (trackIdx >= 0 && trackIdx < tracks.size()) ? tracks.get(trackIdx) : null;
        boolean playing = isPlaying();
        String sub = t != null ? (t.artist.isEmpty() ? tr("Không rõ nghệ sĩ", "Unknown artist") : t.artist)
                : tr("Bộ nhớ máy & USB", "Device & USB");
        Bitmap cover = t != null ? coverBitmap : null;
        if (mcTitle != null && mcSub != null && mcCover != null && mcState != null) {
            mcTitle.setText(t != null ? t.title : tr("Nhạc", "Music"));
            mcSub.setText(sub);
            setCover(mcCover, cover, 12);
            mcState.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        }
        if (panelOpen && pTitle != null && pArtist != null && pCover != null && pPlay != null) {
            pTitle.setText(t != null ? t.title : tr("Chưa chọn bài", "Nothing selected"));
            pArtist.setText(sub);
            setCover(pCover, cover, 32);
            pPlay.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
            if (pAdapter != null) pAdapter.notifyDataSetChanged();
        }
    }

    private void updateProgress() {
        if (!panelOpen || pProgress == null || pElapsed == null || pTotal == null) return;
        try {
            if (player != null && playerReady) {
                int pos = player.getCurrentPosition();
                int dur = player.getDuration();
                pProgress.setProgress(dur > 0 ? (int) (pos * 1000L / dur) : 0);
                pElapsed.setText(MediaLibrary.formatTime(pos));
                pTotal.setText(MediaLibrary.formatTime(dur));
                return;
            }
        } catch (Exception ignored) {
        }
        pProgress.setProgress(0);
        pElapsed.setText("0:00");
        pTotal.setText("0:00");
    }

    private ImageView makeControl(int icon, final Runnable act) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setPadding(dp(10), dp(10), dp(10), dp(10));
        b.setBackgroundResource(R.drawable.pill_bg);
        b.setFocusable(true);
        b.setClickable(true);
        b.setOnFocusChangeListener((v, has) -> {
            if (has) playMove();
        });
        b.setOnClickListener(v -> {
            playSelect();
            act.run();
        });
        return b;
    }

    private void addControl(LinearLayout row, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        lp.setMargins(0, 0, dp(10), 0);
        row.addView(v, lp);
    }

    private void openMusicPanel() {
        withMediaPermission(() -> {
            if (!tracksLoaded) loadTracks(this::showMusicPanel);
            else showMusicPanel();
        });
    }

    private void showMusicPanel() {
        dismissDialog();
        LinearLayout win = macWindow(tr("Nhạc", "Music"));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setPadding(dp(20), dp(8), dp(20), dp(12));

        pCover = new ImageView(this);
        pCover.setBackground(rounded(0x1FFFFFFF, 14));
        roundCorners(pCover, dp(14));
        head.addView(pCover, new LinearLayout.LayoutParams(dp(128), dp(128)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(0, dp(128), 1f);
        il.setMargins(dp(20), 0, 0, 0);

        pTitle = new TextView(this);
        pTitle.setTextColor(0xFFFFFFFF);
        pTitle.setTextSize(20);
        pTitle.setTypeface(Typeface.DEFAULT_BOLD);
        pTitle.setSingleLine(true);
        pTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        info.addView(pTitle, new LinearLayout.LayoutParams(-1, -2));

        pArtist = new TextView(this);
        pArtist.setTextColor(0xB3FFFFFF);
        pArtist.setTextSize(13);
        pArtist.setSingleLine(true);
        info.addView(pArtist, new LinearLayout.LayoutParams(-1, -2));
        info.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1f));

        pProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pProgress.setMax(1000);
        pProgress.setProgressDrawable(getDrawable(R.drawable.bar_progress));
        info.addView(pProgress, new LinearLayout.LayoutParams(-1, dp(4)));

        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.HORIZONTAL);
        pElapsed = new TextView(this);
        pElapsed.setTextColor(0x99FFFFFF);
        pElapsed.setTextSize(11);
        pTotal = new TextView(this);
        pTotal.setTextColor(0x99FFFFFF);
        pTotal.setTextSize(11);
        times.addView(pElapsed, new LinearLayout.LayoutParams(0, -2, 1f));
        times.addView(pTotal, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.setMargins(0, dp(4), 0, dp(8));
        info.addView(times, tp);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        addControl(controls, makeControl(R.drawable.ic_prev, this::prevTrack));
        pPlay = makeControl(R.drawable.ic_play, this::togglePlay);
        addControl(controls, pPlay);
        addControl(controls, makeControl(R.drawable.ic_stop, this::stopPlayback));
        addControl(controls, makeControl(R.drawable.ic_next, this::nextTrack));
        addControl(controls, makeControl(R.drawable.ic_refresh, this::refreshMusic));
        info.addView(controls, new LinearLayout.LayoutParams(-2, -2));

        head.addView(info, il);
        win.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // danh sách bài (cuộn) ở dưới
        FrameLayout listBox = new FrameLayout(this);
        listBox.setPadding(dp(12), 0, dp(12), dp(12));
        pList = new ListView(this);
        pList.setDivider(null);
        pList.setVerticalScrollBarEnabled(false);
        pList.setSelector(R.drawable.row_selector);
        pAdapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return tracks.size();
            }

            @Override
            public Object getItem(int i) {
                return tracks.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View convertView, ViewGroup parent) {
                MediaLibrary.Track t = tracks.get(i);
                boolean cur = i == trackIdx;
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(7), dp(12), dp(7));
                if (cur) row.setBackground(rounded(0x26FFFFFF, 8));

                TextView n = new TextView(MainActivity.this);
                n.setText(cur ? "♪" : String.valueOf(i + 1));
                n.setTextColor(cur ? 0xFFFF375F : 0x99FFFFFF);
                n.setTextSize(12);
                n.setMinWidth(dp(30));
                row.addView(n, new LinearLayout.LayoutParams(-2, -2));

                LinearLayout col = new LinearLayout(MainActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                TextView ttl = new TextView(MainActivity.this);
                ttl.setText(t.title);
                ttl.setTextColor(cur ? 0xFFFF375F : 0xFFFFFFFF);
                ttl.setTextSize(14);
                ttl.setSingleLine(true);
                ttl.setEllipsize(android.text.TextUtils.TruncateAt.END);
                col.addView(ttl, new LinearLayout.LayoutParams(-1, -2));
                if (!t.artist.isEmpty()) {
                    TextView art = new TextView(MainActivity.this);
                    art.setText(t.artist);
                    art.setTextColor(0x99FFFFFF);
                    art.setTextSize(11);
                    art.setSingleLine(true);
                    col.addView(art, new LinearLayout.LayoutParams(-1, -2));
                }
                row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

                if (t.duration > 0) {
                    TextView d = new TextView(MainActivity.this);
                    d.setText(MediaLibrary.formatTime(t.duration));
                    d.setTextColor(0x99FFFFFF);
                    d.setTextSize(11);
                    row.addView(d, new LinearLayout.LayoutParams(-2, -2));
                }
                return row;
            }
        };
        pList.setAdapter(pAdapter);
        pList.setOnItemClickListener((parent, view, pos, id) -> {
            playSelect();
            playTrack(pos);
        });
        pList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                playMove();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        TextView empty = new TextView(this);
        empty.setText(tr("Không tìm thấy bài hát.\nCắm USB hoặc chép nhạc vào TV rồi bấm nút làm mới ⟳.",
                "No songs found.\nPlug in a USB drive or copy music to the TV, then press the refresh button ⟳."));
        empty.setTextColor(0x99FFFFFF);
        empty.setTextSize(13);
        empty.setGravity(Gravity.CENTER);
        listBox.addView(pList, new FrameLayout.LayoutParams(-1, -1));
        listBox.addView(empty, new FrameLayout.LayoutParams(-1, -1));
        pList.setEmptyView(empty);
        win.addView(listBox, new LinearLayout.LayoutParams(-1, dp(220)));

        panelOpen = true;
        refreshPlayerUi();
        updateProgress();
        showMacDialog(win, 700, () -> {
            panelOpen = false;
            pCover = null;
            pPlay = null;
            pTitle = null;
            pArtist = null;
            pElapsed = null;
            pTotal = null;
            pProgress = null;
            pList = null;
            pAdapter = null;
            handler.removeCallbacks(panelTick);
        });
        handler.removeCallbacks(panelTick);
        handler.post(panelTick);
        if (pPlay != null) pPlay.requestFocus();
    }

    private View makeMusicCard() {
        final FrameLayout f = new FrameLayout(this);
        f.setBackgroundResource(R.drawable.tile_bg);
        f.setClipToOutline(true);
        f.setFocusable(true);
        f.setClickable(true);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(14), dp(10));

        mcCover = new ImageView(this);
        mcCover.setBackground(rounded(0x26FFFFFF, 10));
        roundCorners(mcCover, dp(10));
        row.addView(mcCover, new LinearLayout.LayoutParams(dp(60), dp(60)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        mcTitle = new TextView(this);
        mcTitle.setTextColor(0xFFFFFFFF);
        mcTitle.setTextSize(17);
        mcTitle.setTypeface(Typeface.DEFAULT_BOLD);
        mcTitle.setSingleLine(true);
        mcTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(mcTitle, new LinearLayout.LayoutParams(-1, -2));
        mcSub = new TextView(this);
        mcSub.setTextColor(0xB3FFFFFF);
        mcSub.setTextSize(12);
        mcSub.setSingleLine(true);
        mcSub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(mcSub, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
        cl.setMargins(dp(14), 0, dp(10), 0);
        row.addView(col, cl);

        mcState = new ImageView(this);
        row.addView(mcState, new LinearLayout.LayoutParams(dp(28), dp(28)));
        f.addView(row, new FrameLayout.LayoutParams(-1, -1));

        autoCancelGlow(f);
        f.setOnFocusChangeListener((v, has) -> {
            float sc = has ? 1.04f : 1f;
            f.animate().scaleX(sc).scaleY(sc).setDuration(180).setInterpolator(SMOOTH).start();
            f.setTranslationZ(has ? dp(8) : 0);
            setGlow(f, has, 1.04f);
            if (has) {
                playMove();
                if (movingPkg == null) appName.setText(tr("Nhạc", "Music"));
            }
        });
        f.setOnClickListener(v -> {
            playSelect();
            openMusicPanel();
        });
        f.setOnLongClickListener(v -> {      // giữ OK: phát / tạm dừng nhanh
            playSelect();
            withMediaPermission(() -> {
                if (!tracksLoaded) loadTracks(this::togglePlay);
                else togglePlay();
            });
            return true;
        });
        refreshPlayerUi();
        return f;
    }

    // ================================================================ trình chiếu ảnh

    private ImageView slideView;
    private TextView slideHint;
    private List<Uri> slideUris = new ArrayList<>();
    private boolean slidesLoaded = false;
    private int slideIdx = -1;

    private ImageView fsView;
    private TextView fsCaption;
    private boolean fsPaused = false;
    private int fsIdx = 0;
    private int fsToken = 0;

    private long slideMs() {
        return prefs.getInt("slideSec", 8) * 1000L;
    }

    private final Runnable cardSlideTick = new Runnable() {
        @Override
        public void run() {
            advanceCardSlide();
            handler.postDelayed(this, slideMs());
        }
    };

    private final Runnable fsTick = new Runnable() {
        @Override
        public void run() {
            if (!fsPaused) fsStep(1);
            handler.postDelayed(this, slideMs());
        }
    };

    private void loadSlides(final Runnable done) {
        final Set<String> ids = new HashSet<>(prefs.getStringSet("ssBuckets", new HashSet<String>()));
        new Thread(() -> {
            final List<Uri> list = MediaLibrary.loadImages(getApplicationContext(), ids);
            Collections.shuffle(list);
            runOnUiThread(() -> {
                slideUris = list;
                slidesLoaded = true;
                slideIdx = -1;
                if (done != null) done.run();
            });
        }).start();
    }

    private void fadeTo(final ImageView iv, final Bitmap b) {
        if (iv.getDrawable() == null) {
            iv.setImageBitmap(b);
            iv.setAlpha(0f);
            iv.animate().alpha(1f).setDuration(500).start();
            return;
        }
        iv.animate().alpha(0f).setDuration(250).withEndAction(() -> {
            iv.setImageBitmap(b);
            iv.animate().alpha(1f).setDuration(350).start();
        }).start();
    }

    private void startCardSlides() {
        handler.removeCallbacks(cardSlideTick);
        if (slideView == null || slideHint == null || !prefs.getBoolean("photoFrameOn", true)) return;
        if (!hasMediaPerm()) {
            slideHint.setText(tr("Bấm để cấp quyền và chọn ảnh trình chiếu",
                    "Press to grant access and set up the slideshow"));
            slideHint.setVisibility(View.VISIBLE);
            return;
        }
        if (!slidesLoaded) {
            loadSlides(() -> {
                if (slideUris.isEmpty()) {
                    if (slideHint != null) {
                        slideHint.setText(tr("Chưa thấy ảnh. Giữ OK để chọn thư mục",
                                "No photos found. Hold OK to choose folders"));
                        slideHint.setVisibility(View.VISIBLE);
                    }
                    return;
                }
                advanceCardSlide();
                handler.postDelayed(cardSlideTick, slideMs());
            });
        } else if (!slideUris.isEmpty()) {
            if (slideView.getDrawable() == null) advanceCardSlide();
            handler.postDelayed(cardSlideTick, slideMs());
        }
    }

    private void advanceCardSlide() {
        final ImageView iv = slideView;
        if (iv == null || slideUris.isEmpty()) return;
        slideIdx = (slideIdx + 1) % slideUris.size();
        final Uri uri = slideUris.get(slideIdx);
        new Thread(() -> {
            final Bitmap b = MediaLibrary.loadScaled(getApplicationContext(), uri, 800);
            if (b == null) return;
            runOnUiThread(() -> {
                if (iv == slideView) {
                    fadeTo(iv, b);
                    if (slideHint != null) slideHint.setVisibility(View.GONE);
                }
            });
        }).start();
    }

    private View makePhotoCard() {
        final FrameLayout f = new FrameLayout(this);
        f.setBackgroundResource(R.drawable.tile_bg);
        f.setClipToOutline(true);
        f.setFocusable(true);
        f.setClickable(true);

        slideView = new ImageView(this);
        slideView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        f.addView(slideView, new FrameLayout.LayoutParams(-1, -1));

        TextView label = new TextView(this);
        label.setText(tr("Trình chiếu ảnh", "Photo slideshow"));
        label.setTextColor(0xFFFFFFFF);
        label.setTextSize(13);
        label.setSingleLine(true);
        label.setPadding(dp(12), dp(16), dp(12), dp(8));
        label.setBackgroundResource(R.drawable.scrim);
        f.addView(label, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        slideHint = new TextView(this);
        slideHint.setText(tr("Bấm để chọn ảnh trình chiếu", "Press to set up the slideshow"));
        slideHint.setTextColor(0xB3FFFFFF);
        slideHint.setTextSize(13);
        slideHint.setGravity(Gravity.CENTER);
        f.addView(slideHint, new FrameLayout.LayoutParams(-1, -1));

        autoCancelGlow(f);
        f.setOnFocusChangeListener((v, has) -> {
            float sc = has ? 1.04f : 1f;
            f.animate().scaleX(sc).scaleY(sc).setDuration(180).setInterpolator(SMOOTH).start();
            f.setTranslationZ(has ? dp(8) : 0);
            setGlow(f, has, 1.04f);
            if (has) {
                playMove();
                if (movingPkg == null) appName.setText(tr("Trình chiếu ảnh", "Photo slideshow"));
            }
        });
        f.setOnClickListener(v -> {
            playSelect();
            openSlideshow();
        });
        f.setOnLongClickListener(v -> {
            playSelect();
            showMediaSettings();
            return true;
        });
        if (!safeMode) startCardSlides();
        return f;
    }

    private void openSlideshow() {
        withMediaPermission(() -> {
            if (!slidesLoaded) loadSlides(this::showSlideshow);
            else showSlideshow();
        });
    }

    private void fsStep(int delta) {
        final int n = slideUris.size();
        if (n == 0 || fsView == null) return;
        fsIdx = ((fsIdx + delta) % n + n) % n;
        final int token = ++fsToken;
        final int idx = fsIdx;
        final Uri uri = slideUris.get(idx);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final int dim = Math.min(1920, Math.max(dm.widthPixels, dm.heightPixels));
        new Thread(() -> {
            final Bitmap b = MediaLibrary.loadScaled(getApplicationContext(), uri, dim);
            runOnUiThread(() -> {
                if (token != fsToken || fsView == null || b == null) return;
                fadeTo(fsView, b);
                if (fsCaption != null) fsCaption.setText((idx + 1) + " / " + n);
            });
        }).start();
    }

    private void showSlideshow() {
        if (slideUris.isEmpty()) {
            toast(tr("Không tìm thấy ảnh. Chọn thư mục ảnh trong Cài đặt → Nhạc & ảnh",
                    "No photos found. Choose folders in Settings → Music & photos"));
            showMediaSettings();
            return;
        }
        dismissDialog();
        final Dialog d = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        fsView = new ImageView(this);
        fsView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(fsView, new FrameLayout.LayoutParams(-1, -1));
        fsCaption = new TextView(this);
        fsCaption.setTextColor(0xB3FFFFFF);
        fsCaption.setTextSize(12);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        cp.setMargins(dp(24), 0, 0, dp(18));
        root.addView(fsCaption, cp);
        d.setContentView(root);

        fsPaused = false;
        fsIdx = Math.max(0, slideIdx) - 1;
        d.setOnKeyListener((dlg, keyCode, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            switch (keyCode) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    fsStep(-1);
                    handler.removeCallbacks(fsTick);
                    handler.postDelayed(fsTick, slideMs());
                    return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    fsStep(1);
                    handler.removeCallbacks(fsTick);
                    handler.postDelayed(fsTick, slideMs());
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                    fsPaused = !fsPaused;
                    toast(fsPaused ? tr("Tạm dừng", "Paused") : tr("Tiếp tục", "Playing"));
                    return true;
                default:
                    return false;
            }
        });
        presentDialog(d, () -> {
            handler.removeCallbacks(fsTick);
            fsView = null;
            fsCaption = null;
            fsToken++;
        });
        fsStep(1);
        handler.removeCallbacks(fsTick);
        handler.postDelayed(fsTick, slideMs());
    }

    // ================================================================ cài đặt nhạc & ảnh

    private void showMediaSettings() {
        String[] items = {
                tr("Chọn thư mục ảnh trình chiếu…", "Choose slideshow folders…"),
                tr("Thời gian chuyển ảnh: ", "Seconds per photo: ") + prefs.getInt("slideSec", 8) + "s",
                tr("Làm mới thư viện nhạc & ảnh", "Refresh music & photo library")};
        int[] icons = {R.drawable.ic_image, R.drawable.ic_tune, R.drawable.ic_music_dlg};
        showMacMenu(tr("Nhạc & ảnh", "Music & photos"), items, icons, false, (dlg, which) -> {
            if (which == 0) {
                chooseSlideFolders();
            } else if (which == 1) {
                chooseSlideSeconds();
            } else {
                slidesLoaded = false;
                slideIdx = -1;
                withMediaPermission(() -> {
                    refreshMusic();
                    startCardSlides();
                });
            }
        });
    }

    private void chooseSlideSeconds() {
        final int[] opts = {3, 5, 8, 15, 30};
        LinearLayout win = macWindow(tr("Thời gian chuyển ảnh", "Seconds per photo"));
        LinearLayout list = macListBox(win);
        final Dialog[] holder = new Dialog[1];
        int cur = prefs.getInt("slideSec", 8);
        for (int i = 0; i < opts.length; i++) {
            final int sec = opts[i];
            addRow(list, macRowEx(R.drawable.ic_tune, PALETTE[i % PALETTE.length],
                    sec + tr(" giây", " seconds"), sec == cur ? "✓" : "", v -> {
                        playSelect();
                        holder[0].dismiss();
                        prefs.edit().putInt("slideSec", sec).apply();
                        startCardSlides();
                    }));
        }
        holder[0] = showMacDialog(win, 440, null);
        focusFirst(list, 0);
    }

    private void chooseSlideFolders() {
        withMediaPermission(() -> new Thread(() -> {
            final List<MediaLibrary.Album> albums = MediaLibrary.loadAlbums(getApplicationContext());
            runOnUiThread(() -> showFolderDialog(albums));
        }).start());
    }

    private void showFolderDialog(final List<MediaLibrary.Album> albums) {
        if (albums.isEmpty()) {
            toast(tr("Không thấy thư mục ảnh nào", "No photo folders found"));
            return;
        }
        final Set<String> sel = new HashSet<>(prefs.getStringSet("ssBuckets", new HashSet<String>()));
        String[] labels = new String[albums.size()];
        boolean[] checked = new boolean[albums.size()];
        for (int i = 0; i < albums.size(); i++) {
            MediaLibrary.Album a = albums.get(i);
            labels[i] = a.name + " (" + a.count + ")";
            checked[i] = sel.contains(a.id);
        }
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Thư mục ảnh trình chiếu (bộ nhớ, USB)", "Slideshow folders (storage, USB)"))
                .setMultiChoiceItems(labels, checked, (dlg, which, isChecked) -> {
                    if (isChecked) sel.add(albums.get(which).id);
                    else sel.remove(albums.get(which).id);
                })
                .setPositiveButton(tr("Lưu", "Save"), (dlg, w) -> {
                    prefs.edit().putStringSet("ssBuckets", sel).apply();
                    slidesLoaded = false;
                    slideIdx = -1;
                    startCardSlides();
                    toast(tr("Đã lưu", "Saved"));
                })
                .setNeutralButton(tr("Tất cả ảnh", "All photos"), (dlg, w) -> {
                    prefs.edit().remove("ssBuckets").apply();
                    slidesLoaded = false;
                    slideIdx = -1;
                    startCardSlides();
                })
                .setNegativeButton(tr("Hủy", "Cancel"), null));
    }

    // ================================================================ khung nhạc + ảnh trên màn hình chính

    private void buildMediaFrame() {
        mediaFrame.removeAllViews();
        mcTitle = null;
        mcSub = null;
        mcCover = null;
        mcState = null;
        slideView = null;
        slideHint = null;
        handler.removeCallbacks(cardSlideTick);
        boolean musicOn = prefs.getBoolean("musicFrameOn", true);
        boolean photoOn = prefs.getBoolean("photoFrameOn", true);
        mediaSection.setVisibility(musicOn || photoOn ? View.VISIBLE : View.GONE);
        if (musicOn) addMediaCard(makeMusicCard());
        if (photoOn) addMediaCard(makePhotoCard());
    }

    private void addMediaCard(View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(92), 1f);
        lp.setMargins(dp(8), dp(4), dp(8), dp(4));
        mediaFrame.addView(v, lp);
    }

    // ================================================================ gán phím mở ứng dụng

    private Map<Integer, String> keyMap() {
        Map<Integer, String> m = new LinkedHashMap<>();
        for (String e : prefs.getString("keymap", "").split(",")) {
            int i = e.indexOf(':');
            if (i <= 0) continue;
            try {
                m.put(Integer.parseInt(e.substring(0, i)), e.substring(i + 1));
            } catch (NumberFormatException ignored) {
            }
        }
        return m;
    }

    private void saveKeyMap(Map<Integer, String> m) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Integer, String> e : m.entrySet()) {
            if (sb.length() > 0) sb.append(',');
            sb.append(e.getKey()).append(':').append(e.getValue());
        }
        prefs.edit().putString("keymap", sb.toString()).apply();
    }

    private String keyName(int code) {
        return KeyEvent.keyCodeToString(code).replace("KEYCODE_", "");
    }

    private String appLabelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    private boolean isReservedKey(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_HOME:
            case KeyEvent.KEYCODE_ESCAPE:
            case KeyEvent.KEYCODE_CHANNEL_UP:
            case KeyEvent.KEYCODE_CHANNEL_DOWN:
            case KeyEvent.KEYCODE_PAGE_UP:
            case KeyEvent.KEYCODE_PAGE_DOWN:
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
            case KeyEvent.KEYCODE_VOLUME_MUTE:
            case KeyEvent.KEYCODE_POWER:
            case KeyEvent.KEYCODE_UNKNOWN:
                return true;
            default:
                return false;
        }
    }

    private void showKeyMapMenu() {
        final Map<Integer, String> m = keyMap();
        final List<Integer> codes = new ArrayList<>(m.keySet());
        String[] labels = new String[codes.size() + 1];
        int[] icons = new int[labels.length];
        for (int i = 0; i < codes.size(); i++) {
            labels[i] = keyName(codes.get(i)) + "  →  " + appLabelOf(m.get(codes.get(i)));
            icons[i] = R.drawable.ic_remote;
        }
        labels[codes.size()] = tr("+ Thêm gán phím", "+ Add key shortcut");
        icons[codes.size()] = R.drawable.ic_tune;
        showMacMenu(tr("Gán phím mở ứng dụng", "Key shortcuts for apps"), labels, icons, false, (dlg, which) -> {
            if (which == codes.size()) pickAppForKey();
            else confirmRemoveKey(codes.get(which));
        });
    }

    private void confirmRemoveKey(final int code) {
        String app = keyMap().get(code);
        macMessage(tr("Xóa gán phím ", "Remove shortcut ") + keyName(code) + "?",
                app == null ? "" : appLabelOf(app), tr("Xóa", "Remove"), () -> {
                    Map<Integer, String> m = keyMap();
                    m.remove(code);
                    saveKeyMap(m);
                    toast(tr("Đã xóa", "Removed"));
                }, tr("Hủy", "Cancel"));
    }

    private void pickAppForKey() {
        final List<AppItem> list = new ArrayList<>();
        for (AppItem a : apps) if (!a.self) list.add(a);
        String[] labels = new String[list.size()];
        int[] icons = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            labels[i] = list.get(i).label;
            icons[i] = R.drawable.ic_apps;
        }
        showMacMenu(tr("Chọn ứng dụng", "Choose an app"), labels, icons, false,
                (dlg, which) -> captureKey(list.get(which)));
    }

    private void captureKey(final AppItem a) {
        Dialog d = macMessage(tr("Gán phím", "Assign key"),
                tr("Bấm một phím trên remote để mở ", "Press a remote key to open ") + a.label
                        + tr("\n\n(Bấm Back để hủy)", "\n\n(Press Back to cancel)"),
                null, null, tr("Hủy", "Cancel"));
        d.setOnKeyListener((dlg, keyCode, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_BACK) return false;
            if (isReservedKey(keyCode)) {
                toast(tr("Phím này dùng để điều hướng, hãy chọn phím khác",
                        "This key is used for navigation, pick another"));
                return true;
            }
            Map<Integer, String> m = keyMap();
            m.put(keyCode, a.pkg);
            saveKeyMap(m);
            dlg.dismiss();
            toast(keyName(keyCode) + " → " + a.label);
            return true;
        });
    }

    private boolean launchByKey(int keyCode) {
        String pkg = keyMap().get(keyCode);
        if (pkg == null) return false;
        AppItem item = findApp(pkg);
        if (item != null) {
            playSelect();
            launch(item, scroll);          // FPT Play → mở thẳng mục Truyền hình
            return true;
        }
        PackageManager pm = getPackageManager();
        Intent li = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (li == null) li = pm.getLaunchIntentForPackage(pkg);
        if (li == null) return false;
        try {
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(li);
            playSelect();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ================================================================ launcher mặc định

    private void showDefaultLauncherMenu() {
        String[] items = {
                tr("Để hệ thống hỏi (khuyên dùng)", "Let the system ask (recommended)"),
                tr("ADB qua Wi-Fi", "ADB over Wi-Fi"),
                tr("ADB qua USB", "ADB over USB"),
                tr("Tự động bằng ADB nội bộ", "Automatic with local ADB"),
                tr("Hướng dẫn bật ADB nội bộ", "How to enable local ADB"),
                tr("Khôi phục launcher gốc (khi bị đen màn hình)", "Restore stock launcher (black screen)")};
        int[] icons = {R.drawable.ic_home, R.drawable.ic_wifi, R.drawable.ic_usb, R.drawable.ic_remote,
                R.drawable.ic_info, R.drawable.ic_tv};
        showIconMenu(tr("Đặt launcher mặc định", "Set as default launcher"), items, icons, (dlg, which) -> {
            final String pkg = getPackageName();
            final String set = "adb shell cmd package set-home-activity " + pkg + "/.MainActivity";
            if (which == 0) {
                requestDefaultLauncher();
            } else if (which == 1) {
                String ip = localIp();
                showAdbHelp(tr("ADB qua Wi-Fi", "ADB over Wi-Fi"),
                        tr("1. Trên TV: Cài đặt → Tùy chọn nhà phát triển → bật Gỡ lỗi USB và Gỡ lỗi qua mạng (Wi-Fi).\n"
                                + "2. Máy tính và TV dùng chung mạng Wi-Fi.\n"
                                + "3. Chạy các lệnh dưới đây trên máy tính (Android 11 trở lên cần 'adb pair IP:CỔNG' trước).\n\n"
                                + "Sau khi đặt xong, bấm Home để kiểm tra. Nếu bị đen màn hình, dùng mục Khôi phục launcher gốc.",
                                "1. On the TV: Settings → Developer options → enable USB debugging and network (Wi-Fi) debugging.\n"
                                        + "2. Computer and TV must be on the same Wi-Fi.\n"
                                        + "3. Run the commands below on the computer (Android 11+ needs 'adb pair IP:PORT' first).\n\n"
                                        + "Press Home afterwards to check. If the screen goes black, use Restore stock launcher."),
                        "adb connect " + (ip == null ? "<IP-TV>" : ip) + ":5555\n" + set);
            } else if (which == 2) {
                showAdbHelp(tr("ADB qua USB", "ADB over USB"),
                        tr("1. Bật Gỡ lỗi USB trên TV và nối TV với máy tính bằng cáp USB (cổng hỗ trợ ADB).\n"
                                + "2. Chạy các lệnh dưới đây trên máy tính. Nếu TV hỏi cho phép gỡ lỗi thì chọn Cho phép.",
                                "1. Enable USB debugging on the TV and connect it to the computer with a USB cable.\n"
                                        + "2. Run the commands below. Accept the debugging prompt on the TV if it appears."),
                        "adb devices\n" + set);
            } else if (which == 3) {
                autoSetDefaultLauncher();
            } else if (which == 4) {
                showAdbGuide();
            } else {
                showAdbHelp(tr("Khôi phục launcher gốc", "Restore stock launcher"),
                        tr("Dùng khi màn hình đen hoặc muốn quay về giao diện cũ. Chọn 1 trong 2 lệnh phù hợp với TV "
                                + "(Android TV hoặc Google TV), chạy qua ADB Wi-Fi hoặc USB.",
                                "Use this if the screen is black or you want the old home screen back. "
                                        + "Pick the command that matches your TV (Android TV or Google TV) and run it over ADB Wi-Fi or USB."),
                        "adb shell cmd package set-home-activity com.google.android.tvlauncher/.MainActivity\n"
                                + "adb shell cmd package set-home-activity com.google.android.apps.tv.launcherx/.home.HomeActivity");
            }
        });
    }

    private void requestDefaultLauncher() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                        toast(tr("Đã là launcher mặc định", "Already the default launcher"));
                        return;
                    }
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_ROLE);
                    return;
                }
            }
        } catch (Exception ignored) {
        }
        if (!startSafe(new Intent(Settings.ACTION_HOME_SETTINGS), new Intent(Settings.ACTION_SETTINGS))) {
            toast(tr("TV không hỗ trợ, hãy dùng ADB", "Not supported on this TV, use ADB"));
        }
    }

    private void showAdbHelp(String title, String intro, final String cmd) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        TextView m = new TextView(this);
        m.setText(intro);
        m.setTextColor(0xE6FFFFFF);
        m.setTextSize(13);
        body.addView(m, new LinearLayout.LayoutParams(-1, -2));
        TextView c = new TextView(this);
        c.setText(cmd);
        c.setTextColor(0xFF64D2FF);
        c.setTextSize(12);
        c.setTypeface(Typeface.MONOSPACE);
        c.setBackground(rounded(0x33000000, 10));
        c.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
        cl.setMargins(0, dp(10), 0, 0);
        body.addView(c, cl);
        macDialog(title, body, 560, tr("Sao chép lệnh", "Copy commands"), () -> {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("adb", cmd));
                toast(tr("Đã sao chép", "Copied"));
            } catch (Exception e) {
                toast(tr("Không sao chép được", "Could not copy"));
            }
        }, null, null, tr("Đóng", "Close"), true);
    }

    private String localIp() {
        try {
            Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
            while (nis.hasMoreElements()) {
                NetworkInterface ni = nis.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress a = addrs.nextElement();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    // ================================================================ hình nền

    private void showWallpaperMenu() {
        final String[] names = en() ? PRESET_EN : PRESET_VI;
        String bg = prefs.getString("bg", "preset:0");
        LinearLayout win = macWindow(tr("Hình nền", "Wallpaper"));
        LinearLayout list = macListBox(win);
        final Dialog[] holder = new Dialog[1];
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            int color = PRESET_COLORS[i] != 0 ? (PRESET_COLORS[i] | 0xFF000000) : 0xFF3A3A3C;
            boolean cur = bg.equals("preset:" + i);
            addRow(list, macRowEx(R.drawable.ic_image, color, names[i], cur ? "✓" : "", v -> {
                playSelect();
                holder[0].dismiss();
                prefs.edit().putString("bg", "preset:" + idx).apply();
                applyBackground();
            }));
        }
        list.addView(sectionHeader(tr("Ảnh của bạn", "Your photos")));
        addNav(list, holder, R.drawable.ic_image, PALETTE[4],
                tr("Chọn ảnh từ điện thoại (quét mã QR)", "Choose a photo from your phone (QR code)"),
                this::showQrUpload);
        addNav(list, holder, R.drawable.ic_image, PALETTE[0],
                tr("Chọn ảnh từ thiết bị…", "Choose a photo from device…"), this::pickImage);
        addNav(list, holder, R.drawable.ic_image, PALETTE[1],
                tr("Chọn ảnh từ thư mục ứng dụng…", "Choose a photo from the app folder…"), this::showLocalImages);
        addNav(list, holder, R.drawable.ic_tune, PALETTE[3], tr("Độ trong suốt…", "Opacity…"),
                this::showOpacityDialog);
        holder[0] = showMacDialog(win, 520, null);
        focusFirst(list, 0);
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try {
            startActivityForResult(i, REQ_PICK_IMAGE);
        } catch (ActivityNotFoundException e) {
            toast(tr("TV này không có trình chọn ảnh, dùng thư mục ứng dụng",
                    "This TV has no photo picker, using the app folder"));
            showLocalImages();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK_IMAGE && res == RESULT_OK && data != null && data.getData() != null) {
            final Uri uri = data.getData();
            applyCustomAsync(() -> getContentResolver().openInputStream(uri));
        } else if (req == REQ_ROLE) {
            toast(res == RESULT_OK ? tr("Đã đặt làm launcher mặc định", "Set as default launcher")
                    : tr("Chưa đặt làm mặc định", "Not set as default"));
        }
    }

    private void showLocalImages() {
        final File dir = getExternalFilesDir("wallpapers");
        File[] found = dir == null ? null : dir.listFiles((d, name) -> {
            String l = name.toLowerCase(Locale.ROOT);
            return l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") || l.endsWith(".webp");
        });
        final String path = dir == null ? "" : dir.getAbsolutePath();
        if (found == null || found.length == 0) {
            present(new AlertDialog.Builder(this)
                    .setTitle(tr("Chưa có ảnh nào", "No photos yet"))
                    .setMessage(tr("Hãy chép ảnh (jpg/png/webp) vào thư mục:\n", "Copy photos (jpg/png/webp) to:\n") + path
                            + tr("\n\nVí dụ từ máy tính:\n", "\n\nExample from a computer:\n")
                            + "adb push photo.jpg " + path + "/")
                    .setPositiveButton(tr("Đóng", "Close"), null));
            return;
        }
        final File[] files = found;
        String[] names = new String[files.length];
        for (int k = 0; k < files.length; k++) names[k] = files[k].getName();
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Chọn ảnh nền", "Choose a wallpaper"))
                .setItems(names, (dlg, which) -> {
                    final File f = files[which];
                    applyCustomAsync(() -> new FileInputStream(f));
                }));
    }

    private void applyCustomAsync(final Opener opener) {
        final DisplayMetrics dm = getResources().getDisplayMetrics();
        new Thread(() -> {
            try {
                Bitmap bm = decodeCover(opener, dm.widthPixels, dm.heightPixels);
                if (bm == null) throw new IOException("decode");
                try (FileOutputStream os = new FileOutputStream(new File(getFilesDir(), "wallpaper.jpg"))) {
                    bm.compress(Bitmap.CompressFormat.JPEG, 90, os);
                }
                prefs.edit().putString("bg", "custom").apply();
                runOnUiThread(() -> {
                    wallBitmap = null;
                    applyBackground();
                    toast(tr("Đã đổi hình nền", "Wallpaper changed"));
                });
            } catch (Exception | OutOfMemoryError e) {
                runOnUiThread(() -> toast(tr("Không đọc được ảnh này", "Could not read this photo")));
            }
        }).start();
    }

    private Bitmap decodeCover(Opener opener, int w, int h) throws IOException {
        BitmapFactory.Options op = new BitmapFactory.Options();
        op.inJustDecodeBounds = true;
        try (InputStream is = opener.open()) {
            BitmapFactory.decodeStream(is, null, op);
        }
        int s = 1;
        while (op.outWidth / (s * 2) >= w && op.outHeight / (s * 2) >= h) s *= 2;
        op.inJustDecodeBounds = false;
        op.inSampleSize = s;
        Bitmap src;
        try (InputStream is = opener.open()) {
            src = BitmapFactory.decodeStream(is, null, op);
        }
        if (src == null) return null;

        float scale = Math.max((float) w / src.getWidth(), (float) h / src.getHeight());
        int cw = Math.min(src.getWidth(), Math.round(w / scale));
        int ch = Math.min(src.getHeight(), Math.round(h / scale));
        int x = Math.max(0, (src.getWidth() - cw) / 2);
        int y = Math.max(0, (src.getHeight() - ch) / 2);
        Bitmap crop = Bitmap.createBitmap(src, x, y, cw, ch);
        return Bitmap.createScaledBitmap(crop, w, h, true);
    }

    private void applyBackground() {
        int pct = prefs.getInt("bgAlpha", 100);
        String bg = prefs.getString("bg", "preset:0");
        Drawable wall = null;
        if ("custom".equals(bg)) {
            if (wallBitmap == null) {
                File f = new File(getFilesDir(), "wallpaper.jpg");
                if (f.exists()) wallBitmap = BitmapFactory.decodeFile(f.getPath());
            }
            if (wallBitmap != null) {
                wall = new LayerDrawable(new Drawable[]{
                        new BitmapDrawable(getResources(), wallBitmap),
                        new ColorDrawable(0x66000000)});
            }
        }
        if (wall == null) {
            int idx = 0;
            try {
                if (bg.startsWith("preset:")) idx = Integer.parseInt(bg.substring(7));
            } catch (NumberFormatException ignored) {
            }
            if (idx < 0 || idx >= PRESET_COLORS.length) idx = 0;
            wall = glowDrawable(PRESET_COLORS[idx]);
        }
        Drawable base = new ColorDrawable(0xFF0D0D10);
        Drawable result = base;
        if (wall != null) {
            wall.setAlpha(Math.max(0, Math.min(255, pct * 255 / 100)));
            result = new LayerDrawable(new Drawable[]{base, wall});
        }
        getWindow().setBackgroundDrawable(result);
    }

    private Drawable glowDrawable(int glow) {
        if (glow == 0) return null;
        GradientDrawable g = new GradientDrawable();
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g.setGradientRadius(getResources().getDisplayMetrics().widthPixels * 0.7f);
        g.setGradientCenter(0.35f, 0.30f);
        g.setColors(new int[]{glow, 0x00000000});
        return g;
    }

    // ================================================================ tiêu đề (lời chào, giờ, lịch, lễ)

    private void updateHeader() {
        Calendar c = Calendar.getInstance();
        lastDay = c.get(Calendar.DAY_OF_YEAR);
        int h = c.get(Calendar.HOUR_OF_DAY);
        int res = h < 12 ? R.string.good_morning : (h < 18 ? R.string.good_afternoon : R.string.good_evening);
        Locale loc = new Locale(lang);
        String g = getString(res);
        if (prefs.getBoolean("nameOn", true)) {
            String name = prefs.getString("name", "").trim();
            if (!name.isEmpty()) g += ", " + name;
        }
        greeting.setText(g.toUpperCase(loc));

        int dd = c.get(Calendar.DAY_OF_MONTH);
        int mm = c.get(Calendar.MONTH) + 1;
        int yy = c.get(Calendar.YEAR);
        int dow = c.get(Calendar.DAY_OF_WEEK) - 1;
        String d = en() ? DAY_EN[dow] + ", " + dd + " " + MON_EN[mm - 1]
                : THU_VI[dow] + ", " + dd + " tháng " + mm;
        dateView.setText(d.toUpperCase(loc));

        int[] lunar = null;
        try {
            lunarView.setText(LunarCalendar.format(dd, mm, yy, en()));
            lunar = LunarCalendar.solarToLunar(dd, mm, yy);
        } catch (Exception e) {
            lunarView.setText("");
        }

        // đếm ngược ngày lễ
        boolean holidayOn = prefs.getBoolean("holidayOn", true);
        holidayView.setVisibility(View.GONE);
        if (holidayOn) {
            try {
                Holidays.Result r = Holidays.next(c, en());
                if (r != null) {
                    String t;
                    if (r.days == 0) {
                        t = tr("Hôm nay là " + r.name, "Today is " + r.name);
                    } else {
                        t = tr("Còn " + r.days + " ngày đến " + r.name,
                                r.days + (r.days == 1 ? " day until " : " days until ") + r.name);
                    }
                    holidayView.setText(t);
                    holidayView.setVisibility(View.VISIBLE);
                }
            } catch (Exception ignored) {
            }
        }

        // thông báo đỏ: mùng 1, 14, 15, cuối tháng âm lịch
        lunarAlert.setVisibility(View.GONE);
        if (prefs.getBoolean("lunarAlertOn", true) && lunar != null) {
            try {
                int ld = lunar[0];
                Calendar t = (Calendar) c.clone();
                t.add(Calendar.DAY_OF_MONTH, 1);
                int[] next = LunarCalendar.solarToLunar(t.get(Calendar.DAY_OF_MONTH),
                        t.get(Calendar.MONTH) + 1, t.get(Calendar.YEAR));
                String msg = null;
                if (ld == 1) {
                    msg = tr("Hôm nay mùng 1 âm lịch", "Today is the 1st of the lunar month");
                } else if (ld == 14) {
                    msg = tr("Hôm nay 14 âm lịch – mai là Rằm", "Lunar 14th today – full moon tomorrow");
                } else if (ld == 15) {
                    msg = tr("Hôm nay Rằm (15 âm lịch)", "Today is the full moon (lunar 15th)");
                } else if (next[0] == 1) {
                    msg = tr("Hôm nay là ngày cuối tháng âm lịch (" + ld + ")",
                            "Last day of the lunar month (" + ld + ")");
                }
                if (msg != null) {
                    lunarAlert.setText("● " + msg);
                    lunarAlert.setVisibility(View.VISIBLE);
                }
            } catch (Exception ignored) {
            }
        }
    }

    // ================================================================ danh sách ứng dụng

    private Set<String> hiddenSet() {
        return new HashSet<>(prefs.getStringSet("hidden", new HashSet<String>()));
    }

    private List<ResolveInfo> queryResolve() {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> list = new ArrayList<>();
        list.addAll(pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0));
        list.addAll(pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0));
        List<ResolveInfo> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : list) {
            if (seen.add(ri.activityInfo.packageName)) out.add(ri);
        }
        return out;
    }

    private String signature(List<ResolveInfo> raw) {
        TreeSet<String> pk = new TreeSet<>();
        for (ResolveInfo ri : raw) pk.add(ri.activityInfo.packageName);
        return pk + "|" + new TreeSet<>(hiddenSet()) + "|" + prefs.getString("order", "")
                + "|" + prefs.getString("tv0", "") + "|" + prefs.getString("tv1", "");
    }

    private void refreshApps(boolean force, String focusPkg) {
        List<ResolveInfo> raw = queryResolve();
        String sig = signature(raw);
        if (!force && sig.equals(lastSignature)) return;
        lastSignature = sig;

        PackageManager pm = getPackageManager();
        Set<String> hidden = hiddenSet();
        List<AppItem> items = new ArrayList<>();
        for (ResolveInfo ri : raw) {
            String pkg = ri.activityInfo.packageName;
            if (hidden.contains(pkg)) continue;
            AppItem a = new AppItem();
            a.pkg = pkg;
            a.cls = ri.activityInfo.name;
            a.self = pkg.equals(getPackageName());
            a.label = String.valueOf(ri.loadLabel(pm));
            Drawable bn = ri.activityInfo.loadBanner(pm);
            a.banner = bn != null;
            a.image = bn != null ? bn : ri.loadIcon(pm);
            items.add(a);
        }
        apps = orderApps(items);
        buildViews(focusPkg);
    }

    private List<AppItem> defaultOrder(List<AppItem> items) {
        List<AppItem> sorted = new ArrayList<>(items);
        Collections.sort(sorted, (x, y) -> x.label.compareToIgnoreCase(y.label));
        List<AppItem> out = new ArrayList<>();
        for (String key : DOCK_PREF) {
            for (AppItem a : sorted) {
                if (!a.self && !out.contains(a) && a.label.toLowerCase(Locale.ROOT).contains(key)) {
                    out.add(a);
                    break;
                }
            }
        }
        for (AppItem a : sorted) if (!a.self && !out.contains(a)) out.add(a);
        for (AppItem a : sorted) if (a.self) out.add(a);
        return out;
    }

    private List<AppItem> orderApps(List<AppItem> items) {
        List<AppItem> def = defaultOrder(items);
        String saved = prefs.getString("order", "");
        if (saved.isEmpty()) return def;
        List<AppItem> out = new ArrayList<>();
        for (String p : saved.split(",")) {
            for (AppItem a : def) {
                if (a.pkg.equals(p) && !out.contains(a)) out.add(a);
            }
        }
        for (AppItem a : def) if (!out.contains(a)) out.add(a);
        return out;
    }

    private void buildViews(String focusPkg) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int inner = dm.widthPixels - 2 * dp(48) - 2 * dp(12);
        int margin = dp(8);
        int ringPad = dp(5);
        slotW = inner / COLUMNS;
        tileW = Math.round((slotW - 2 * margin) * APP_SIZE_SCALE);
        tileH = tileW * 9 / 16;

        grid.removeAllViews();
        View gridFocus = null;
        for (int i = COLUMNS; i < apps.size(); i++) {
            AppItem a = apps.get(i);
            View cell = makeTile(a, true);                      // có viền bao ngoài thứ 2
            View tile = ((ViewGroup) cell).getChildAt(0);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = tileW + 2 * ringPad;
            lp.height = tileH + 2 * ringPad;
            int vm = margin - ringPad;
            int hm = Math.max(0, (slotW - lp.width) / 2);
            lp.setMargins(hm, vm, hm, vm);
            grid.addView(cell, lp);
            if (a.pkg.equals(focusPkg)) gridFocus = tile;
        }
        View[] dk = fillDock(focusPkg);
        buildTvFrame();
        buildMediaFrame();
        View target = dk[0] != null ? dk[0] : (gridFocus != null ? gridFocus : dk[1]);
        if (target != null) {
            quiet = true;
            target.requestFocus();
            quiet = false;
        }
    }

    // ================================================================ thanh 4 ứng dụng có 3 tab (3 chấm màu)

    private static final int[] TAB_COLORS = {0xFFFF5F57, 0xFFFEBC2E, 0xFF28C840};   // đỏ, vàng, xanh lá
    private int dockTab = 0;               // 0: Ứng dụng, 1: Mở gần đây nhất, 2: Thường dùng
    private LinearLayout tabDots;
    private TextView tabTitle;
    private String dockSig = "";

    private void buildTabDots() {
        tabDots.removeAllViews();
        for (int i = 0; i < TAB_COLORS.length; i++) {
            final int idx = i;
            View dot = new View(this);
            dot.setFocusable(true);
            dot.setClickable(true);
            dot.setOnFocusChangeListener((v, has) -> {
                float sc = has ? 1.4f : 1f;
                v.animate().scaleX(sc).scaleY(sc).setDuration(120).start();
                if (has) playMove();
            });
            dot.setOnClickListener(v -> {
                playSelect();
                selectTab(idx);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(14), dp(14));
            lp.setMargins(dp(7), dp(7), dp(7), dp(7));
            tabDots.addView(dot, lp);
        }
        updateTabUi();
    }

    private void updateTabUi() {
        for (int i = 0; i < tabDots.getChildCount(); i++) {
            View d = tabDots.getChildAt(i);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(TAB_COLORS[i]);
            if (i == dockTab) g.setStroke(Math.max(2, dp(2)), 0xFFFFFFFF);
            d.setBackground(g);
            d.setAlpha(i == dockTab ? 1f : 0.5f);
        }
        String[] titles = {tr("Ứng dụng", "Apps"), tr("Mở gần đây nhất", "Recently opened"),
                tr("Thường dùng", "Most used")};
        tabTitle.setText(titles[dockTab]);
    }

    private void selectTab(int t) {
        if (t == dockTab) return;
        dockTab = t;
        updateTabUi();
        fillDock(null);
    }

    private Map<String, Integer> launchCounts() {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (String e : prefs.getString("counts", "").split(",")) {
            int i = e.lastIndexOf(':');
            if (i <= 0) continue;
            try {
                m.put(e.substring(0, i), Integer.parseInt(e.substring(i + 1)));
            } catch (NumberFormatException ignored) {
            }
        }
        return m;
    }

    /** Nhớ ứng dụng vừa mở (cho tab "Mở gần đây nhất" và "Thường dùng"). */
    private void recordLaunch(String pkg) {
        if (pkg == null || pkg.equals(getPackageName())) return;
        List<String> r = new ArrayList<>();
        r.add(pkg);
        for (String p : prefs.getString("recents", "").split(",")) {
            if (!p.isEmpty() && !p.equals(pkg) && r.size() < 12) r.add(p);
        }
        Map<String, Integer> c = launchCounts();
        Integer cur = c.get(pkg);
        c.put(pkg, cur == null ? 1 : cur + 1);
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : c.entrySet()) {
            if (sb.length() > 0) sb.append(',');
            sb.append(e.getKey()).append(':').append(e.getValue());
        }
        prefs.edit().putString("recents", android.text.TextUtils.join(",", r))
                .putString("counts", sb.toString()).apply();
    }

    private List<AppItem> tabApps() {
        List<AppItem> out = new ArrayList<>();
        if (dockTab == 0) {
            for (int i = 0; i < apps.size() && i < COLUMNS; i++) out.add(apps.get(i));
        } else if (dockTab == 1) {
            for (String pkg : prefs.getString("recents", "").split(",")) {
                if (pkg.isEmpty()) continue;
                AppItem a = findApp(pkg);
                if (a != null && !a.self && !out.contains(a)) out.add(a);
                if (out.size() >= COLUMNS) break;
            }
        } else {
            final Map<String, Integer> counts = launchCounts();
            List<AppItem> cand = new ArrayList<>();
            for (AppItem a : apps) if (!a.self && counts.containsKey(a.pkg)) cand.add(a);
            Collections.sort(cand, (x, y) -> counts.get(y.pkg) - counts.get(x.pkg));
            for (int i = 0; i < cand.size() && i < COLUMNS; i++) out.add(cand.get(i));
        }
        return out;
    }

    private String dockSignature(List<AppItem> l) {
        StringBuilder sb = new StringBuilder();
        sb.append(dockTab).append('|');
        for (AppItem a : l) sb.append(a.pkg).append(',');
        return sb.toString();
    }

    /** Dựng lại thanh 4 ứng dụng theo tab đang chọn. Trả về {ô khớp focusPkg, ô đầu tiên}. */
    private View[] fillDock(String focusPkg) {
        dock.removeAllViews();
        List<AppItem> list = tabApps();
        dockSig = dockSignature(list);
        int margin = dp(8);
        View focusTile = null;
        View firstTile = null;
        if (list.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(dockTab == 1
                    ? tr("Chưa có ứng dụng nào được mở gần đây", "No recently opened apps yet")
                    : tr("Chưa có dữ liệu", "No data yet"));
            empty.setTextColor(0x99FFFFFF);
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);
            dock.addView(empty, new LinearLayout.LayoutParams(-1, tileH + 2 * margin));
            return new View[]{null, null};
        }
        for (AppItem a : list) {
            View tile = makeTile(a, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tileW, tileH);
            int hm = Math.max(dp(2), (slotW - tileW) / 2);
            lp.setMargins(hm, margin, hm, margin);
            dock.addView(tile, lp);
            if (firstTile == null) firstTile = tile;
            if (a.pkg.equals(focusPkg)) focusTile = tile;
        }
        return new View[]{focusTile, firstTile};
    }

    /** Sau khi quay lại màn hình chính: cập nhật tab "gần đây"/"thường dùng" nếu danh sách đổi. */
    private void refreshTabDock() {
        if (dockTab == 0 || movingPkg != null) return;
        if (!dockSignature(tabApps()).equals(dockSig)) fillDock(null);
    }

    private View makeTile(final AppItem a, boolean ring) {
        final FrameLayout f = new FrameLayout(this);
        f.setBackgroundResource(R.drawable.tile_bg);
        f.setClipToOutline(true);
        f.setFocusable(true);
        f.setClickable(true);

        final ImageView iv = new ImageView(this);
        iv.setImageDrawable(a.image);
        iv.setAlpha(TILE_ALPHA);
        if (a.banner) {
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(dp(20), dp(12), dp(20), dp(12));
        }
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));

        final FrameLayout wrapper = ring ? new FrameLayout(this) : null;
        final View scaleTarget = ring ? wrapper : f;
        if (ring) {
            wrapper.setBackgroundResource(R.drawable.tile_ring);
            wrapper.setClipChildren(false);
            wrapper.addView(f, new FrameLayout.LayoutParams(tileW, tileH, Gravity.CENTER));
        }

        autoCancelGlow(f);
        f.setOnFocusChangeListener((v, has) -> {
            float s = has ? APP_FOCUS_SCALE : 1f;
            scaleTarget.animate().scaleX(s).scaleY(s).setDuration(180).setInterpolator(SMOOTH).start();
            scaleTarget.setTranslationZ(has ? dp(8) : 0);
            setGlow(f, has, APP_FOCUS_SCALE);
            iv.animate().alpha(has ? 1f : TILE_ALPHA).setDuration(180).start();
            if (has) {
                if (movingPkg == null) appName.setText(a.label);
                playMove();
            }
        });
        f.setOnClickListener(v -> {
            playSelect();
            if (a.self) {
                showMenu();
            } else {
                launch(a, v);
            }
        });
        f.setOnLongClickListener(v -> {
            playSelect();
            showTileMenu(a);
            return true;
        });
        return ring ? wrapper : f;
    }

    private void launch(AppItem a, View from) {
        recordLaunch(a.pkg);
        if (isFpt(a) && !fptLink().isEmpty()) {
            launchFptTv(a, from);
            return;
        }
        launchPlain(a, from);
    }

    private void launchPlain(AppItem a, View from) {
        Intent it = new Intent(Intent.ACTION_MAIN)
                .setComponent(new ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ActivityOptions opts = ActivityOptions.makeScaleUpAnimation(
                    from, 0, 0, from.getWidth(), from.getHeight());
            startActivity(it, opts.toBundle());
        } catch (Exception e) {
            try {
                startActivity(it);
            } catch (Exception ignored) {
                toast(tr("Không mở được ", "Cannot open ") + a.label);
            }
        }
    }

    // ================================================================ nhấn giữ ô ứng dụng

    private void showTileMenu(final AppItem a) {
        String move = tr("Di chuyển", "Move");
        String hide = tr("Ẩn", "Hide");
        String del = tr("Xóa", "Uninstall");
        String[] labels = a.self ? new String[]{move, hide} : new String[]{move, hide, del};
        int[] icons = a.self ? new int[]{R.drawable.ic_move, R.drawable.ic_hide}
                : new int[]{R.drawable.ic_move, R.drawable.ic_hide, R.drawable.ic_delete};
        showIconMenu(a.label, labels, icons, (dlg, which) -> {
            if (which == 0) {
                startMove(a);
            } else if (which == 1) {
                Set<String> h = hiddenSet();
                h.add(a.pkg);
                prefs.edit().putStringSet("hidden", h).apply();
                refreshApps(true, null);
                toast(tr("Đã ẩn " + a.label + " (hiện lại trong Cài đặt → Ứng dụng đã ẩn)",
                        a.label + " hidden (restore in Settings → Hidden apps)"));
            } else {
                try {
                    startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                } catch (Exception e) {
                    toast(tr("Không gỡ được ứng dụng này", "Cannot uninstall this app"));
                }
            }
        });
    }

    // ================================================================ tiện ích

    private boolean startSafe(Intent... intents) {
        for (Intent i : intents) {
            try {
                startActivity(i);
                return true;
            } catch (Exception ignored) {
            }
        }
        return false;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
