package vn.launcher.tv;

import android.animation.TimeInterpolator;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.SoundPool;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.PathInterpolator;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends Activity {

    // Ưu tiên đưa các ứng dụng này lên đầu (so khớp theo tên hiển thị)
    private static final String[] DOCK_PREF = {"youtube", "fpt play", "tv360", "vtv"};
    private static final String[] THU = {"Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư",
            "Thứ năm", "Thứ sáu", "Thứ bảy"};

    private static final String[] PRESET_NAMES = {"Đỏ (mặc định)", "Xanh dương", "Tím", "Xanh lá", "Đen"};
    private static final int[] PRESET_COLORS = {0xAAB71C1C, 0xAA1565C0, 0xAA6A1B9A, 0xAA2E7D32, 0};

    private static final int REQ_PICK_IMAGE = 101;
    private static final int COLUMNS = 4;                 // dock và lưới đều 4 cột
    private static final float TILE_ALPHA = 0.6f;         // độ đục hình ứng dụng khi chưa chọn
    private static final long STATUS_INTERVAL = 2000;     // chu kỳ kiểm tra USB / nhạc (ms)
    private static final TimeInterpolator SMOOTH = new PathInterpolator(0.25f, 0.1f, 0.25f, 1f);

    interface Opener {
        InputStream open() throws IOException;
    }

    static class AppItem {
        String label, pkg, cls;
        Drawable image;
        boolean banner, self;
    }

    static class MusicInfo {
        String text;
        PendingIntent open;
    }

    private ScrollView scroll;
    private LinearLayout dock;
    private GridLayout grid;
    private TextView appName, greeting, dateView, lunarView, pillStatus;

    private SharedPreferences prefs;
    private SoundPool sounds;
    private int soundMove, soundSelect;
    private boolean soundOn = true;
    private boolean quiet = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statusTick = new Runnable() {
        @Override
        public void run() {
            updateStatus();
            handler.postDelayed(this, STATUS_INTERVAL);
        }
    };

    private List<AppItem> apps = new ArrayList<>();
    private String lastSignature = "";
    private String statusKey = "";
    private Runnable statusAction;
    private String movingPkg = null;
    private int tileW, tileH;

    // ================================================================ vòng đời

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        soundOn = prefs.getBoolean("sound", true);

        scroll = findViewById(R.id.scroll);
        dock = findViewById(R.id.dock);
        grid = findViewById(R.id.grid);
        appName = findViewById(R.id.app_name);
        greeting = findViewById(R.id.greeting);
        dateView = findViewById(R.id.date);
        lunarView = findViewById(R.id.lunar);
        pillStatus = findViewById(R.id.pill_status);

        initSounds();
        applyBackground();

        int[] pillIds = {R.id.pill_status, R.id.pill_wifi, R.id.pill_settings};
        for (int id : pillIds) {
            findViewById(id).setOnFocusChangeListener((v, has) -> {
                if (has) playMove();
            });
        }
        pillStatus.setOnClickListener(v -> {
            playSelect();
            if (statusAction != null) statusAction.run();
            else startVoiceSearch();
        });
        findViewById(R.id.pill_wifi).setOnClickListener(v -> {
            playSelect();
            startSafe(new Intent(Settings.ACTION_WIFI_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
        });
        findViewById(R.id.pill_settings).setOnClickListener(v -> {
            playSelect();
            showMenu();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateHeader();
        refreshApps(false, null);   // chỉ dựng lại khi danh sách ứng dụng thật sự thay đổi
        handler.removeCallbacks(statusTick);
        handler.post(statusTick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(statusTick);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (movingPkg != null) endMove();
        goHome();                   // bấm Home: chỉ cuộn lên đầu, KHÔNG dựng lại giao diện
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sounds != null) {
            sounds.release();
            sounds = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Là màn hình chính nên không thoát khi bấm Back
    }

    private void goHome() {
        scroll.smoothScrollTo(0, 0);
        View first = dock.getChildAt(0);
        if (first != null && !first.hasFocus()) {
            quiet = true;
            first.requestFocus();
            quiet = false;
        }
    }

    // ================================================================ phím (chế độ di chuyển)

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (movingPkg == null) return super.dispatchKeyEvent(e);
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            switch (e.getKeyCode()) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    moveBy(-1);
                    break;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    moveBy(1);
                    break;
                case KeyEvent.KEYCODE_DPAD_UP:
                    moveBy(-COLUMNS);
                    break;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    moveBy(COLUMNS);
                    break;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_BACK:
                case KeyEvent.KEYCODE_ESCAPE:
                    endMove();
                    break;
                default:
                    return super.dispatchKeyEvent(e);
            }
        }
        return true;
    }

    private void startMove(AppItem a) {
        movingPkg = a.pkg;
        appName.setText("Đang di chuyển: " + a.label);
        toast("Dùng phím mũi tên để di chuyển, bấm OK để xong");
    }

    private void endMove() {
        if (movingPkg == null) return;
        String p = movingPkg;
        movingPkg = null;
        saveOrder();
        for (AppItem a : apps) if (a.pkg.equals(p)) appName.setText(a.label);
        toast("Đã lưu vị trí");
    }

    private void moveBy(int delta) {
        int idx = -1;
        for (int i = 0; i < apps.size(); i++) if (apps.get(i).pkg.equals(movingPkg)) idx = i;
        if (idx < 0) return;
        int n = idx + delta;
        if (n < 0 || n >= apps.size()) return;
        AppItem a = apps.remove(idx);
        apps.add(n, a);
        buildViews(movingPkg);
        appName.setText("Đang di chuyển: " + a.label);
        playMove();
    }

    private void saveOrder() {
        StringBuilder sb = new StringBuilder();
        for (AppItem a : apps) {
            if (sb.length() > 0) sb.append(',');
            sb.append(a.pkg);
        }
        prefs.edit().putString("order", sb.toString()).apply();
        lastSignature = signature(queryResolve());
    }

    // ================================================================ âm thanh

    private void initSounds() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        sounds = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build();
        soundMove = sounds.load(this, R.raw.move, 1);
        soundSelect = sounds.load(this, R.raw.select, 1);
    }

    private void playMove() {
        if (soundOn && !quiet && sounds != null) sounds.play(soundMove, 0.6f, 0.6f, 1, 0, 1f);
    }

    private void playSelect() {
        if (soundOn && sounds != null) sounds.play(soundSelect, 0.7f, 0.7f, 1, 0, 1f);
    }

    // ================================================================ nút trạng thái (giọng nói / USB / nhạc)

    private void updateStatus() {
        String key, text;
        int icon;
        Runnable action;

        final MusicInfo music = currentMusic();
        if (music != null) {
            key = "music:" + music.text;
            text = music.text;
            icon = R.drawable.ic_music;
            action = () -> {
                try {
                    if (music.open != null) {
                        music.open.send();
                        return;
                    }
                } catch (PendingIntent.CanceledException ignored) {
                }
                startSafe(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC));
            };
        } else if (usbConnected()) {
            key = "usb";
            text = "USB đã kết nối";
            icon = R.drawable.ic_usb;
            action = () -> startSafe(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
                    new Intent(Settings.ACTION_SETTINGS));
        } else {
            key = "voice";
            text = getString(R.string.voice_search);
            icon = R.drawable.ic_mic;
            action = this::startVoiceSearch;
        }
        statusAction = action;
        if (!key.equals(statusKey)) {       // chỉ cập nhật khi đổi trạng thái, tránh nhấp nháy
            statusKey = key;
            pillStatus.setText(text);
            pillStatus.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0);
        }
    }

    private MusicInfo currentMusic() {
        try {
            MediaSessionManager msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> list = msm.getActiveSessions(new ComponentName(this, MediaListener.class));
            for (MediaController c : list) {
                PlaybackState ps = c.getPlaybackState();
                if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) {
                    MusicInfo m = new MusicInfo();
                    MediaMetadata md = c.getMetadata();
                    String title = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_TITLE);
                    String artist = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                    if (title == null || title.isEmpty()) {
                        m.text = "Đang phát nhạc";
                    } else {
                        m.text = title + (artist == null || artist.isEmpty() ? "" : " - " + artist);
                    }
                    m.open = c.getSessionActivity();
                    return m;
                }
            }
        } catch (Exception ignored) {
            // chưa cấp quyền đọc thông báo → dùng cách đơn giản bên dưới
        }
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null && am.isMusicActive()) {
                MusicInfo m = new MusicInfo();
                m.text = "Đang phát nhạc";
                return m;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private boolean usbConnected() {
        try {
            UsbManager um = (UsbManager) getSystemService(Context.USB_SERVICE);
            if (um != null) {
                for (UsbDevice d : um.getDeviceList().values()) {
                    for (int i = 0; i < d.getInterfaceCount(); i++) {
                        if (d.getInterface(i).getInterfaceClass() == UsbConstants.USB_CLASS_MASS_STORAGE) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        try {
            StorageManager sm = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
            if (sm != null) {
                for (StorageVolume v : sm.getStorageVolumes()) {
                    if (v.isRemovable() && Environment.MEDIA_MOUNTED.equals(v.getState())) return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void startVoiceSearch() {
        Intent katniss = new Intent(Intent.ACTION_ASSIST).setPackage("com.google.android.katniss");
        boolean ok = startSafe(katniss,
                new Intent(Intent.ACTION_VOICE_COMMAND),
                new Intent("android.intent.action.VOICE_ASSIST"),
                new Intent(Intent.ACTION_ASSIST),
                new Intent(RecognizerIntent.ACTION_WEB_SEARCH));
        if (!ok) toast("Không tìm thấy Google Assistant trên TV này");
    }

    // ================================================================ menu Cài đặt

    private void showMenu() {
        String[] items = {"Cài đặt hệ thống", "Hình nền",
                "Âm thanh di chuyển: " + (soundOn ? "Bật" : "Tắt"),
                "Tên hiển thị", "Hiện bài hát đang phát", "Ứng dụng đã ẩn",
                getString(R.string.info_title)};
        int[] icons = {R.drawable.ic_tv, R.drawable.ic_image, R.drawable.ic_volume,
                R.drawable.ic_person, R.drawable.ic_music_dlg, R.drawable.ic_apps, R.drawable.ic_info};
        showIconMenu("Cài đặt", items, icons, (dlg, which) -> {
            switch (which) {
                case 0:
                    startSafe(new Intent(Settings.ACTION_SETTINGS));
                    break;
                case 1:
                    showWallpaperMenu();
                    break;
                case 2:
                    soundOn = !soundOn;
                    prefs.edit().putBoolean("sound", soundOn).apply();
                    toast("Âm thanh di chuyển: " + (soundOn ? "Bật" : "Tắt"));
                    playSelect();
                    break;
                case 3:
                    showNameMenu();
                    break;
                case 4:
                    toast("Bật quyền cho \"" + getString(R.string.app_name) + "\" để hiện tên bài hát");
                    startSafe(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                    break;
                case 5:
                    showHiddenApps();
                    break;
                default:
                    showInfo();
                    break;
            }
        });
    }

    private void showIconMenu(String title, String[] labels, final int[] icons,
                              DialogInterface.OnClickListener listener) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, labels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setCompoundDrawablesRelativeWithIntrinsicBounds(icons[position], 0, 0, 0);
                t.setCompoundDrawablePadding(dp(16));
                return t;
            }
        };
        new AlertDialog.Builder(this).setTitle(title).setAdapter(adapter, listener).show();
    }

    private void showNameMenu() {
        boolean on = prefs.getBoolean("nameOn", true);
        String name = prefs.getString("name", "").trim();
        String[] items = {"Hiển thị tên: " + (on ? "Bật" : "Tắt"),
                "Đổi tên… (" + (name.isEmpty() ? "chưa đặt" : name) + ")"};
        new AlertDialog.Builder(this)
                .setTitle("Tên hiển thị")
                .setItems(items, (dlg, which) -> {
                    if (which == 0) {
                        prefs.edit().putBoolean("nameOn", !prefs.getBoolean("nameOn", true)).apply();
                        updateHeader();
                    } else {
                        askName();
                    }
                })
                .show();
    }

    private void askName() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(prefs.getString("name", ""));
        et.setSelection(et.getText().length());
        new AlertDialog.Builder(this)
                .setTitle("Nhập tên của bạn")
                .setView(et)
                .setPositiveButton("Lưu", (dlg, w) -> {
                    prefs.edit().putString("name", et.getText().toString().trim())
                            .putBoolean("nameOn", true).apply();
                    updateHeader();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void showHiddenApps() {
        final List<String> hidden = new ArrayList<>(new TreeSet<>(hiddenSet()));
        if (hidden.isEmpty()) {
            toast("Chưa có ứng dụng nào bị ẩn");
            return;
        }
        PackageManager pm = getPackageManager();
        String[] labels = new String[hidden.size()];
        for (int i = 0; i < hidden.size(); i++) {
            try {
                labels[i] = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(hidden.get(i), 0)));
            } catch (Exception e) {
                labels[i] = hidden.get(i);
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("Chọn ứng dụng để hiện lại")
                .setItems(labels, (dlg, which) -> {
                    Set<String> h = hiddenSet();
                    h.remove(hidden.get(which));
                    prefs.edit().putStringSet("hidden", h).apply();
                    refreshApps(true, hidden.get(which));
                    toast("Đã hiện lại ứng dụng");
                })
                .show();
    }

    private void showInfo() {
        String version = "1.0";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        final String url = getString(R.string.info_url);
        String msg = getString(R.string.app_name) + "\n" + getString(R.string.info_description)
                + "\n\nPhiên bản: " + version
                + "\n\nFacebook:\n" + url;
        new AlertDialog.Builder(this)
                .setTitle(R.string.info_title)
                .setMessage(msg)
                .setPositiveButton(R.string.info_open, (dlg, w) -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) {
                        toast("TV chưa có trình duyệt. Hãy truy cập: " + url);
                    }
                })
                .setNegativeButton(R.string.info_close, null)
                .show();
    }

    // ================================================================ hình nền

    private void showWallpaperMenu() {
        final int n = PRESET_NAMES.length;
        String[] items = new String[n + 2];
        System.arraycopy(PRESET_NAMES, 0, items, 0, n);
        items[n] = "Chọn ảnh từ thiết bị…";
        items[n + 1] = "Chọn ảnh từ thư mục ứng dụng…";
        new AlertDialog.Builder(this)
                .setTitle("Hình nền")
                .setItems(items, (dlg, which) -> {
                    if (which < n) {
                        prefs.edit().putString("bg", "preset:" + which).apply();
                        applyBackground();
                    } else if (which == n) {
                        pickImage();
                    } else {
                        showLocalImages();
                    }
                })
                .show();
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try {
            startActivityForResult(i, REQ_PICK_IMAGE);
        } catch (ActivityNotFoundException e) {
            toast("TV này không có trình chọn ảnh, dùng thư mục ứng dụng");
            showLocalImages();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK_IMAGE && res == RESULT_OK && data != null && data.getData() != null) {
            final Uri uri = data.getData();
            applyCustomAsync(() -> getContentResolver().openInputStream(uri));
        }
    }

    private void showLocalImages() {
        final File dir = getExternalFilesDir("wallpapers");
        File[] found = dir == null ? null : dir.listFiles((d, name) -> {
            String l = name.toLowerCase(Locale.ROOT);
            return l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") || l.endsWith(".webp");
        });
        final String path = dir == null ? "" : dir.getAbsolutePath();
        if (found == null || found.length == 0) {
            new AlertDialog.Builder(this)
                    .setTitle("Chưa có ảnh nào")
                    .setMessage("Hãy chép ảnh (jpg/png/webp) vào thư mục:\n" + path
                            + "\n\nVí dụ từ máy tính:\nadb push anh.jpg " + path + "/")
                    .setPositiveButton("Đóng", null)
                    .show();
            return;
        }
        final File[] files = found;
        String[] names = new String[files.length];
        for (int k = 0; k < files.length; k++) names[k] = files[k].getName();
        new AlertDialog.Builder(this)
                .setTitle("Chọn ảnh nền")
                .setItems(names, (dlg, which) -> {
                    final File f = files[which];
                    applyCustomAsync(() -> new FileInputStream(f));
                })
                .show();
    }

    private void applyCustomAsync(final Opener opener) {
        final DisplayMetrics dm = getResources().getDisplayMetrics();
        new Thread(() -> {
            try {
                Bitmap bm = decodeCover(opener, dm.widthPixels, dm.heightPixels);
                if (bm == null) throw new IOException("decode");
                try (FileOutputStream os = new FileOutputStream(new File(getFilesDir(), "wallpaper.jpg"))) {
                    bm.compress(Bitmap.CompressFormat.JPEG, 90, os);
                }
                prefs.edit().putString("bg", "custom").apply();
                runOnUiThread(() -> {
                    applyBackground();
                    toast("Đã đổi hình nền");
                });
            } catch (Exception | OutOfMemoryError e) {
                runOnUiThread(() -> toast("Không đọc được ảnh này"));
            }
        }).start();
    }

    private Bitmap decodeCover(Opener opener, int w, int h) throws IOException {
        BitmapFactory.Options op = new BitmapFactory.Options();
        op.inJustDecodeBounds = true;
        try (InputStream is = opener.open()) {
            BitmapFactory.decodeStream(is, null, op);
        }
        int s = 1;
        while (op.outWidth / (s * 2) >= w && op.outHeight / (s * 2) >= h) s *= 2;
        op.inJustDecodeBounds = false;
        op.inSampleSize = s;
        Bitmap src;
        try (InputStream is = opener.open()) {
            src = BitmapFactory.decodeStream(is, null, op);
        }
        if (src == null) return null;

        float scale = Math.max((float) w / src.getWidth(), (float) h / src.getHeight());
        int cw = Math.min(src.getWidth(), Math.round(w / scale));
        int ch = Math.min(src.getHeight(), Math.round(h / scale));
        int x = Math.max(0, (src.getWidth() - cw) / 2);
        int y = Math.max(0, (src.getHeight() - ch) / 2);
        Bitmap crop = Bitmap.createBitmap(src, x, y, cw, ch);
        return Bitmap.createScaledBitmap(crop, w, h, true);
    }

    private void applyBackground() {
        String bg = prefs.getString("bg", "preset:0");
        Drawable d = null;
        if ("custom".equals(bg)) {
            File f = new File(getFilesDir(), "wallpaper.jpg");
            if (f.exists()) {
                Bitmap bm = BitmapFactory.decodeFile(f.getPath());
                if (bm != null) {
                    d = new LayerDrawable(new Drawable[]{
                            new BitmapDrawable(getResources(), bm),
                            new ColorDrawable(0x66000000)});
                }
            }
        }
        if (d == null) {
            int idx = 0;
            try {
                if (bg.startsWith("preset:")) idx = Integer.parseInt(bg.substring(7));
            } catch (NumberFormatException ignored) {
            }
            if (idx < 0 || idx >= PRESET_COLORS.length) idx = 0;
            d = presetDrawable(PRESET_COLORS[idx]);
        }
        getWindow().setBackgroundDrawable(d);
    }

    private Drawable presetDrawable(int glow) {
        ColorDrawable base = new ColorDrawable(0xFF0D0D10);
        if (glow == 0) return base;
        GradientDrawable g = new GradientDrawable();
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g.setGradientRadius(getResources().getDisplayMetrics().widthPixels * 0.7f);
        g.setGradientCenter(0.35f, 0.30f);
        g.setColors(new int[]{glow, 0x00000000});
        return new LayerDrawable(new Drawable[]{base, g});
    }

    // ================================================================ tiêu đề (lời chào, giờ, lịch)

    private void updateHeader() {
        Calendar c = Calendar.getInstance();
        int h = c.get(Calendar.HOUR_OF_DAY);
        int res = h < 12 ? R.string.good_morning : (h < 18 ? R.string.good_afternoon : R.string.good_evening);
        Locale vi = new Locale("vi");
        String g = getString(res);
        if (prefs.getBoolean("nameOn", true)) {
            String name = prefs.getString("name", "").trim();
            if (!name.isEmpty()) g += ", " + name;
        }
        greeting.setText(g.toUpperCase(vi));
        String d = THU[c.get(Calendar.DAY_OF_WEEK) - 1] + ", " + c.get(Calendar.DAY_OF_MONTH)
                + " tháng " + (c.get(Calendar.MONTH) + 1);
        dateView.setText(d.toUpperCase(vi));
        lunarView.setText(LunarCalendar.format(c.get(Calendar.DAY_OF_MONTH),
                c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR)));
    }

    // ================================================================ danh sách ứng dụng

    private Set<String> hiddenSet() {
        return new HashSet<>(prefs.getStringSet("hidden", new HashSet<String>()));
    }

    private List<ResolveInfo> queryResolve() {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> list = new ArrayList<>();
        list.addAll(pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0));
        list.addAll(pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0));
        List<ResolveInfo> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : list) {
            if (seen.add(ri.activityInfo.packageName)) out.add(ri);
        }
        return out;
    }

    private String signature(List<ResolveInfo> raw) {
        TreeSet<String> pk = new TreeSet<>();
        for (ResolveInfo ri : raw) pk.add(ri.activityInfo.packageName);
        return pk + "|" + new TreeSet<>(hiddenSet()) + "|" + prefs.getString("order", "");
    }

    private void refreshApps(boolean force, String focusPkg) {
        List<ResolveInfo> raw = queryResolve();
        String sig = signature(raw);
        if (!force && sig.equals(lastSignature)) return;   // không đổi → giữ nguyên, không nhấp nháy
        lastSignature = sig;

        PackageManager pm = getPackageManager();
        Set<String> hidden = hiddenSet();
        List<AppItem> items = new ArrayList<>();
        for (ResolveInfo ri : raw) {
            String pkg = ri.activityInfo.packageName;
            if (hidden.contains(pkg)) continue;
            AppItem a = new AppItem();
            a.pkg = pkg;
            a.cls = ri.activityInfo.name;
            a.self = pkg.equals(getPackageName());
            a.label = String.valueOf(ri.loadLabel(pm));
            Drawable bn = ri.activityInfo.loadBanner(pm);
            a.banner = bn != null;
            a.image = bn != null ? bn : ri.loadIcon(pm);
            items.add(a);
        }
        apps = orderApps(items);
        buildViews(focusPkg);
    }

    private List<AppItem> defaultOrder(List<AppItem> items) {
        List<AppItem> sorted = new ArrayList<>(items);
        Collections.sort(sorted, (x, y) -> x.label.compareToIgnoreCase(y.label));
        List<AppItem> out = new ArrayList<>();
        for (String key : DOCK_PREF) {
            for (AppItem a : sorted) {
                if (!a.self && !out.contains(a) && a.label.toLowerCase(Locale.ROOT).contains(key)) {
                    out.add(a);
                    break;
                }
            }
        }
        for (AppItem a : sorted) if (!a.self && !out.contains(a)) out.add(a);
        for (AppItem a : sorted) if (a.self) out.add(a);
        return out;
    }

    private List<AppItem> orderApps(List<AppItem> items) {
        List<AppItem> def = defaultOrder(items);
        String saved = prefs.getString("order", "");
        if (saved.isEmpty()) return def;
        List<AppItem> out = new ArrayList<>();
        for (String p : saved.split(",")) {
            for (AppItem a : def) {
                if (a.pkg.equals(p) && !out.contains(a)) out.add(a);
            }
        }
        for (AppItem a : def) if (!out.contains(a)) out.add(a);
        return out;
    }

    private void buildViews(String focusPkg) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int inner = dm.widthPixels - 2 * dp(48) - 2 * dp(12);
        int margin = dp(8);
        int ringPad = dp(5);
        tileW = inner / COLUMNS - 2 * margin;
        tileH = tileW * 9 / 16;

        dock.removeAllViews();
        grid.removeAllViews();

        View focusTile = null;
        View firstTile = null;
        for (int i = 0; i < apps.size(); i++) {
            AppItem a = apps.get(i);
            View cell;
            View tile;
            if (i < COLUMNS) {
                tile = makeTile(a, false);
                cell = tile;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tileW, tileH);
                lp.setMargins(margin, margin, margin, margin);
                dock.addView(cell, lp);
            } else {
                cell = makeTile(a, true);                 // có viền bao ngoài thứ 2
                tile = ((ViewGroup) cell).getChildAt(0);
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = tileW + 2 * ringPad;
                lp.height = tileH + 2 * ringPad;
                int m = margin - ringPad;
                lp.setMargins(m, m, m, m);
                grid.addView(cell, lp);
            }
            if (firstTile == null) firstTile = tile;
            if (a.pkg.equals(focusPkg)) focusTile = tile;
        }
        View target = focusTile != null ? focusTile : firstTile;
        if (target != null) {
            quiet = true;
            target.requestFocus();
            quiet = false;
        }
    }

    private View makeTile(final AppItem a, boolean ring) {
        final FrameLayout f = new FrameLayout(this);
        f.setBackgroundResource(R.drawable.tile_bg);
        f.setClipToOutline(true);
        f.setFocusable(true);
        f.setClickable(true);

        final ImageView iv = new ImageView(this);
        iv.setImageDrawable(a.image);
        iv.setAlpha(TILE_ALPHA);
        if (a.banner) {
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(dp(20), dp(12), dp(20), dp(12));
        }
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));

        final FrameLayout wrapper = ring ? new FrameLayout(this) : null;
        final View scaleTarget = ring ? wrapper : f;
        if (ring) {
            wrapper.setBackgroundResource(R.drawable.tile_ring);
            wrapper.setClipChildren(false);
            wrapper.addView(f, new FrameLayout.LayoutParams(tileW, tileH, Gravity.CENTER));
        }

        f.setOnFocusChangeListener((v, has) -> {
            float s = has ? 1.08f : 1f;
            scaleTarget.animate().scaleX(s).scaleY(s).setDuration(180).setInterpolator(SMOOTH).start();
            scaleTarget.setTranslationZ(has ? dp(8) : 0);
            f.setForeground(has ? getDrawable(R.drawable.tile_focus) : null);
            iv.animate().alpha(has ? 1f : TILE_ALPHA).setDuration(180).start();
            if (has) {
                if (movingPkg == null) appName.setText(a.label);
                playMove();
            }
        });
        f.setOnClickListener(v -> {
            playSelect();
            if (a.self) {
                showMenu();
            } else {
                launch(a, v);
            }
        });
        f.setOnLongClickListener(v -> {
            playSelect();
            showTileMenu(a);
            return true;
        });
        return ring ? wrapper : f;
    }

    private void launch(AppItem a, View from) {
        Intent it = new Intent(Intent.ACTION_MAIN)
                .setComponent(new ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            // Hiệu ứng phóng to từ ô ứng dụng ra toàn màn hình như Apple TV
            ActivityOptions opts = ActivityOptions.makeScaleUpAnimation(
                    from, 0, 0, from.getWidth(), from.getHeight());
            startActivity(it, opts.toBundle());
        } catch (Exception e) {
            try {
                startActivity(it);
            } catch (Exception ignored) {
                toast("Không mở được " + a.label);
            }
        }
    }

    // ================================================================ nhấn giữ ô ứng dụng

    private void showTileMenu(final AppItem a) {
        String[] labels = a.self ? new String[]{"Di chuyển", "Ẩn"}
                : new String[]{"Di chuyển", "Ẩn", "Xóa"};
        int[] icons = a.self ? new int[]{R.drawable.ic_move, R.drawable.ic_hide}
                : new int[]{R.drawable.ic_move, R.drawable.ic_hide, R.drawable.ic_delete};
        showIconMenu(a.label, labels, icons, (dlg, which) -> {
            if (which == 0) {
                startMove(a);
            } else if (which == 1) {
                Set<String> h = hiddenSet();
                h.add(a.pkg);
                prefs.edit().putStringSet("hidden", h).apply();
                refreshApps(true, null);
                toast("Đã ẩn " + a.label + " (hiện lại trong Cài đặt → Ứng dụng đã ẩn)");
            } else {
                try {
                    startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                } catch (Exception e) {
                    toast("Không gỡ được ứng dụng này");
                }
            }
        });
    }

    // ================================================================ tiện ích

    private boolean startSafe(Intent... intents) {
        for (Intent i : intents) {
            try {
                startActivity(i);
                return true;
            } catch (Exception ignored) {
            }
        }
        return false;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
