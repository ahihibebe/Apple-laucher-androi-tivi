package vn.launcher.tv;

import android.Manifest;
import android.animation.TimeInterpolator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.SearchManager;
import android.app.role.RoleManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.SoundPool;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.PathInterpolator;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends Activity {

    private static final String[] DOCK_PREF = {"youtube", "fpt play", "tv360", "vtv"};
    private static final String[] TV_KEYS = {"fpt play", "vtvgo", "vtv", "tv360", "vieon", "k+",
            "galaxy play", "clip tv"};
    private static final String[] THU_VI = {"Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư",
            "Thứ năm", "Thứ sáu", "Thứ bảy"};
    private static final String[] DAY_EN = {"Sunday", "Monday", "Tuesday", "Wednesday",
            "Thursday", "Friday", "Saturday"};
    private static final String[] MON_EN = {"January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"};

    private static final String[] PRESET_VI = {"Đỏ (mặc định)", "Xanh dương", "Tím", "Xanh lá", "Đen"};
    private static final String[] PRESET_EN = {"Red (default)", "Blue", "Purple", "Green", "Black"};
    private static final int[] PRESET_COLORS = {0xAAB71C1C, 0xAA1565C0, 0xAA6A1B9A, 0xAA2E7D32, 0};

    private static final String DEFAULT_CHANNELS = "VTV1, VTV2, VTV3, VTV6, HTV7, HTV9, VTC1, THVL1, ANTV";

    private static final String[] DISPLAY_KEYS = {"weatherOn", "tvOn", "barsOn", "holidayOn",
            "lunarAlertOn", "nameOn"};

    private static final int REQ_PICK_IMAGE = 101;
    private static final int REQ_ROLE = 102;
    private static final int REQ_LOC = 103;
    private static final int COLUMNS = 4;
    private static final float TILE_ALPHA = 0.6f;
    private static final long STATUS_INTERVAL = 2000;
    private static final TimeInterpolator SMOOTH = new PathInterpolator(0.25f, 0.1f, 0.25f, 1f);

    interface Opener {
        InputStream open() throws IOException;
    }

    static class AppItem {
        String label, pkg, cls;
        Drawable image;
        boolean banner, self;
    }

    static class MusicInfo {
        String text;
        PendingIntent open;
    }

    private String lang = "vi";

    private ScrollView scroll;
    private LinearLayout dock, tvSection, tvFrame, tvChannels, weatherBox, sysBars;
    private GridLayout grid;
    private TextView appName, greeting, dateView, lunarView, pillStatus;
    private TextView holidayView, lunarAlert, weatherTemp, weatherDesc, weatherCity;
    private TextView txtStorage, txtRam;
    private ProgressBar barStorage, barRam;

    private SharedPreferences prefs;
    private SoundPool sounds;
    private int soundMove, soundSelect;
    private boolean soundOn = true;
    private boolean quiet = false;

    private Dialog currentDialog;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statusTick = new Runnable() {
        @Override
        public void run() {
            updateStatus();
            updateSysBars();
            maybeFetchWeather(false);
            if (Calendar.getInstance().get(Calendar.DAY_OF_YEAR) != lastDay) updateHeader();
            handler.postDelayed(this, STATUS_INTERVAL);
        }
    };

    private List<AppItem> apps = new ArrayList<>();
    private String lastSignature = "";
    private String statusKey = "";
    private Runnable statusAction;
    private String movingPkg = null;
    private int tileW, tileH;
    private int lastDay = -1;
    private int channelIdx = 0;
    private boolean weatherBusy = false;
    private long lastWeatherAttempt = 0;

    // ================================================================ ngôn ngữ

    private boolean en() {
        return "en".equals(lang);
    }

    private String tr(String vi, String eng) {
        return en() ? eng : vi;
    }

    @Override
    protected void attachBaseContext(Context base) {
        lang = base.getSharedPreferences("cfg", MODE_PRIVATE).getString("lang", "vi");
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(new Locale(lang));
        super.attachBaseContext(base.createConfigurationContext(cfg));
    }

    // ================================================================ vòng đời

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        soundOn = prefs.getBoolean("sound", true);

        scroll = findViewById(R.id.scroll);
        dock = findViewById(R.id.dock);
        grid = findViewById(R.id.grid);
        tvSection = findViewById(R.id.tv_section);
        tvFrame = findViewById(R.id.tv_frame);
        tvChannels = findViewById(R.id.tv_channels);
        sysBars = findViewById(R.id.sys_bars);
        weatherBox = findViewById(R.id.weather_box);
        appName = findViewById(R.id.app_name);
        greeting = findViewById(R.id.greeting);
        dateView = findViewById(R.id.date);
        lunarView = findViewById(R.id.lunar);
        pillStatus = findViewById(R.id.pill_status);
        holidayView = findViewById(R.id.holiday);
        lunarAlert = findViewById(R.id.lunar_alert);
        weatherTemp = findViewById(R.id.weather_temp);
        weatherDesc = findViewById(R.id.weather_desc);
        weatherCity = findViewById(R.id.weather_city);
        txtStorage = findViewById(R.id.txt_storage);
        txtRam = findViewById(R.id.txt_ram);
        barStorage = findViewById(R.id.bar_storage);
        barRam = findViewById(R.id.bar_ram);

        try {
            initSounds();
        } catch (Exception ignored) {
        }
        try {
            applyBackground();
        } catch (Throwable t) {
            getWindow().setBackgroundDrawable(new ColorDrawable(0xFF0D0D10));
        }

        int[] pillIds = {R.id.pill_status, R.id.pill_wifi, R.id.pill_settings};
        for (int id : pillIds) {
            findViewById(id).setOnFocusChangeListener((v, has) -> {
                if (has) playMove();
            });
        }
        pillStatus.setOnClickListener(v -> {
            playSelect();
            if (statusAction != null) statusAction.run();
            else startVoiceSearch();
        });
        findViewById(R.id.pill_wifi).setOnClickListener(v -> {
            playSelect();
            startSafe(new Intent(Settings.ACTION_WIFI_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
        });
        findViewById(R.id.pill_settings).setOnClickListener(v -> {
            playSelect();
            showMenu();
        });
        applyVisibility();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateHeader();
        refreshApps(false, null);
        updateSysBars();
        showWeather();
        if (prefs.getBoolean("weatherOn", true)) {
            requestLocationIfNeeded(false);
            maybeFetchWeather(false);
        }
        handler.removeCallbacks(statusTick);
        handler.post(statusTick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(statusTick);
        dismissDialog();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        dismissDialog();             // bấm Home: đóng mọi menu đang mở
        if (movingPkg != null) endMove();
        goHome();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dismissDialog();
        if (sounds != null) {
            sounds.release();
            sounds = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Là màn hình chính nên không thoát khi bấm Back
    }

    private void goHome() {
        scroll.smoothScrollTo(0, 0);
        View first = dock.getChildAt(0);
        if (first != null && !first.hasFocus()) {
            quiet = true;
            first.requestFocus();
            quiet = false;
        }
    }

    // ================================================================ hộp thoại (luôn chỉ có 1 hộp thoại)

    private void present(AlertDialog.Builder builder) {
        dismissDialog();
        final AlertDialog d = builder.create();
        d.setOnDismissListener(x -> {
            if (currentDialog == d) currentDialog = null;
        });
        currentDialog = d;
        d.show();
    }

    private void dismissDialog() {
        if (currentDialog != null) {
            try {
                currentDialog.dismiss();
            } catch (Exception ignored) {
            }
            currentDialog = null;
        }
    }

    // ================================================================ phím (chế độ di chuyển)

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (movingPkg == null) {
            int k = e.getKeyCode();
            int dir = 0;
            if (k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP) dir = -1;
            else if (k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN) dir = 1;
            if (dir != 0 && tvChannels.getChildCount() > 0
                    && tvSection.getVisibility() == View.VISIBLE) {
                if (e.getAction() == KeyEvent.ACTION_DOWN) stepChannel(dir);
                return true;
            }
            return super.dispatchKeyEvent(e);
        }
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            switch (e.getKeyCode()) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    moveBy(-1);
                    break;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    moveBy(1);
                    break;
                case KeyEvent.KEYCODE_DPAD_UP:
                    moveBy(-COLUMNS);
                    break;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    moveBy(COLUMNS);
                    break;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_BACK:
                case KeyEvent.KEYCODE_ESCAPE:
                    endMove();
                    break;
                default:
                    return super.dispatchKeyEvent(e);
            }
        }
        return true;
    }

    private void startMove(AppItem a) {
        movingPkg = a.pkg;
        appName.setText(tr("Đang di chuyển: ", "Moving: ") + a.label);
        toast(tr("Dùng phím mũi tên để di chuyển, bấm OK để xong",
                "Use the arrow keys to move, press OK when done"));
    }

    private void endMove() {
        if (movingPkg == null) return;
        String p = movingPkg;
        movingPkg = null;
        saveOrder();
        for (AppItem a : apps) if (a.pkg.equals(p)) appName.setText(a.label);
        toast(tr("Đã lưu vị trí", "Position saved"));
    }

    private void moveBy(int delta) {
        int idx = -1;
        for (int i = 0; i < apps.size(); i++) if (apps.get(i).pkg.equals(movingPkg)) idx = i;
        if (idx < 0) return;
        int n = idx + delta;
        if (n < 0 || n >= apps.size()) return;
        AppItem a = apps.remove(idx);
        apps.add(n, a);
        buildViews(movingPkg);
        appName.setText(tr("Đang di chuyển: ", "Moving: ") + a.label);
        playMove();
    }

    private void saveOrder() {
        StringBuilder sb = new StringBuilder();
        for (AppItem a : apps) {
            if (sb.length() > 0) sb.append(',');
            sb.append(a.pkg);
        }
        prefs.edit().putString("order", sb.toString()).apply();
        lastSignature = signature(queryResolve());
    }

    // ================================================================ âm thanh

    private void initSounds() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        sounds = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build();
        soundMove = sounds.load(this, R.raw.move, 1);
        soundSelect = sounds.load(this, R.raw.select, 1);
    }

    private void playMove() {
        if (soundOn && !quiet && sounds != null) sounds.play(soundMove, 0.6f, 0.6f, 1, 0, 1f);
    }

    private void playSelect() {
        if (soundOn && sounds != null) sounds.play(soundSelect, 0.7f, 0.7f, 1, 0, 1f);
    }

    // ================================================================ nút trạng thái (giọng nói / USB / nhạc)

    private void updateStatus() {
        String key, text;
        int icon;
        Runnable action;

        final MusicInfo music = currentMusic();
        if (music != null) {
            key = "music:" + music.text;
            text = music.text;
            icon = R.drawable.ic_music;
            action = () -> {
                try {
                    if (music.open != null) {
                        music.open.send();
                        return;
                    }
                } catch (PendingIntent.CanceledException ignored) {
                }
                startSafe(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC));
            };
        } else if (usbConnected()) {
            key = "usb";
            text = tr("USB đã kết nối", "USB connected");
            icon = R.drawable.ic_usb;
            action = () -> startSafe(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
                    new Intent(Settings.ACTION_SETTINGS));
        } else {
            key = "voice";
            text = getString(R.string.voice_search);
            icon = R.drawable.ic_mic;
            action = this::startVoiceSearch;
        }
        statusAction = action;
        if (!key.equals(statusKey)) {
            statusKey = key;
            pillStatus.setText(text);
            pillStatus.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0);
        }
    }

    private MusicInfo currentMusic() {
        try {
            MediaSessionManager msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> list = msm.getActiveSessions(new ComponentName(this, MediaListener.class));
            for (MediaController c : list) {
                PlaybackState ps = c.getPlaybackState();
                if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) {
                    MusicInfo m = new MusicInfo();
                    MediaMetadata md = c.getMetadata();
                    String title = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_TITLE);
                    String artist = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                    if (title == null || title.isEmpty()) {
                        m.text = tr("Đang phát nhạc", "Playing music");
                    } else {
                        m.text = title + (artist == null || artist.isEmpty() ? "" : " - " + artist);
                    }
                    m.open = c.getSessionActivity();
                    return m;
                }
            }
        } catch (Exception ignored) {
        }
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null && am.isMusicActive()) {
                MusicInfo m = new MusicInfo();
                m.text = tr("Đang phát nhạc", "Playing music");
                return m;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private boolean usbConnected() {
        try {
            UsbManager um = (UsbManager) getSystemService(Context.USB_SERVICE);
            if (um != null) {
                for (UsbDevice d : um.getDeviceList().values()) {
                    for (int i = 0; i < d.getInterfaceCount(); i++) {
                        if (d.getInterface(i).getInterfaceClass() == UsbConstants.USB_CLASS_MASS_STORAGE) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        try {
            StorageManager sm = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
            if (sm != null) {
                for (StorageVolume v : sm.getStorageVolumes()) {
                    if (v.isRemovable() && Environment.MEDIA_MOUNTED.equals(v.getState())) return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void startVoiceSearch() {
        Intent katniss = new Intent(Intent.ACTION_ASSIST).setPackage("com.google.android.katniss");
        boolean ok = startSafe(katniss,
                new Intent(Intent.ACTION_VOICE_COMMAND),
                new Intent("android.intent.action.VOICE_ASSIST"),
                new Intent(Intent.ACTION_ASSIST),
                new Intent(RecognizerIntent.ACTION_WEB_SEARCH));
        if (!ok) toast(tr("Không tìm thấy Google Assistant trên TV này",
                "Google Assistant was not found on this TV"));
    }

    // ================================================================ dung lượng + RAM

    private void updateSysBars() {
        if (!prefs.getBoolean("barsOn", true)) return;
        try {
            StatFs st = new StatFs(Environment.getDataDirectory().getPath());
            long total = st.getTotalBytes();
            long free = st.getAvailableBytes();
            setBar(barStorage, txtStorage, total - free, total);

            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            setBar(barRam, txtRam, mi.totalMem - mi.availMem, mi.totalMem);
        } catch (Exception ignored) {
        }
    }

    private void setBar(ProgressBar bar, TextView txt, long used, long total) {
        if (total <= 0) return;
        int p = (int) (used * 100 / total);
        bar.setProgress(p);
        bar.setProgressTintList(ColorStateList.valueOf(p >= 90 ? 0xFFFF5252 : 0xE6FFFFFF));
        txt.setText(String.format(Locale.US, "%.1f/%.1f GB",
                used / 1073741824.0, total / 1073741824.0));
    }

    // ================================================================ thời tiết

    private void requestLocationIfNeeded(boolean force) {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) return;
            if (!force && prefs.getBoolean("locAsked", false)) return;
            prefs.edit().putBoolean("locAsked", true).apply();
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_LOC) maybeFetchWeather(true);
    }

    private void maybeFetchWeather(boolean force) {
        if (!prefs.getBoolean("weatherOn", true) || weatherBusy) return;
        long now = System.currentTimeMillis();
        if (!force) {
            if (now - lastWeatherAttempt < 5 * 60 * 1000L) return;
            if (now - prefs.getLong("w_time", 0) < 30 * 60 * 1000L) return;
        }
        lastWeatherAttempt = now;
        weatherBusy = true;
        final boolean eng = en();
        new Thread(() -> {
            try {
                Weather.Data d = Weather.fetch(getApplicationContext(), eng);
                prefs.edit()
                        .putFloat("w_temp", (float) d.temp)
                        .putFloat("w_min", (float) d.min)
                        .putFloat("w_max", (float) d.max)
                        .putInt("w_code", d.code)
                        .putInt("w_rain", d.rain)
                        .putString("w_city", d.city)
                        .putLong("w_time", System.currentTimeMillis())
                        .apply();
                runOnUiThread(this::showWeather);
            } catch (Exception ignored) {
                // giữ dữ liệu cũ, thử lại sau
            } finally {
                weatherBusy = false;
            }
        }).start();
    }

    private void showWeather() {
        if (!prefs.getBoolean("weatherOn", true)) {
            weatherBox.setVisibility(View.GONE);
            return;
        }
        weatherBox.setVisibility(View.VISIBLE);
        if (prefs.getLong("w_time", 0) == 0) {
            weatherTemp.setText("…");
            weatherDesc.setText(tr("Đang tải thời tiết", "Loading weather"));
            weatherCity.setText("");
            return;
        }
        String[] d = Weather.describe(prefs.getInt("w_code", 0), en());
        weatherTemp.setText(d[0] + " " + Math.round(prefs.getFloat("w_temp", 0)) + "°C");
        weatherDesc.setText(d[1] + " · " + Math.round(prefs.getFloat("w_min", 0)) + "°/"
                + Math.round(prefs.getFloat("w_max", 0)) + "° · 💧" + prefs.getInt("w_rain", 0) + "%");
        weatherCity.setText(prefs.getString("w_city", ""));
    }

    // ================================================================ menu Cài đặt

    private void showMenu() {
        String[] items = {
                tr("Cài đặt hệ thống", "System settings"),
                tr("Đặt launcher mặc định", "Set as default launcher"),
                tr("Hình nền", "Wallpaper"),
                tr("Hiển thị…", "Display…"),
                tr("Khung kênh TV…", "TV channel frame…"),
                tr("Đổi tên hiển thị…", "Change display name…"),
                tr("Ngôn ngữ", "Language"),
                tr("Âm thanh di chuyển: ", "Navigation sound: ") + (soundOn ? tr("Bật", "On") : tr("Tắt", "Off")),
                tr("Hiện bài hát đang phát", "Show now playing"),
                tr("Ứng dụng đã ẩn", "Hidden apps"),
                getString(R.string.info_title)};
        int[] icons = {R.drawable.ic_tv, R.drawable.ic_home, R.drawable.ic_image, R.drawable.ic_tune,
                R.drawable.ic_live_tv, R.drawable.ic_person, R.drawable.ic_language, R.drawable.ic_volume,
                R.drawable.ic_music_dlg, R.drawable.ic_apps, R.drawable.ic_info};
        showIconMenu(tr("Cài đặt", "Settings"), items, icons, (dlg, which) -> {
            switch (which) {
                case 0:
                    startSafe(new Intent(Settings.ACTION_SETTINGS));
                    break;
                case 1:
                    showDefaultLauncherMenu();
                    break;
                case 2:
                    showWallpaperMenu();
                    break;
                case 3:
                    showDisplayMenu();
                    break;
                case 4:
                    showTvFrameMenu();
                    break;
                case 5:
                    askName();
                    break;
                case 6:
                    showLanguageMenu();
                    break;
                case 7:
                    soundOn = !soundOn;
                    prefs.edit().putBoolean("sound", soundOn).apply();
                    toast(tr("Âm thanh di chuyển: ", "Navigation sound: ")
                            + (soundOn ? tr("Bật", "On") : tr("Tắt", "Off")));
                    playSelect();
                    break;
                case 8:
                    toast(tr("Bật quyền cho \"" + getString(R.string.app_name) + "\" để hiện tên bài hát",
                            "Allow \"" + getString(R.string.app_name) + "\" to show the song title"));
                    startSafe(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                    break;
                case 9:
                    showHiddenApps();
                    break;
                default:
                    showInfo();
                    break;
            }
        });
    }

    private void showIconMenu(String title, String[] labels, final int[] icons,
                              DialogInterface.OnClickListener listener) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, labels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setCompoundDrawablesRelativeWithIntrinsicBounds(icons[position], 0, 0, 0);
                t.setCompoundDrawablePadding(dp(16));
                return t;
            }
        };
        present(new AlertDialog.Builder(this).setTitle(title).setAdapter(adapter, listener));
    }

    private void showDisplayMenu() {
        String[] labels = {
                tr("Thời tiết", "Weather"),
                tr("Khung kênh TV", "TV channel frame"),
                tr("Dung lượng & RAM", "Storage & RAM"),
                tr("Đếm ngược ngày lễ", "Holiday countdown"),
                tr("Nhắc mùng 1, 14, 15, cuối tháng âm", "Lunar alerts (1st, 14th, 15th, last day)"),
                tr("Hiện tên trong lời chào", "Show name in greeting")};
        boolean[] checked = new boolean[DISPLAY_KEYS.length];
        for (int i = 0; i < checked.length; i++) checked[i] = prefs.getBoolean(DISPLAY_KEYS[i], true);
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Hiển thị", "Display"))
                .setMultiChoiceItems(labels, checked, (dlg, which, isChecked) -> {
                    prefs.edit().putBoolean(DISPLAY_KEYS[which], isChecked).apply();
                    onDisplayChanged(DISPLAY_KEYS[which], isChecked);
                })
                .setPositiveButton(tr("Xong", "Done"), null));
    }

    private void onDisplayChanged(String key, boolean on) {
        applyVisibility();
        if ("weatherOn".equals(key)) {
            if (on) {
                requestLocationIfNeeded(true);
                maybeFetchWeather(true);
            }
            showWeather();
        } else if ("tvOn".equals(key)) {
            buildTvFrame();
        } else if ("barsOn".equals(key)) {
            updateSysBars();
        } else {
            updateHeader();
        }
    }

    private void applyVisibility() {
        tvSection.setVisibility(prefs.getBoolean("tvOn", true) ? View.VISIBLE : View.GONE);
        sysBars.setVisibility(prefs.getBoolean("barsOn", true) ? View.VISIBLE : View.GONE);
        if (!prefs.getBoolean("weatherOn", true)) weatherBox.setVisibility(View.GONE);
    }

    private void showLanguageMenu() {
        String[] items = {"Tiếng Việt", "English"};
        int cur = en() ? 1 : 0;
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Ngôn ngữ", "Language"))
                .setSingleChoiceItems(items, cur, (dlg, which) -> {
                    dlg.dismiss();
                    String nl = which == 1 ? "en" : "vi";
                    if (!nl.equals(lang)) {
                        prefs.edit().putString("lang", nl).apply();
                        recreate();
                    }
                }));
    }

    private void askName() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(prefs.getString("name", ""));
        et.setSelection(et.getText().length());
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Nhập tên của bạn", "Enter your name"))
                .setView(et)
                .setPositiveButton(tr("Lưu", "Save"), (dlg, w) -> {
                    prefs.edit().putString("name", et.getText().toString().trim())
                            .putBoolean("nameOn", true).apply();
                    updateHeader();
                })
                .setNegativeButton(tr("Hủy", "Cancel"), null));
    }

    private void showHiddenApps() {
        final List<String> hidden = new ArrayList<>(new TreeSet<>(hiddenSet()));
        if (hidden.isEmpty()) {
            toast(tr("Chưa có ứng dụng nào bị ẩn", "No hidden apps"));
            return;
        }
        PackageManager pm = getPackageManager();
        String[] labels = new String[hidden.size()];
        for (int i = 0; i < hidden.size(); i++) {
            try {
                labels[i] = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(hidden.get(i), 0)));
            } catch (Exception e) {
                labels[i] = hidden.get(i);
            }
        }
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Chọn ứng dụng để hiện lại", "Choose an app to show again"))
                .setItems(labels, (dlg, which) -> {
                    Set<String> h = hiddenSet();
                    h.remove(hidden.get(which));
                    prefs.edit().putStringSet("hidden", h).apply();
                    refreshApps(true, hidden.get(which));
                    toast(tr("Đã hiện lại ứng dụng", "App is visible again"));
                }));
    }

    private void showInfo() {
        String version = "1.0";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        final String url = getString(R.string.info_url);
        String msg = getString(R.string.app_name) + "\n" + getString(R.string.info_description)
                + "\n\n" + tr("Phiên bản: ", "Version: ") + version
                + "\n\nFacebook:\n" + url;
        present(new AlertDialog.Builder(this)
                .setTitle(R.string.info_title)
                .setMessage(msg)
                .setPositiveButton(R.string.info_open, (dlg, w) -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) {
                        toast(tr("TV chưa có trình duyệt. Hãy truy cập: ", "No browser on this TV. Visit: ") + url);
                    }
                })
                .setNegativeButton(R.string.info_close, null));
    }

    // ================================================================ khung kênh TV

    private void showTvFrameMenu() {
        String[] items = {tr("Khung 1: chọn ứng dụng", "Frame 1: choose app"),
                tr("Khung 2: chọn ứng dụng", "Frame 2: choose app"),
                tr("Sửa danh sách kênh hay xem…", "Edit favorite channels…"),
                tr("Khôi phục kênh mặc định", "Restore default channels")};
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Khung kênh TV", "TV channel frame"))
                .setItems(items, (dlg, which) -> {
                    if (which < 2) {
                        pickTvApp(which);
                    } else if (which == 2) {
                        editChannels();
                    } else {
                        prefs.edit().remove("channels").apply();
                        buildTvFrame();
                        toast(tr("Đã khôi phục kênh mặc định", "Default channels restored"));
                    }
                }));
    }

    private void editChannels() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(prefs.getString("channels", DEFAULT_CHANNELS));
        et.setSelection(et.getText().length());
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Kênh hay xem (cách nhau bằng dấu phẩy)",
                        "Favorite channels (comma separated)"))
                .setView(et)
                .setPositiveButton(tr("Lưu", "Save"), (dlg, w) -> {
                    prefs.edit().putString("channels", et.getText().toString().trim()).apply();
                    buildTvFrame();
                })
                .setNegativeButton(tr("Hủy", "Cancel"), null));
    }

    private void pickTvApp(final int slot) {
        final List<AppItem> list = new ArrayList<>();
        for (AppItem a : apps) if (!a.self) list.add(a);
        String[] labels = new String[list.size() + 1];
        labels[0] = tr("Tự động", "Automatic");
        for (int i = 0; i < list.size(); i++) labels[i + 1] = list.get(i).label;
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Khung ", "Frame ") + (slot + 1))
                .setItems(labels, (dlg, which) -> {
                    prefs.edit().putString("tv" + slot, which == 0 ? "" : list.get(which - 1).pkg).apply();
                    buildTvFrame();
                }));
    }

    private AppItem findApp(String pkg) {
        for (AppItem a : apps) if (a.pkg.equals(pkg)) return a;
        return null;
    }

    private AppItem[] tvApps() {
        AppItem[] res = new AppItem[2];
        for (int s = 0; s < 2; s++) {
            String p = prefs.getString("tv" + s, "");
            if (!p.isEmpty()) res[s] = findApp(p);
        }
        for (String key : TV_KEYS) {
            if (res[0] != null && res[1] != null) break;
            for (AppItem a : apps) {
                if (a.self || a == res[0] || a == res[1]) continue;
                if (a.label.toLowerCase(Locale.ROOT).contains(key)) {
                    if (res[0] == null && prefs.getString("tv0", "").isEmpty()) res[0] = a;
                    else if (res[1] == null && prefs.getString("tv1", "").isEmpty()) res[1] = a;
                    else continue;
                    break;
                }
            }
        }
        return res;
    }

    private void buildTvFrame() {
        tvFrame.removeAllViews();
        boolean on = prefs.getBoolean("tvOn", true);
        tvSection.setVisibility(on ? View.VISIBLE : View.GONE);
        if (!on) return;
        AppItem[] picks = tvApps();
        for (int i = 0; i < 2; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(84), 1f);
            lp.setMargins(dp(8), dp(4), dp(8), dp(4));
            tvFrame.addView(makeTvCard(picks[i], i), lp);
        }
        buildChannels();
    }

    private void buildChannels() {
        tvChannels.removeAllViews();
        String list = prefs.getString("channels", DEFAULT_CHANNELS);
        int counter = 0;
        for (String raw : list.split(",")) {
            final String name = raw.trim();
            if (name.isEmpty()) continue;
            final int index = counter++;
            TextView t = new TextView(this);
            t.setText(name);
            t.setTextColor(0xFFFFFFFF);
            t.setTextSize(12);
            t.setSingleLine(true);
            t.setBackgroundResource(R.drawable.pill_bg);
            t.setPadding(dp(16), dp(7), dp(16), dp(7));
            t.setFocusable(true);
            t.setClickable(true);
            t.setOnFocusChangeListener((v, has) -> {
                if (has) {
                    channelIdx = index;
                    playMove();
                    if (movingPkg == null) appName.setText(tr("Kênh ", "Channel ") + name);
                }
            });
            t.setOnClickListener(v -> {
                playSelect();
                openChannel(name, v);
            });
            t.setOnLongClickListener(v -> {
                playSelect();
                searchChannel(name);
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(dp(8), dp(4), 0, dp(8));
            tvChannels.addView(t, lp);
        }
    }

    /** CH+/CH-: chuyển sang kênh kế tiếp/trước đó (lần đầu: đưa con trỏ vào hàng kênh). */
    private void stepChannel(int dir) {
        int n = tvChannels.getChildCount();
        if (n == 0) return;
        View focused = tvChannels.findFocus();
        int cur = -1;
        for (int i = 0; i < n; i++) if (tvChannels.getChildAt(i) == focused) cur = i;
        int next = cur < 0 ? Math.min(channelIdx, n - 1) : (cur + dir + n) % n;
        tvChannels.getChildAt(next).requestFocus();
    }

    private AppItem findByLabel(String key) {
        for (AppItem a : apps) {
            if (!a.self && a.label.toLowerCase(Locale.ROOT).contains(key)) return a;
        }
        return null;
    }

    /** Bấm kênh: mở ứng dụng xem TV phù hợp (VTV → VTVgo nếu có, còn lại → ứng dụng ở khung 1/2). */
    private void openChannel(String name, View from) {
        AppItem target = null;
        if (name.toLowerCase(Locale.ROOT).startsWith("vtv")) target = findByLabel("vtv");
        if (target == null) {
            AppItem[] p = tvApps();
            target = p[0] != null ? p[0] : p[1];
        }
        if (target == null) {
            pickTvApp(0);
            return;
        }
        toast(tr("Mở " + target.label + " – chọn kênh " + name,
                "Opening " + target.label + " – pick channel " + name));
        launch(target, from);
    }

    /** Nhấn giữ kênh: tìm kênh bằng Google (Android TV). */
    private void searchChannel(String name) {
        Intent s1 = new Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.katniss");
        s1.putExtra(SearchManager.QUERY, name);
        Intent s2 = new Intent(Intent.ACTION_SEARCH);
        s2.putExtra(SearchManager.QUERY, name);
        if (!startSafe(s1, s2)) {
            toast(tr("TV này không hỗ trợ tìm kiếm", "Search is not supported on this TV"));
        }
    }

    private View makeTvCard(final AppItem a, final int slot) {
        final FrameLayout f = new FrameLayout(this);
        f.setBackgroundResource(R.drawable.tile_bg);
        f.setClipToOutline(true);
        f.setFocusable(true);
        f.setClickable(true);

        final ImageView iv = new ImageView(this);
        if (a != null) {
            iv.setImageDrawable(a.image);
            iv.setAlpha(TILE_ALPHA);
            if (a.banner) {
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            } else {
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setPadding(dp(20), dp(8), dp(20), dp(8));
            }
            f.addView(iv, new FrameLayout.LayoutParams(-1, -1));

            TextView label = new TextView(this);
            label.setText(a.label);
            label.setTextColor(0xFFFFFFFF);
            label.setTextSize(13);
            label.setSingleLine(true);
            label.setPadding(dp(12), dp(16), dp(12), dp(8));
            label.setBackgroundResource(R.drawable.scrim);
            f.addView(label, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        } else {
            TextView t = new TextView(this);
            t.setText(tr("+ Chọn ứng dụng TV", "+ Choose a TV app"));
            t.setTextColor(0xB3FFFFFF);
            t.setTextSize(13);
            t.setGravity(Gravity.CENTER);
            f.addView(t, new FrameLayout.LayoutParams(-1, -1));
        }

        f.setOnFocusChangeListener((v, has) -> {
            float s = has ? 1.04f : 1f;
            f.animate().scaleX(s).scaleY(s).setDuration(180).setInterpolator(SMOOTH).start();
            f.setTranslationZ(has ? dp(8) : 0);
            f.setForeground(has ? getDrawable(R.drawable.tile_focus) : null);
            if (a != null) iv.animate().alpha(has ? 1f : TILE_ALPHA).setDuration(180).start();
            if (has) {
                playMove();
                if (movingPkg == null) appName.setText(a != null ? a.label : "");
            }
        });
        f.setOnClickListener(v -> {
            playSelect();
            if (a != null) launch(a, v);
            else pickTvApp(slot);
        });
        f.setOnLongClickListener(v -> {
            playSelect();
            pickTvApp(slot);
            return true;
        });
        return f;
    }

    // ================================================================ launcher mặc định

    private void showDefaultLauncherMenu() {
        String[] items = {
                tr("Để hệ thống hỏi (khuyên dùng)", "Let the system ask (recommended)"),
                tr("ADB qua Wi-Fi", "ADB over Wi-Fi"),
                tr("ADB qua USB", "ADB over USB"),
                tr("Khôi phục launcher gốc (khi bị đen màn hình)", "Restore stock launcher (black screen)")};
        int[] icons = {R.drawable.ic_home, R.drawable.ic_wifi, R.drawable.ic_usb, R.drawable.ic_tv};
        showIconMenu(tr("Đặt launcher mặc định", "Set as default launcher"), items, icons, (dlg, which) -> {
            final String pkg = getPackageName();
            final String set = "adb shell cmd package set-home-activity " + pkg + "/.MainActivity";
            if (which == 0) {
                requestDefaultLauncher();
            } else if (which == 1) {
                String ip = localIp();
                showAdbHelp(tr("ADB qua Wi-Fi", "ADB over Wi-Fi"),
                        tr("1. Trên TV: Cài đặt → Tùy chọn nhà phát triển → bật Gỡ lỗi USB và Gỡ lỗi qua mạng (Wi-Fi).\n"
                                + "2. Máy tính và TV dùng chung mạng Wi-Fi.\n"
                                + "3. Chạy các lệnh dưới đây trên máy tính (Android 11 trở lên cần 'adb pair IP:CỔNG' trước).\n\n"
                                + "Sau khi đặt xong, bấm Home để kiểm tra. Nếu bị đen màn hình, dùng mục Khôi phục launcher gốc.",
                                "1. On the TV: Settings → Developer options → enable USB debugging and network (Wi-Fi) debugging.\n"
                                        + "2. Computer and TV must be on the same Wi-Fi.\n"
                                        + "3. Run the commands below on the computer (Android 11+ needs 'adb pair IP:PORT' first).\n\n"
                                        + "Press Home afterwards to check. If the screen goes black, use Restore stock launcher."),
                        "adb connect " + (ip == null ? "<IP-TV>" : ip) + ":5555\n" + set);
            } else if (which == 2) {
                showAdbHelp(tr("ADB qua USB", "ADB over USB"),
                        tr("1. Bật Gỡ lỗi USB trên TV và nối TV với máy tính bằng cáp USB (cổng hỗ trợ ADB).\n"
                                + "2. Chạy các lệnh dưới đây trên máy tính. Nếu TV hỏi cho phép gỡ lỗi thì chọn Cho phép.",
                                "1. Enable USB debugging on the TV and connect it to the computer with a USB cable.\n"
                                        + "2. Run the commands below. Accept the debugging prompt on the TV if it appears."),
                        "adb devices\n" + set);
            } else {
                showAdbHelp(tr("Khôi phục launcher gốc", "Restore stock launcher"),
                        tr("Dùng khi màn hình đen hoặc muốn quay về giao diện cũ. Chọn 1 trong 2 lệnh phù hợp với TV "
                                + "(Android TV hoặc Google TV), chạy qua ADB Wi-Fi hoặc USB.",
                                "Use this if the screen is black or you want the old home screen back. "
                                        + "Pick the command that matches your TV (Android TV or Google TV) and run it over ADB Wi-Fi or USB."),
                        "adb shell cmd package set-home-activity com.google.android.tvlauncher/.MainActivity\n"
                                + "adb shell cmd package set-home-activity com.google.android.apps.tv.launcherx/.home.HomeActivity");
            }
        });
    }

    private void requestDefaultLauncher() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                        toast(tr("Đã là launcher mặc định", "Already the default launcher"));
                        return;
                    }
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_ROLE);
                    return;
                }
            }
        } catch (Exception ignored) {
        }
        if (!startSafe(new Intent(Settings.ACTION_HOME_SETTINGS), new Intent(Settings.ACTION_SETTINGS))) {
            toast(tr("TV không hỗ trợ, hãy dùng ADB", "Not supported on this TV, use ADB"));
        }
    }

    private void showAdbHelp(String title, String intro, final String cmd) {
        present(new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(intro + "\n\n" + cmd)
                .setPositiveButton(tr("Sao chép lệnh", "Copy commands"), (dlg, w) -> {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("adb", cmd));
                        toast(tr("Đã sao chép", "Copied"));
                    } catch (Exception e) {
                        toast(tr("Không sao chép được", "Could not copy"));
                    }
                })
                .setNegativeButton(tr("Đóng", "Close"), null));
    }

    private String localIp() {
        try {
            Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
            while (nis.hasMoreElements()) {
                NetworkInterface ni = nis.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress a = addrs.nextElement();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    // ================================================================ hình nền

    private void showWallpaperMenu() {
        final String[] names = en() ? PRESET_EN : PRESET_VI;
        final int n = names.length;
        String[] items = new String[n + 2];
        System.arraycopy(names, 0, items, 0, n);
        items[n] = tr("Chọn ảnh từ thiết bị…", "Choose a photo from device…");
        items[n + 1] = tr("Chọn ảnh từ thư mục ứng dụng…", "Choose a photo from the app folder…");
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Hình nền", "Wallpaper"))
                .setItems(items, (dlg, which) -> {
                    if (which < n) {
                        prefs.edit().putString("bg", "preset:" + which).apply();
                        applyBackground();
                    } else if (which == n) {
                        pickImage();
                    } else {
                        showLocalImages();
                    }
                }));
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try {
            startActivityForResult(i, REQ_PICK_IMAGE);
        } catch (ActivityNotFoundException e) {
            toast(tr("TV này không có trình chọn ảnh, dùng thư mục ứng dụng",
                    "This TV has no photo picker, using the app folder"));
            showLocalImages();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK_IMAGE && res == RESULT_OK && data != null && data.getData() != null) {
            final Uri uri = data.getData();
            applyCustomAsync(() -> getContentResolver().openInputStream(uri));
        } else if (req == REQ_ROLE) {
            toast(res == RESULT_OK ? tr("Đã đặt làm launcher mặc định", "Set as default launcher")
                    : tr("Chưa đặt làm mặc định", "Not set as default"));
        }
    }

    private void showLocalImages() {
        final File dir = getExternalFilesDir("wallpapers");
        File[] found = dir == null ? null : dir.listFiles((d, name) -> {
            String l = name.toLowerCase(Locale.ROOT);
            return l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") || l.endsWith(".webp");
        });
        final String path = dir == null ? "" : dir.getAbsolutePath();
        if (found == null || found.length == 0) {
            present(new AlertDialog.Builder(this)
                    .setTitle(tr("Chưa có ảnh nào", "No photos yet"))
                    .setMessage(tr("Hãy chép ảnh (jpg/png/webp) vào thư mục:\n", "Copy photos (jpg/png/webp) to:\n") + path
                            + tr("\n\nVí dụ từ máy tính:\n", "\n\nExample from a computer:\n")
                            + "adb push photo.jpg " + path + "/")
                    .setPositiveButton(tr("Đóng", "Close"), null));
            return;
        }
        final File[] files = found;
        String[] names = new String[files.length];
        for (int k = 0; k < files.length; k++) names[k] = files[k].getName();
        present(new AlertDialog.Builder(this)
                .setTitle(tr("Chọn ảnh nền", "Choose a wallpaper"))
                .setItems(names, (dlg, which) -> {
                    final File f = files[which];
                    applyCustomAsync(() -> new FileInputStream(f));
                }));
    }

    private void applyCustomAsync(final Opener opener) {
        final DisplayMetrics dm = getResources().getDisplayMetrics();
        new Thread(() -> {
            try {
                Bitmap bm = decodeCover(opener, dm.widthPixels, dm.heightPixels);
                if (bm == null) throw new IOException("decode");
                try (FileOutputStream os = new FileOutputStream(new File(getFilesDir(), "wallpaper.jpg"))) {
                    bm.compress(Bitmap.CompressFormat.JPEG, 90, os);
                }
                prefs.edit().putString("bg", "custom").apply();
                runOnUiThread(() -> {
                    applyBackground();
                    toast(tr("Đã đổi hình nền", "Wallpaper changed"));
                });
            } catch (Exception | OutOfMemoryError e) {
                runOnUiThread(() -> toast(tr("Không đọc được ảnh này", "Could not read this photo")));
            }
        }).start();
    }

    private Bitmap decodeCover(Opener opener, int w, int h) throws IOException {
        BitmapFactory.Options op = new BitmapFactory.Options();
        op.inJustDecodeBounds = true;
        try (InputStream is = opener.open()) {
            BitmapFactory.decodeStream(is, null, op);
        }
        int s = 1;
        while (op.outWidth / (s * 2) >= w && op.outHeight / (s * 2) >= h) s *= 2;
        op.inJustDecodeBounds = false;
        op.inSampleSize = s;
        Bitmap src;
        try (InputStream is = opener.open()) {
            src = BitmapFactory.decodeStream(is, null, op);
        }
        if (src == null) return null;

        float scale = Math.max((float) w / src.getWidth(), (float) h / src.getHeight());
        int cw = Math.min(src.getWidth(), Math.round(w / scale));
        int ch = Math.min(src.getHeight(), Math.round(h / scale));
        int x = Math.max(0, (src.getWidth() - cw) / 2);
        int y = Math.max(0, (src.getHeight() - ch) / 2);
        Bitmap crop = Bitmap.createBitmap(src, x, y, cw, ch);
        return Bitmap.createScaledBitmap(crop, w, h, true);
    }

    private void applyBackground() {
        String bg = prefs.getString("bg", "preset:0");
        Drawable d = null;
        if ("custom".equals(bg)) {
            File f = new File(getFilesDir(), "wallpaper.jpg");
            if (f.exists()) {
                Bitmap bm = BitmapFactory.decodeFile(f.getPath());
                if (bm != null) {
                    d = new LayerDrawable(new Drawable[]{
                            new BitmapDrawable(getResources(), bm),
                            new ColorDrawable(0x66000000)});
                }
            }
        }
        if (d == null) {
            int idx = 0;
            try {
                if (bg.startsWith("preset:")) idx = Integer.parseInt(bg.substring(7));
            } catch (NumberFormatException ignored) {
            }
            if (idx < 0 || idx >= PRESET_COLORS.length) idx = 0;
            d = presetDrawable(PRESET_COLORS[idx]);
        }
        getWindow().setBackgroundDrawable(d);
    }

    private Drawable presetDrawable(int glow) {
        ColorDrawable base = new ColorDrawable(0xFF0D0D10);
        if (glow == 0) return base;
        GradientDrawable g = new GradientDrawable();
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g.setGradientRadius(getResources().getDisplayMetrics().widthPixels * 0.7f);
        g.setGradientCenter(0.35f, 0.30f);
        g.setColors(new int[]{glow, 0x00000000});
        return new LayerDrawable(new Drawable[]{base, g});
    }

    // ================================================================ tiêu đề (lời chào, giờ, lịch, lễ)

    private void updateHeader() {
        Calendar c = Calendar.getInstance();
        lastDay = c.get(Calendar.DAY_OF_YEAR);
        int h = c.get(Calendar.HOUR_OF_DAY);
        int res = h < 12 ? R.string.good_morning : (h < 18 ? R.string.good_afternoon : R.string.good_evening);
        Locale loc = new Locale(lang);
        String g = getString(res);
        if (prefs.getBoolean("nameOn", true)) {
            String name = prefs.getString("name", "").trim();
            if (!name.isEmpty()) g += ", " + name;
        }
        greeting.setText(g.toUpperCase(loc));

        int dd = c.get(Calendar.DAY_OF_MONTH);
        int mm = c.get(Calendar.MONTH) + 1;
        int yy = c.get(Calendar.YEAR);
        int dow = c.get(Calendar.DAY_OF_WEEK) - 1;
        String d = en() ? DAY_EN[dow] + ", " + dd + " " + MON_EN[mm - 1]
                : THU_VI[dow] + ", " + dd + " tháng " + mm;
        dateView.setText(d.toUpperCase(loc));

        int[] lunar = null;
        try {
            lunarView.setText(LunarCalendar.format(dd, mm, yy, en()));
            lunar = LunarCalendar.solarToLunar(dd, mm, yy);
        } catch (Exception e) {
            lunarView.setText("");
        }

        // đếm ngược ngày lễ
        boolean holidayOn = prefs.getBoolean("holidayOn", true);
        holidayView.setVisibility(View.GONE);
        if (holidayOn) {
            try {
                Holidays.Result r = Holidays.next(c, en());
                if (r != null) {
                    String t;
                    if (r.days == 0) {
                        t = tr("Hôm nay là " + r.name, "Today is " + r.name);
                    } else {
                        t = tr("Còn " + r.days + " ngày đến " + r.name,
                                r.days + (r.days == 1 ? " day until " : " days until ") + r.name);
                    }
                    holidayView.setText(t);
                    holidayView.setVisibility(View.VISIBLE);
                }
            } catch (Exception ignored) {
            }
        }

        // thông báo đỏ: mùng 1, 14, 15, cuối tháng âm lịch
        lunarAlert.setVisibility(View.GONE);
        if (prefs.getBoolean("lunarAlertOn", true) && lunar != null) {
            try {
                int ld = lunar[0];
                Calendar t = (Calendar) c.clone();
                t.add(Calendar.DAY_OF_MONTH, 1);
                int[] next = LunarCalendar.solarToLunar(t.get(Calendar.DAY_OF_MONTH),
                        t.get(Calendar.MONTH) + 1, t.get(Calendar.YEAR));
                String msg = null;
                if (ld == 1) {
                    msg = tr("Hôm nay mùng 1 âm lịch", "Today is the 1st of the lunar month");
                } else if (ld == 14) {
                    msg = tr("Hôm nay 14 âm lịch – mai là Rằm", "Lunar 14th today – full moon tomorrow");
                } else if (ld == 15) {
                    msg = tr("Hôm nay Rằm (15 âm lịch)", "Today is the full moon (lunar 15th)");
                } else if (next[0] == 1) {
                    msg = tr("Hôm nay là ngày cuối tháng âm lịch (" + ld + ")",
                            "Last day of the lunar month (" + ld + ")");
                }
                if (msg != null) {
                    lunarAlert.setText("● " + msg);
                    lunarAlert.setVisibility(View.VISIBLE);
                }
            } catch (Exception ignored) {
            }
        }
    }

    // ================================================================ danh sách ứng dụng

    private Set<String> hiddenSet() {
        return new HashSet<>(prefs.getStringSet("hidden", new HashSet<String>()));
    }

    private List<ResolveInfo> queryResolve() {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> list = new ArrayList<>();
        list.addAll(pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0));
        list.addAll(pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0));
        List<ResolveInfo> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : list) {
            if (seen.add(ri.activityInfo.packageName)) out.add(ri);
        }
        return out;
    }

    private String signature(List<ResolveInfo> raw) {
        TreeSet<String> pk = new TreeSet<>();
        for (ResolveInfo ri : raw) pk.add(ri.activityInfo.packageName);
        return pk + "|" + new TreeSet<>(hiddenSet()) + "|" + prefs.getString("order", "")
                + "|" + prefs.getString("tv0", "") + "|" + prefs.getString("tv1", "");
    }

    private void refreshApps(boolean force, String focusPkg) {
        List<ResolveInfo> raw = queryResolve();
        String sig = signature(raw);
        if (!force && sig.equals(lastSignature)) return;
        lastSignature = sig;

        PackageManager pm = getPackageManager();
        Set<String> hidden = hiddenSet();
        List<AppItem> items = new ArrayList<>();
        for (ResolveInfo ri : raw) {
            String pkg = ri.activityInfo.packageName;
            if (hidden.contains(pkg)) continue;
            AppItem a = new AppItem();
            a.pkg = pkg;
            a.cls = ri.activityInfo.name;
            a.self = pkg.equals(getPackageName());
            a.label = String.valueOf(ri.loadLabel(pm));
            Drawable bn = ri.activityInfo.loadBanner(pm);
            a.banner = bn != null;
            a.image = bn != null ? bn : ri.loadIcon(pm);
            items.add(a);
        }
        apps = orderApps(items);
        buildViews(focusPkg);
    }

    private List<AppItem> defaultOrder(List<AppItem> items) {
        List<AppItem> sorted = new ArrayList<>(items);
        Collections.sort(sorted, (x, y) -> x.label.compareToIgnoreCase(y.label));
        List<AppItem> out = new ArrayList<>();
        for (String key : DOCK_PREF) {
            for (AppItem a : sorted) {
                if (!a.self && !out.contains(a) && a.label.toLowerCase(Locale.ROOT).contains(key)) {
                    out.add(a);
                    break;
                }
            }
        }
        for (AppItem a : sorted) if (!a.self && !out.contains(a)) out.add(a);
        for (AppItem a : sorted) if (a.self) out.add(a);
        return out;
    }

    private List<AppItem> orderApps(List<AppItem> items) {
        List<AppItem> def = defaultOrder(items);
        String saved = prefs.getString("order", "");
        if (saved.isEmpty()) return def;
        List<AppItem> out = new ArrayList<>();
        for (String p : saved.split(",")) {
            for (AppItem a : def) {
                if (a.pkg.equals(p) && !out.contains(a)) out.add(a);
            }
        }
        for (AppItem a : def) if (!out.contains(a)) out.add(a);
        return out;
    }

    private void buildViews(String focusPkg) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int inner = dm.widthPixels - 2 * dp(48) - 2 * dp(12);
        int margin = dp(8);
        int ringPad = dp(5);
        tileW = inner / COLUMNS - 2 * margin;
        tileH = tileW * 9 / 16;

        dock.removeAllViews();
        grid.removeAllViews();

        View focusTile = null;
        View firstTile = null;
        for (int i = 0; i < apps.size(); i++) {
            AppItem a = apps.get(i);
            View cell;
            View tile;
            if (i < COLUMNS) {
                tile = makeTile(a, false);
                cell = tile;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tileW, tileH);
                lp.setMargins(margin, margin, margin, margin);
                dock.addView(cell, lp);
            } else {
                cell = makeTile(a, true);
                tile = ((ViewGroup) cell).getChildAt(0);
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = tileW + 2 * ringPad;
                lp.height = tileH + 2 * ringPad;
                int m = margin - ringPad;
                lp.setMargins(m, m, m, m);
                grid.addView(cell, lp);
            }
            if (firstTile == null) firstTile = tile;
            if (a.pkg.equals(focusPkg)) focusTile = tile;
        }
        buildTvFrame();
        View target = focusTile != null ? focusTile : firstTile;
        if (target != null) {
            quiet = true;
            target.requestFocus();
            quiet = false;
        }
    }

    private View makeTile(final AppItem a, boolean ring) {
        final FrameLayout f = new FrameLayout(this);
        f.setBackgroundResource(R.drawable.tile_bg);
        f.setClipToOutline(true);
        f.setFocusable(true);
        f.setClickable(true);

        final ImageView iv = new ImageView(this);
        iv.setImageDrawable(a.image);
        iv.setAlpha(TILE_ALPHA);
        if (a.banner) {
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(dp(20), dp(12), dp(20), dp(12));
        }
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));

        final FrameLayout wrapper = ring ? new FrameLayout(this) : null;
        final View scaleTarget = ring ? wrapper : f;
        if (ring) {
            wrapper.setBackgroundResource(R.drawable.tile_ring);
            wrapper.setClipChildren(false);
            wrapper.addView(f, new FrameLayout.LayoutParams(tileW, tileH, Gravity.CENTER));
        }

        f.setOnFocusChangeListener((v, has) -> {
            float s = has ? 1.08f : 1f;
            scaleTarget.animate().scaleX(s).scaleY(s).setDuration(180).setInterpolator(SMOOTH).start();
            scaleTarget.setTranslationZ(has ? dp(8) : 0);
            f.setForeground(has ? getDrawable(R.drawable.tile_focus) : null);
            iv.animate().alpha(has ? 1f : TILE_ALPHA).setDuration(180).start();
            if (has) {
                if (movingPkg == null) appName.setText(a.label);
                playMove();
            }
        });
        f.setOnClickListener(v -> {
            playSelect();
            if (a.self) {
                showMenu();
            } else {
                launch(a, v);
            }
        });
        f.setOnLongClickListener(v -> {
            playSelect();
            showTileMenu(a);
            return true;
        });
        return ring ? wrapper : f;
    }

    private void launch(AppItem a, View from) {
        Intent it = new Intent(Intent.ACTION_MAIN)
                .setComponent(new ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ActivityOptions opts = ActivityOptions.makeScaleUpAnimation(
                    from, 0, 0, from.getWidth(), from.getHeight());
            startActivity(it, opts.toBundle());
        } catch (Exception e) {
            try {
                startActivity(it);
            } catch (Exception ignored) {
                toast(tr("Không mở được ", "Cannot open ") + a.label);
            }
        }
    }

    // ================================================================ nhấn giữ ô ứng dụng

    private void showTileMenu(final AppItem a) {
        String move = tr("Di chuyển", "Move");
        String hide = tr("Ẩn", "Hide");
        String del = tr("Xóa", "Uninstall");
        String[] labels = a.self ? new String[]{move, hide} : new String[]{move, hide, del};
        int[] icons = a.self ? new int[]{R.drawable.ic_move, R.drawable.ic_hide}
                : new int[]{R.drawable.ic_move, R.drawable.ic_hide, R.drawable.ic_delete};
        showIconMenu(a.label, labels, icons, (dlg, which) -> {
            if (which == 0) {
                startMove(a);
            } else if (which == 1) {
                Set<String> h = hiddenSet();
                h.add(a.pkg);
                prefs.edit().putStringSet("hidden", h).apply();
                refreshApps(true, null);
                toast(tr("Đã ẩn " + a.label + " (hiện lại trong Cài đặt → Ứng dụng đã ẩn)",
                        a.label + " hidden (restore in Settings → Hidden apps)"));
            } else {
                try {
                    startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                } catch (Exception e) {
                    toast(tr("Không gỡ được ứng dụng này", "Cannot uninstall this app"));
                }
            }
        });
    }

    // ================================================================ tiện ích

    private boolean startSafe(Intent... intents) {
        for (Intent i : intents) {
            try {
                startActivity(i);
                return true;
            } catch (Exception ignored) {
            }
        }
        return false;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
