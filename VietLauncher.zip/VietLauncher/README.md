# VietLauncher – Launcher Android TV tiếng Việt

Cách lấy file APK (không cần cài Android Studio):
1. Tạo repo mới trên GitHub, tải toàn bộ thư mục này lên (giữ nguyên thư mục `.github`).
2. Vào tab **Actions** → **Build APK** → **Run workflow**.
3. Khi chạy xong, tải APK ở mục **Artifacts** (giải nén file zip).
4. Cài lên TV:  adb connect <IP-TV>:5555  rồi  adb install app-debug.apk
5. Bấm nút Home trên remote, chọn "Màn hình chính" → "Luôn luôn" để đặt làm launcher mặc định.

Muốn đổi các app trên dock: sửa mảng DOCK_PREF trong MainActivity.java.

## Tùy chỉnh (nút "Tùy chỉnh" ở góc trên bên phải)
- **Hình nền**: 5 nền có sẵn, hoặc chọn ảnh từ thiết bị.
  Nếu TV không có trình chọn tệp, chép ảnh vào thư mục ứng dụng bằng ADB:
  adb push anh.jpg /sdcard/Android/data/vn.launcher.tv/files/wallpapers/
  rồi vào Tùy chỉnh → Hình nền → "Chọn ảnh từ thư mục ứng dụng".
- **Âm thanh di chuyển**: bật/tắt tiếng "tách" khi chuyển qua lại giữa các mục.

## Cập nhật
- Nút **Cài đặt** (có icon) mở menu: Hình nền, Âm thanh di chuyển, Cài đặt hệ thống của TV.
- Dưới đồng hồ có dòng lịch âm: [ Âm lịch: ngày/tháng - Can Chi ].
- Ô ứng dụng trong suốt 60% (hằng số TILE_ALPHA trong MainActivity.java), bo góc 32dp (tile_bg.xml).

## Icon và thông tin
- Icon ứng dụng + banner (hiện trong menu ứng dụng của Android TV): quả táo trắng trên nền đỏ (res/drawable/ic_launcher.xml, banner.xml).
- Cài đặt → **Thông tin**: nội dung đọc từ res/values/info.xml (info_url = http://facebook.com/TruongAlone).

## Bản cập nhật mới
- Lịch âm nằm ngay dưới ngày dương lịch (cùng một cột, cạnh đồng hồ).
- Ô ứng dụng: bo góc nhẹ (14dp), nền trắng trong suốt giống nút Cài đặt.
- Menu Cài đặt: Cài đặt hệ thống (đầu tiên), Hình nền, Âm thanh, Thông tin — đều có icon.
- Icon launcher hiện trong lưới "Tất cả ứng dụng" (bấm vào để mở menu Cài đặt).
- Icon/banner ứng dụng: quả táo trắng trên nền trắng trong suốt.
