# VietLauncher – Launcher Android TV tiếng Việt

Cách lấy file APK (không cần cài Android Studio):
1. Tạo repo mới trên GitHub, tải toàn bộ thư mục này lên (giữ nguyên thư mục `.github`).
2. Vào tab **Actions** → **Build APK** → **Run workflow**.
3. Khi chạy xong, tải APK ở mục **Artifacts** (giải nén file zip).
4. Cài lên TV:  adb connect <IP-TV>:5555  rồi  adb install app-debug.apk
5. Bấm nút Home trên remote, chọn "Màn hình chính" → "Luôn luôn" để đặt làm launcher mặc định.

Muốn đổi các app trên dock: sửa mảng DOCK_PREF trong MainActivity.java.

## Tùy chỉnh (nút "Tùy chỉnh" ở góc trên bên phải)
- **Hình nền**: 5 nền có sẵn, hoặc chọn ảnh từ thiết bị.
  Nếu TV không có trình chọn tệp, chép ảnh vào thư mục ứng dụng bằng ADB:
  adb push anh.jpg /sdcard/Android/data/vn.launcher.tv/files/wallpapers/
  rồi vào Tùy chỉnh → Hình nền → "Chọn ảnh từ thư mục ứng dụng".
- **Âm thanh di chuyển**: bật/tắt tiếng "tách" khi chuyển qua lại giữa các mục.

## Cập nhật
- Nút **Cài đặt** (có icon) mở menu: Hình nền, Âm thanh di chuyển, Cài đặt hệ thống của TV.
- Dưới đồng hồ có dòng lịch âm: [ Âm lịch: ngày/tháng - Can Chi ].
- Ô ứng dụng trong suốt 60% (hằng số TILE_ALPHA trong MainActivity.java), bo góc 32dp (tile_bg.xml).

## Icon và thông tin
- Icon ứng dụng + banner (hiện trong menu ứng dụng của Android TV): quả táo trắng trên nền đỏ (res/drawable/ic_launcher.xml, banner.xml).
- Cài đặt → **Thông tin**: nội dung đọc từ res/values/info.xml (info_url = http://facebook.com/TruongAlone).

## Bản cập nhật mới
- Lịch âm nằm ngay dưới ngày dương lịch (cùng một cột, cạnh đồng hồ).
- Ô ứng dụng: bo góc nhẹ (14dp), nền trắng trong suốt giống nút Cài đặt.
- Menu Cài đặt: Cài đặt hệ thống (đầu tiên), Hình nền, Âm thanh, Thông tin — đều có icon.
- Icon launcher hiện trong lưới "Tất cả ứng dụng" (bấm vào để mở menu Cài đặt).
- Icon/banner ứng dụng: quả táo trắng trên nền trắng trong suốt.

## Bản cập nhật (Home, thông báo, tên, nhấn giữ, viền, hiệu ứng)
- Sửa lỗi bấm Home bị nhấp nháy: không dựng lại giao diện khi danh sách app không đổi.
- Nút đầu thanh trên: mặc định "Tìm kiếm giọng nói" (Google Assistant); hiện "USB đã kết nối" khi cắm USB; hiện bài hát khi đang phát nhạc (cấp quyền tại Cài đặt → Hiện bài hát đang phát).
- Lời chào kèm tên (Cài đặt → Tên hiển thị: bật/tắt, đổi tên).
- Nhấn giữ OK trên ô ứng dụng: Di chuyển / Ẩn / Xóa. Ứng dụng đã ẩn hiện lại trong Cài đặt → Ứng dụng đã ẩn.
- Ô trong "Tất cả ứng dụng" có thêm viền bao ngoài mờ hơn.
- Mở ứng dụng có hiệu ứng phóng to mượt từ ô ứng dụng.

## Bản cập nhật lớn
- Sửa lỗi menu không đóng: mọi menu tự đóng khi bấm Home / mở app, luôn chỉ có 1 menu.
- Thời tiết (Open-Meteo): nhiệt độ, nắng/mưa, thấp–cao, % mưa; vị trí tự nhận bằng GPS/mạng (cần quyền vị trí), nếu không có thì theo IP.
- Cài đặt → Đặt launcher mặc định: hệ thống hỏi / hướng dẫn ADB Wi-Fi, USB (tự điền IP TV, nút Sao chép lệnh) / khôi phục launcher gốc.
- Cài đặt → Ngôn ngữ: Tiếng Việt / English.
- Khung 2 kênh TV phía trên thanh app (FPT Play, VTVgo, TV360...); nhấn giữ để đổi ứng dụng.
- Thanh dung lượng + RAM dưới giờ.
- Đếm ngược ngày lễ Việt Nam kèm trái tim đỏ.
- Thông báo đỏ mùng 1, 14, 15, cuối tháng âm lịch.
- Cài đặt → Hiển thị: bật/tắt từng mục trên.

## Cập nhật: nút tắt TV, FPT Play, viền sáng
- Nút "Tắt TV" (icon nguồn) cạnh nút Cài đặt, bật/tắt trong Cài đặt → Hiển thị. Dùng ADB nội bộ gửi phím SLEEP (chuyển TV sang chế độ chờ).
- Đã bỏ hàng kênh. Cài đặt → Khung kênh TV → "Mở FPT Play vào mục Truyền hình": đặt liên kết hoặc dãy phím điều hướng (ví dụ RIGHT RIGHT CENTER); có mục dò liên kết của FPT Play.
- Ô ứng dụng đang chọn: viền dày 6dp nhấp nháy đỏ ↔ trắng.

## Phiên bản 1.10
- Cài đè: bản build dùng khóa ký cố định (app/viet-launcher.p12). Lần đầu từ bản cũ cần gỡ bản cũ một lần; từ 1.10 trở đi cài đè (hoặc adb install -r).
- Icon + banner đổi sang PNG (res/drawable-nodpi) để hiện trong danh sách ứng dụng của TV.
- Launcher nhường cho trình hướng dẫn cài đặt của hệ thống khi TV chưa cài đặt xong (và bộ lọc HOME ưu tiên thấp).
- Bỏ nút tắt TV. Thanh dung lượng/RAM nhỏ một nửa. Icon LAN mới.
- Cài đặt → Hiển thị: thêm công tắc "Bài hát/video đang phát" (YouTube, SmartTube, TizenTube...).
- Cài đặt → "FPT Play: liên kết mở Truyền hình" (mặc định https://fptplay.vn/trang/channel); phím gán mở FPT Play cũng vào Truyền hình.
- Khung TV: 2 ô kênh chữ lớn (THVL1, VTV1), sửa tên/liên kết trong Cài đặt hoặc nhấn giữ OK trên ô.
- Viền LED mảnh 3dp nháy đỏ → vàng → xanh lá → trắng.

## Chống đen màn hình
- Đã bỏ đoạn "nhường trình hướng dẫn cài đặt" (có thể làm launcher tự đóng) và trả bộ lọc HOME về mặc định.
- Launcher ghi lỗi vào file; lần mở sau hiện hộp "Launcher từng gặp lỗi" (có nút Sao chép). Giao diện không dựng được thì hiện màn hình lỗi có nút mở Cài đặt / chọn launcher khác thay vì đen.
- Mỗi phần phụ (thời tiết, mạng, USB, nhạc...) chạy riêng, lỗi một phần không làm sập cả launcher. Vừa lỗi trong 1 phút → chế độ an toàn (tắt các phần phụ).

## Khung cài đặt kiểu macOS + khung nhạc/ảnh
- Cài đặt mở thành cửa sổ kiểu macOS (nền mờ bo góc, 3 chấm đỏ-vàng-xanh), đầu cửa sổ là logo tròn = hình nền và tên bạn đặt trong lời chào (bấm để đổi tên). Có âm thanh khi di chuyển/bấm. Các mục chia nhóm: Giao diện / Nội dung / Hệ thống.
- Hiển thị: bảng bật/tắt chia nhóm; bật/tắt riêng "Khung phát nhạc" và "Khung trình chiếu ảnh".
- Khung nhạc: phát nhạc từ bộ nhớ máy + USB, ảnh bìa, tên bài, Prev/Play-Pause/Stop/Next, thanh tiến trình, danh sách bài cuộn bên dưới.
- Khung ảnh: tự chuyển ảnh trên màn hình chính; bấm để trình chiếu toàn màn hình (◀ ▶ đổi ảnh, OK tạm dừng). Cài đặt → Nhạc & ảnh: chọn thư mục ảnh (bộ nhớ/USB), thời gian chuyển.
- Lần đầu cần cấp quyền đọc nhạc/ảnh. Nếu TV không hiện hộp cấp quyền: adb shell pm grant vn.launcher.tv android.permission.READ_MEDIA_AUDIO (và READ_MEDIA_IMAGES; Android 12 trở xuống dùng READ_EXTERNAL_STORAGE).

## Phiên bản 2.0.0
- Thanh 4 ứng dụng có 3 tab (3 chấm màu kiểu macOS, bấm OK để chuyển): đỏ = Ứng dụng, vàng = Mở gần đây nhất, xanh lá = Thường dùng. Nhấn giữ ô ứng dụng ở bất kỳ tab nào vẫn có menu Di chuyển / Ẩn / Xóa (Di chuyển sẽ đưa về tab Ứng dụng).
- Thông tin: cửa sổ kiểu "Giới thiệu về máy Mac" (logo, tên, phiên bản 2.0.0, mô tả, liên kết Facebook).
- Khung Cài đặt: bỏ "Đổi tên hiển thị" (bấm vào logo tròn/tên ở đầu cửa sổ để đổi tên). Thứ tự: Hình nền, Ngôn ngữ, Âm thanh (công tắc), Thông tin | Kênh trong khung TV, Gán phím, FPT Play | Hiển thị, Nhạc & ảnh, Đặt launcher mặc định, Cài đặt hệ thống, Ứng dụng đã ẩn.
- Các cửa sổ phụ (hình nền, ngôn ngữ, kênh, FPT Play, gán phím, độ trong suốt, hướng dẫn ADB) đều kiểu macOS.

## Cập nhật
- Ô ứng dụng (thanh 4 ô + lưới) nhỏ hơn 20%, ô đang chọn phóng to 125%. Khung viền LED (đỏ→vàng→xanh lá→trắng) trượt mượt từ ô này sang ô khác khi bấm phím điều hướng.
- Cài đặt, dưới logo tròn: 4 ô nhanh (Nguồn vào, Bluetooth, Mạng, Tắt TV) kèm chữ trạng thái nhỏ; bên dưới là thanh trượt âm lượng.
- Hình nền → "Chọn ảnh từ điện thoại (quét mã QR)": TV hiện mã QR, điện thoại (cùng Wi-Fi) quét, chọn ảnh, bấm Gửi. Máy chủ nhận ảnh chỉ chạy khi cửa sổ QR đang mở, đường dẫn có mã ngẫu nhiên.
- Thêm thư viện zxing-core (tạo mã QR). versionName vẫn 2.0.0, versionCode 201.

## Làm mới nhạc
- Cửa sổ nhạc có nút "Cập nhật danh sách" ở góc phải trên cùng: quét lại bộ nhớ và cả USB mới cắm (kể cả file chưa được hệ thống lập chỉ mục), giữ nguyên bài đang phát nếu còn. Cài đặt → Nhạc & ảnh → "Làm mới thư viện" cũng làm mới nhạc.
